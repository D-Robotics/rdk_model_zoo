var searchData=
[
  ['tensor_5fto_5fcls_5fresults_0',['tensor_to_cls_results',['../nn__math_8hpp.html#a37b1e2e89d1affee225bf838b5bc9124',1,'tensor_to_cls_results(hbDNNTensor &amp;tensor, std::vector&lt; Classification &gt; &amp;results):&#160;nn_math.cpp'],['../nn__math_8cpp.html#a37b1e2e89d1affee225bf838b5bc9124',1,'tensor_to_cls_results(hbDNNTensor &amp;tensor, std::vector&lt; Classification &gt; &amp;results):&#160;nn_math.cpp']]]
];
