var searchData=
[
  ['texts_0',['texts',['../structOCRResult.html#ab5850273cacefddb6817c7cc9e08acc6',1,'OCRResult']]],
  ['threshold_1',['threshold',['../structPaddleOCRDetConfig.html#a442471f9e0aa26f9ee656c6a2f14bb91',1,'PaddleOCRDetConfig']]]
];
