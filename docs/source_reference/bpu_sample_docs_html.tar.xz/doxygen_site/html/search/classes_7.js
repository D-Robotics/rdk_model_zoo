var searchData=
[
  ['ocrresult_0',['OCRResult',['../structOCRResult.html',1,'']]]
];
