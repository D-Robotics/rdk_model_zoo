var searchData=
[
  ['paddle_5focr_2ecpp_0',['paddle_ocr.cpp',['../paddle__ocr_8cpp.html',1,'']]],
  ['paddle_5focr_2ehpp_1',['paddle_ocr.hpp',['../paddle__ocr_8hpp.html',1,'']]],
  ['postprocess_2ecpp_2',['postprocess.cpp',['../postprocess_8cpp.html',1,'']]],
  ['postprocess_2ehpp_3',['postprocess.hpp',['../postprocess_8hpp.html',1,'']]],
  ['preprocess_2ecpp_4',['preprocess.cpp',['../preprocess_8cpp.html',1,'']]],
  ['preprocess_2ehpp_5',['preprocess.hpp',['../preprocess_8hpp.html',1,'']]]
];
