var searchData=
[
  ['paddleocrdet_0',['PaddleOCRDet',['../classPaddleOCRDet.html',1,'']]],
  ['paddleocrdetconfig_1',['PaddleOCRDetConfig',['../structPaddleOCRDetConfig.html',1,'']]],
  ['paddleocrrec_2',['PaddleOCRRec',['../classPaddleOCRRec.html',1,'']]],
  ['paddleocrrecconfig_3',['PaddleOCRRecConfig',['../structPaddleOCRRecConfig.html',1,'']]],
  ['poseresult_4',['PoseResult',['../structPoseResult.html',1,'']]]
];
