var searchData=
[
  ['bbox_0',['bbox',['../structDetection.html#a7825dc492220a7d8bb6dab96d1a5acbf',1,'Detection']]],
  ['bgr_5fto_5fnv12_5ftensor_1',['bgr_to_nv12_tensor',['../preprocess_8hpp.html#a73c711f13556433b7bc84e8651feef5d',1,'bgr_to_nv12_tensor(cv::Mat &amp;mat, std::vector&lt; hbDNNTensor &gt; &amp;input_tensor, int input_h, int input_w):&#160;preprocess.cpp'],['../preprocess_8cpp.html#a73c711f13556433b7bc84e8651feef5d',1,'bgr_to_nv12_tensor(cv::Mat &amp;mat, std::vector&lt; hbDNNTensor &gt; &amp;input_tensor, int input_h, int input_w):&#160;preprocess.cpp']]],
  ['boxes_2',['boxes',['../structTextDetResult.html#a2b1577cd0ee465d9c2e2bad35be86ff5',1,'TextDetResult::boxes'],['../structOCRResult.html#a94f06eacd6d068f9bc04e5c0279e0be9',1,'OCRResult::boxes']]],
  ['bpu_5falign_3',['BPU_ALIGN',['../preprocess_8cpp.html#a0aaf1cf977d5502c75696e913392d304',1,'preprocess.cpp']]]
];
