var searchData=
[
  ['tensor_5fto_5fcls_5fresults_0',['tensor_to_cls_results',['../nn__math_8hpp.html#a37b1e2e89d1affee225bf838b5bc9124',1,'tensor_to_cls_results(hbDNNTensor &amp;tensor, std::vector&lt; Classification &gt; &amp;results):&#160;nn_math.cpp'],['../nn__math_8cpp.html#a37b1e2e89d1affee225bf838b5bc9124',1,'tensor_to_cls_results(hbDNNTensor &amp;tensor, std::vector&lt; Classification &gt; &amp;results):&#160;nn_math.cpp']]],
  ['textdetresult_1',['TextDetResult',['../structTextDetResult.html',1,'']]],
  ['texts_2',['texts',['../structOCRResult.html#ab5850273cacefddb6817c7cc9e08acc6',1,'OCRResult']]],
  ['threshold_3',['threshold',['../structPaddleOCRDetConfig.html#a442471f9e0aa26f9ee656c6a2f14bb91',1,'PaddleOCRDetConfig']]]
];
