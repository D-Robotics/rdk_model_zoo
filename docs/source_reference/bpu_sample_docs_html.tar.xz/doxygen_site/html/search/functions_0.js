var searchData=
[
  ['argmax_5fnhwc_5fs32_0',['argmax_nhwc_s32',['../postprocess_8hpp.html#aba2c254af61e1174ae24226f69b86877',1,'argmax_nhwc_s32(const hbDNNTensor &amp;tensor):&#160;postprocess.cpp'],['../postprocess_8cpp.html#aba2c254af61e1174ae24226f69b86877',1,'argmax_nhwc_s32(const hbDNNTensor &amp;tensor):&#160;postprocess.cpp']]],
  ['asr_1',['ASR',['../classASR.html#a09855fcb9feef025b9a1a69adfe9d716',1,'ASR']]],
  ['audiochunkreader_2',['AudioChunkReader',['../classAudioChunkReader.html#aa79987cb5598b3735a818e0df8d924d1',1,'AudioChunkReader']]]
];
