var searchData=
[
  ['bbox_0',['bbox',['../structDetection.html#a7825dc492220a7d8bb6dab96d1a5acbf',1,'Detection']]],
  ['boxes_1',['boxes',['../structTextDetResult.html#a2b1577cd0ee465d9c2e2bad35be86ff5',1,'TextDetResult::boxes'],['../structOCRResult.html#a94f06eacd6d068f9bc04e5c0279e0be9',1,'OCRResult::boxes']]]
];
