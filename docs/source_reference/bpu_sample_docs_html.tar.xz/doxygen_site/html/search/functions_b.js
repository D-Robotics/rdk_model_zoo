var searchData=
[
  ['resize_5fmasks_5fto_5fboxes_0',['resize_masks_to_boxes',['../postprocess_8hpp.html#a4d51b83d652345d0622ea709ba6668cc',1,'resize_masks_to_boxes(const std::vector&lt; cv::Mat &gt; &amp;masks, const std::vector&lt; Detection &gt; &amp;detections, int img_w, int img_h, bool do_morph=true):&#160;postprocess.cpp'],['../postprocess_8cpp.html#af48421854f78f4beb7084f6a210fe2ff',1,'resize_masks_to_boxes(const std::vector&lt; cv::Mat &gt; &amp;masks, const std::vector&lt; Detection &gt; &amp;detections, int img_w, int img_h, bool do_morph):&#160;postprocess.cpp']]],
  ['resnet18_1',['Resnet18',['../classResnet18.html#a69dfff6473f0ea74bb3c479203f62bc9',1,'Resnet18']]],
  ['rgb_5fto_5fargb8888_2',['rgb_to_argb8888',['../visualize_8hpp.html#a071edfa25f8b76bbc3200a0a3cca9095',1,'rgb_to_argb8888(uint8_t r, uint8_t g, uint8_t b):&#160;visualize.cpp'],['../visualize_8cpp.html#a071edfa25f8b76bbc3200a0a3cca9095',1,'rgb_to_argb8888(uint8_t r, uint8_t g, uint8_t b):&#160;visualize.cpp']]]
];
