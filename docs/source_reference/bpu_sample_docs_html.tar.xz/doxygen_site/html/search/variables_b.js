var searchData=
[
  ['ratio_5fprime_0',['ratio_prime',['../structPaddleOCRDetConfig.html#aec0062e459a72b7a58ed74736f638bbf',1,'PaddleOCRDetConfig']]],
  ['rdk_5fcolors_1',['rdk_colors',['../visualize_8hpp.html#adfde41d608c5e97a59e85a41600650f5',1,'visualize.hpp']]],
  ['read_5fbuf_5f_2',['read_buf_',['../classAudioChunkReader.html#a5c0e7a6e44006c340ef36f36f9640aef',1,'AudioChunkReader']]],
  ['read_5fsize_5fframes_5f_3',['read_size_frames_',['../classAudioChunkReader.html#afe60da05f619c866de61d48c27e2fd64',1,'AudioChunkReader']]],
  ['reg_4',['reg',['../structYolo11Config.html#a8a52ae67ae0f64ae675229583b2a1edf',1,'Yolo11Config::reg'],['../structYOLO11PoseConfig.html#a29dad5e65b49e027b2b2e49b8d683677',1,'YOLO11PoseConfig::reg'],['../structYolo11SegConfig.html#a8f38ddfa649edb8ca09441161c32eb0a',1,'Yolo11SegConfig::reg'],['../structYoloE11SegConfig.html#a50f3ec6e4b8802ce30338c1f4225fbd3',1,'YoloE11SegConfig::reg']]],
  ['resize_5fmode_5',['resize_mode',['../structMobileNetV2Config.html#a69a6f77fc24d15497666232ddac15f4b',1,'MobileNetV2Config::resize_mode'],['../structResnet18Config.html#a8860792d8c47987f207aa8e789f56272',1,'Resnet18Config::resize_mode'],['../structYolov5Config.html#ab4ad101aa211ca39f3947a77c69f1961',1,'Yolov5Config::resize_mode']]]
];
