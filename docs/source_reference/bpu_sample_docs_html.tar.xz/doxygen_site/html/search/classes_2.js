var searchData=
[
  ['detection_0',['Detection',['../structDetection.html',1,'']]]
];
