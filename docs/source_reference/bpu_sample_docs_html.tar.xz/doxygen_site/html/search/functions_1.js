var searchData=
[
  ['bgr_5fto_5fnv12_5ftensor_0',['bgr_to_nv12_tensor',['../preprocess_8hpp.html#a73c711f13556433b7bc84e8651feef5d',1,'bgr_to_nv12_tensor(cv::Mat &amp;mat, std::vector&lt; hbDNNTensor &gt; &amp;input_tensor, int input_h, int input_w):&#160;preprocess.cpp'],['../preprocess_8cpp.html#a73c711f13556433b7bc84e8651feef5d',1,'bgr_to_nv12_tensor(cv::Mat &amp;mat, std::vector&lt; hbDNNTensor &gt; &amp;input_tensor, int input_h, int input_w):&#160;preprocess.cpp']]]
];
