var searchData=
[
  ['write_5fchw32_5fto_5ftensor_0',['write_chw32_to_tensor',['../preprocess_8hpp.html#a6c5727baabff96aeec01c15d5cdd3a3e',1,'write_chw32_to_tensor(const std::vector&lt; cv::Mat &gt; &amp;channels, const std::vector&lt; hbDNNTensor &gt; &amp;tensor):&#160;preprocess.cpp'],['../preprocess_8cpp.html#a6c5727baabff96aeec01c15d5cdd3a3e',1,'write_chw32_to_tensor(const std::vector&lt; cv::Mat &gt; &amp;channels, const std::vector&lt; hbDNNTensor &gt; &amp;tensor):&#160;preprocess.cpp']]]
];
