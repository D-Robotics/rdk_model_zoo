var searchData=
[
  ['default_5fmodel_5fpath_0',['DEFAULT_MODEL_PATH',['../vision_2unetmobilenet_2runtime_2cpp_2src_2main_8cpp.html#ab67c7b269904cd7e78dadafb0b06e236',1,'DEFAULT_MODEL_PATH:&#160;main.cpp'],['../vision_2yolo11_2runtime_2cpp_2src_2main_8cpp.html#ab67c7b269904cd7e78dadafb0b06e236',1,'DEFAULT_MODEL_PATH:&#160;main.cpp'],['../vision_2yolo11__pose_2runtime_2cpp_2src_2main_8cpp.html#ab67c7b269904cd7e78dadafb0b06e236',1,'DEFAULT_MODEL_PATH:&#160;main.cpp'],['../vision_2yolo11__seg_2runtime_2cpp_2src_2main_8cpp.html#ab67c7b269904cd7e78dadafb0b06e236',1,'DEFAULT_MODEL_PATH:&#160;main.cpp'],['../vision_2yoloe11__seg_2runtime_2cpp_2src_2main_8cpp.html#ab67c7b269904cd7e78dadafb0b06e236',1,'DEFAULT_MODEL_PATH:&#160;main.cpp']]]
];
