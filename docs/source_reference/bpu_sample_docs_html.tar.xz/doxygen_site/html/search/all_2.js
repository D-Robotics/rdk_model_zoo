var searchData=
[
  ['channels_5f_0',['channels_',['../classAudioChunkReader.html#ad1cc8188dd53abf72c8660e0f0839305',1,'AudioChunkReader']]],
  ['class_5fid_1',['class_id',['../structClassification.html#a0d44d3491e8f1faab905994e2e3fbf3a',1,'Classification::class_id'],['../structDetection.html#ad83942fdc49d92291671fccfb59fa0aa',1,'Detection::class_id']]],
  ['class_5fids_2',['class_ids',['../structSegmentationMask.html#a81cdebaa2095b9b2be9f62a90b25f01b',1,'SegmentationMask']]],
  ['classification_3',['Classification',['../structClassification.html',1,'']]],
  ['colorize_5fmask_4',['colorize_mask',['../visualize_8hpp.html#aeafc251061028ec54d22142d3efb4e56',1,'colorize_mask(const cv::Mat &amp;seg_mask, const std::vector&lt; cv::Scalar &gt; &amp;colors):&#160;visualize.cpp'],['../visualize_8cpp.html#aeafc251061028ec54d22142d3efb4e56',1,'colorize_mask(const cv::Mat &amp;seg_mask, const std::vector&lt; cv::Scalar &gt; &amp;colors):&#160;visualize.cpp']]],
  ['crop_5fand_5frotate_5fimage_5',['crop_and_rotate_image',['../postprocess_8hpp.html#a71fdda669e226120a0ef060605086248',1,'crop_and_rotate_image(const cv::Mat &amp;img, const std::vector&lt; cv::Point &gt; &amp;box):&#160;postprocess.cpp'],['../postprocess_8cpp.html#a71fdda669e226120a0ef060605086248',1,'crop_and_rotate_image(const cv::Mat &amp;img, const std::vector&lt; cv::Point &gt; &amp;box):&#160;postprocess.cpp']]],
  ['crops_6',['crops',['../structTextDetResult.html#a96526df24611f2a36b10bc3642cdba39',1,'TextDetResult']]],
  ['ctc_5fgreedy_5fdecode_5ffrom_5ftensor_7',['ctc_greedy_decode_from_tensor',['../paddle__ocr_8cpp.html#a5761c65f7ffc6f4a86a5e933b9a128e7',1,'paddle_ocr.cpp']]]
];
