var searchData=
[
  ['keypoints_0',['keypoints',['../structPoseResult.html#ae8e32af8b913568db4fedc5200beac3d',1,'PoseResult']]],
  ['kpt_5fconf_5fthresh_1',['kpt_conf_thresh',['../structYOLO11PoseConfig.html#a58b66cef8c80af9d09b5d4fd2b61c040',1,'YOLO11PoseConfig']]]
];
