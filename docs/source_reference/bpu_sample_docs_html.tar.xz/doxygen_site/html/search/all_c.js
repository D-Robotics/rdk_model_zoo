var searchData=
[
  ['new_5frate_0',['new_rate',['../structASRConfig.html#a8c5e226cd95cfb5cb43488e021204788',1,'ASRConfig']]],
  ['new_5frate_5f_1',['new_rate_',['../classAudioChunkReader.html#abea96388953d645c72a60ba54ee3c80d',1,'AudioChunkReader']]],
  ['next_2',['next',['../classAudioChunkReader.html#a426348a5666d361d2b5511d867471ddf',1,'AudioChunkReader']]],
  ['nms_5fbboxes_3',['nms_bboxes',['../postprocess_8hpp.html#a45544ec2cc7b62c3c9adc6b8245c9951',1,'nms_bboxes(const std::vector&lt; Detection &gt; &amp;detections, float iou_thresh=0.45f):&#160;postprocess.cpp'],['../postprocess_8cpp.html#a9cb248a8f7aedb2908a2f66d90568c78',1,'nms_bboxes(const std::vector&lt; Detection &gt; &amp;detections, float iou_thresh):&#160;postprocess.cpp']]],
  ['nms_5fthresh_4',['nms_thresh',['../structYolo11Config.html#ae1682511911d3795fe83b34dfe2abc62',1,'Yolo11Config::nms_thresh'],['../structYOLO11PoseConfig.html#a9fe4304f367cd216481ce0b5471dceca',1,'YOLO11PoseConfig::nms_thresh'],['../structYolo11SegConfig.html#af30811a5b7c90a3c3442440c35a8a43f',1,'Yolo11SegConfig::nms_thresh'],['../structYoloE11SegConfig.html#a1f744b272c3180c1f26821f814f60bff',1,'YoloE11SegConfig::nms_thresh'],['../structYolov5Config.html#ad92171a479e6172e9ba82c541e4c5d26',1,'Yolov5Config::nms_thresh']]],
  ['nms_5fwith_5fkpts_5',['nms_with_kpts',['../yolo11pose_8cpp.html#a52c593a73e927308f54991f734622ca6',1,'yolo11pose.cpp']]],
  ['nms_5fwith_5fmces_6',['nms_with_mces',['../yolo11seg_8cpp.html#a874302136f32faa88bb09669bbe583b7',1,'nms_with_mces(const std::vector&lt; Detection &gt; &amp;detections, const std::vector&lt; std::vector&lt; float &gt; &gt; &amp;mces, float iou_thresh):&#160;yolo11seg.cpp'],['../yoloe11seg_8cpp.html#a874302136f32faa88bb09669bbe583b7',1,'nms_with_mces(const std::vector&lt; Detection &gt; &amp;detections, const std::vector&lt; std::vector&lt; float &gt; &gt; &amp;mces, float iou_thresh):&#160;yoloe11seg.cpp']]],
  ['nn_5fmath_2ecpp_7',['nn_math.cpp',['../nn__math_8cpp.html',1,'']]],
  ['nn_5fmath_2ehpp_8',['nn_math.hpp',['../nn__math_8hpp.html',1,'']]],
  ['num_5fclasses_9',['num_classes',['../classPaddleOCRRec.html#ab31fd3a12989424ba2a82b74d28b2370',1,'PaddleOCRRec::num_classes'],['../structUnetMobileNetConfig.html#aaad21d39fc463206baa08bd5e02a6e4a',1,'UnetMobileNetConfig::num_classes'],['../structYolo11Config.html#a2b1a7e76a251bc50184a5b80792d1480',1,'Yolo11Config::num_classes'],['../structYolov5Config.html#a94fccad702e24b7d6e052be26c5e0080',1,'Yolov5Config::num_classes']]]
];
