var searchData=
[
  ['channels_5f_0',['channels_',['../classAudioChunkReader.html#ad1cc8188dd53abf72c8660e0f0839305',1,'AudioChunkReader']]],
  ['class_5fid_1',['class_id',['../structClassification.html#a0d44d3491e8f1faab905994e2e3fbf3a',1,'Classification::class_id'],['../structDetection.html#ad83942fdc49d92291671fccfb59fa0aa',1,'Detection::class_id']]],
  ['class_5fids_2',['class_ids',['../structSegmentationMask.html#a81cdebaa2095b9b2be9f62a90b25f01b',1,'SegmentationMask']]],
  ['crops_3',['crops',['../structTextDetResult.html#a96526df24611f2a36b10bc3642cdba39',1,'TextDetResult']]]
];
