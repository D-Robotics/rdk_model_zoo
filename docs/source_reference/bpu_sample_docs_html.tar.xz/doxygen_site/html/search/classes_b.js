var searchData=
[
  ['textdetresult_0',['TextDetResult',['../structTextDetResult.html',1,'']]]
];
