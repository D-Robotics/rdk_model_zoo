var searchData=
[
  ['ratio_5fprime_0',['ratio_prime',['../structPaddleOCRDetConfig.html#aec0062e459a72b7a58ed74736f638bbf',1,'PaddleOCRDetConfig']]],
  ['rdk_5fcolors_1',['rdk_colors',['../visualize_8hpp.html#adfde41d608c5e97a59e85a41600650f5',1,'visualize.hpp']]],
  ['read_5fbuf_5f_2',['read_buf_',['../classAudioChunkReader.html#a5c0e7a6e44006c340ef36f36f9640aef',1,'AudioChunkReader']]],
  ['read_5fsize_5fframes_5f_3',['read_size_frames_',['../classAudioChunkReader.html#afe60da05f619c866de61d48c27e2fd64',1,'AudioChunkReader']]],
  ['reg_4',['reg',['../structYolo11Config.html#a8a52ae67ae0f64ae675229583b2a1edf',1,'Yolo11Config::reg'],['../structYOLO11PoseConfig.html#a29dad5e65b49e027b2b2e49b8d683677',1,'YOLO11PoseConfig::reg'],['../structYolo11SegConfig.html#a8f38ddfa649edb8ca09441161c32eb0a',1,'Yolo11SegConfig::reg'],['../structYoloE11SegConfig.html#a50f3ec6e4b8802ce30338c1f4225fbd3',1,'YoloE11SegConfig::reg']]],
  ['resize_5fmasks_5fto_5fboxes_5',['resize_masks_to_boxes',['../postprocess_8hpp.html#a4d51b83d652345d0622ea709ba6668cc',1,'resize_masks_to_boxes(const std::vector&lt; cv::Mat &gt; &amp;masks, const std::vector&lt; Detection &gt; &amp;detections, int img_w, int img_h, bool do_morph=true):&#160;postprocess.cpp'],['../postprocess_8cpp.html#af48421854f78f4beb7084f6a210fe2ff',1,'resize_masks_to_boxes(const std::vector&lt; cv::Mat &gt; &amp;masks, const std::vector&lt; Detection &gt; &amp;detections, int img_w, int img_h, bool do_morph):&#160;postprocess.cpp']]],
  ['resize_5fmode_6',['resize_mode',['../structMobileNetV2Config.html#a69a6f77fc24d15497666232ddac15f4b',1,'MobileNetV2Config::resize_mode'],['../structResnet18Config.html#a8860792d8c47987f207aa8e789f56272',1,'Resnet18Config::resize_mode'],['../structYolov5Config.html#ab4ad101aa211ca39f3947a77c69f1961',1,'Yolov5Config::resize_mode']]],
  ['resnet18_7',['Resnet18',['../classResnet18.html',1,'Resnet18'],['../classResnet18.html#a69dfff6473f0ea74bb3c479203f62bc9',1,'Resnet18::Resnet18()']]],
  ['resnet18_2ecpp_8',['resnet18.cpp',['../resnet18_8cpp.html',1,'']]],
  ['resnet18_2ehpp_9',['resnet18.hpp',['../resnet18_8hpp.html',1,'']]],
  ['resnet18config_10',['Resnet18Config',['../structResnet18Config.html',1,'']]],
  ['rgb_5fto_5fargb8888_11',['rgb_to_argb8888',['../visualize_8hpp.html#a071edfa25f8b76bbc3200a0a3cca9095',1,'rgb_to_argb8888(uint8_t r, uint8_t g, uint8_t b):&#160;visualize.cpp'],['../visualize_8cpp.html#a071edfa25f8b76bbc3200a0a3cca9095',1,'rgb_to_argb8888(uint8_t r, uint8_t g, uint8_t b):&#160;visualize.cpp']]],
  ['runtime_2ehpp_12',['runtime.hpp',['../runtime_8hpp.html',1,'']]]
];
