var searchData=
[
  ['resnet18_0',['Resnet18',['../classResnet18.html',1,'']]],
  ['resnet18config_1',['Resnet18Config',['../structResnet18Config.html',1,'']]]
];
