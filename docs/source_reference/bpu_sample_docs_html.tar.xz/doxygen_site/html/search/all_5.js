var searchData=
[
  ['get_5fbounding_5fboxes_0',['get_bounding_boxes',['../postprocess_8hpp.html#acc7d41b626a65b6b7da477a6c3ec7a01',1,'get_bounding_boxes(const std::vector&lt; std::vector&lt; cv::Point &gt; &gt; &amp;dilated_polys, float min_area):&#160;postprocess.cpp'],['../postprocess_8cpp.html#acc7d41b626a65b6b7da477a6c3ec7a01',1,'get_bounding_boxes(const std::vector&lt; std::vector&lt; cv::Point &gt; &gt; &amp;dilated_polys, float min_area):&#160;postprocess.cpp']]],
  ['get_5ftopk_5fresult_1',['get_topk_result',['../postprocess_8hpp.html#ab60b5237a2cad02d0d75054b8e16bb50',1,'get_topk_result(const std::vector&lt; Classification &gt; &amp;results, std::vector&lt; Classification &gt; &amp;topk_results, size_t k):&#160;postprocess.cpp'],['../postprocess_8cpp.html#ab60b5237a2cad02d0d75054b8e16bb50',1,'get_topk_result(const std::vector&lt; Classification &gt; &amp;results, std::vector&lt; Classification &gt; &amp;topk_results, size_t k):&#160;postprocess.cpp']]]
];
