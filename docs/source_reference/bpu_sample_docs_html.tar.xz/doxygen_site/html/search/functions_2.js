var searchData=
[
  ['colorize_5fmask_0',['colorize_mask',['../visualize_8hpp.html#aeafc251061028ec54d22142d3efb4e56',1,'colorize_mask(const cv::Mat &amp;seg_mask, const std::vector&lt; cv::Scalar &gt; &amp;colors):&#160;visualize.cpp'],['../visualize_8cpp.html#aeafc251061028ec54d22142d3efb4e56',1,'colorize_mask(const cv::Mat &amp;seg_mask, const std::vector&lt; cv::Scalar &gt; &amp;colors):&#160;visualize.cpp']]],
  ['crop_5fand_5frotate_5fimage_1',['crop_and_rotate_image',['../postprocess_8hpp.html#a71fdda669e226120a0ef060605086248',1,'crop_and_rotate_image(const cv::Mat &amp;img, const std::vector&lt; cv::Point &gt; &amp;box):&#160;postprocess.cpp'],['../postprocess_8cpp.html#a71fdda669e226120a0ef060605086248',1,'crop_and_rotate_image(const cv::Mat &amp;img, const std::vector&lt; cv::Point &gt; &amp;box):&#160;postprocess.cpp']]],
  ['ctc_5fgreedy_5fdecode_5ffrom_5ftensor_2',['ctc_greedy_decode_from_tensor',['../paddle__ocr_8cpp.html#a5761c65f7ffc6f4a86a5e933b9a128e7',1,'paddle_ocr.cpp']]]
];
