var searchData=
[
  ['scale_5fkeypoints_5fback_5fletterbox_0',['scale_keypoints_back_letterbox',['../postprocess_8hpp.html#a3d5833c6872d704496e09c181b52840f',1,'scale_keypoints_back_letterbox(std::vector&lt; std::vector&lt; Keypoint &gt; &gt; &amp;kpts, int img_w, int img_h, int input_w, int input_h):&#160;postprocess.cpp'],['../postprocess_8cpp.html#a3d5833c6872d704496e09c181b52840f',1,'scale_keypoints_back_letterbox(std::vector&lt; std::vector&lt; Keypoint &gt; &gt; &amp;kpts, int img_w, int img_h, int input_w, int input_h):&#160;postprocess.cpp']]],
  ['scale_5fletterbox_5fbboxes_5fback_1',['scale_letterbox_bboxes_back',['../postprocess_8hpp.html#a60e486a56db9c0a4a43600911d1359df',1,'scale_letterbox_bboxes_back(std::vector&lt; Detection &gt; &amp;dets, int img_w, int img_h, int input_w, int input_h):&#160;postprocess.cpp'],['../postprocess_8cpp.html#a60e486a56db9c0a4a43600911d1359df',1,'scale_letterbox_bboxes_back(std::vector&lt; Detection &gt; &amp;dets, int img_w, int img_h, int input_w, int input_h):&#160;postprocess.cpp']]],
  ['sigmoid_2',['sigmoid',['../nn__math_8hpp.html#ae18d105356d4d3e7730d931fce4bfb23',1,'nn_math.hpp']]],
  ['softmax_3',['softmax',['../nn__math_8hpp.html#a6f63e1b1a01e3876fb6a2721d03f5bd5',1,'nn_math.hpp']]]
];
