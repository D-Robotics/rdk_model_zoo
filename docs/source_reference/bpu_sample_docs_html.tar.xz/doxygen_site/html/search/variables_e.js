var searchData=
[
  ['vocab_5fsize_0',['vocab_size',['../classASR.html#ae6de7e5b7e6ef89aeef8b878f79723ad',1,'ASR']]]
];
