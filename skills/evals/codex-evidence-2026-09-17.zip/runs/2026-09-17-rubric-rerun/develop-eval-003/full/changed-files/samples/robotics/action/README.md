# Robotics action / 机器人动作样例

## 当前状态 / Current status

本次范围仅涉及 Python。当前不支持 C++：`runtime/cpp/README.md` 只有 TODO，没有实现。
`runtime/python/main.py` 中的 `action(values)` 仅原样返回输入，不是实际模型推理或机器人控制实现。

This delivery scope covers Python only. C++ is currently unsupported: `runtime/cpp/README.md`
contains only a TODO, with no implementation. Python's `action(values)` in
`runtime/python/main.py` returns its input unchanged; it does not implement model inference
or robot control.

## 交付要求与缺口 / Delivery requirements and gaps

依据 [仓库规范](../../../docs/Model_Zoo_Repository_Guidelines.md)，robotics 必须提供 Python 和 C++ 实现。
本次范围说明不豁免双 runtime 要求；当前样例交付不完整，不可据此通过双 runtime 验收。
后续仍需补齐真实的 Python/C++ 实现、模型与 I/O 契约及相应验证。

The [repository guidelines](../../../docs/Model_Zoo_Repository_Guidelines.md) require both
Python and C++ implementations for robotics. This scope statement does not waive that
requirement. Delivery remains incomplete and cannot pass dual-runtime acceptance.
Real Python/C++ implementations, model and I/O contracts, and corresponding verification
remain outstanding.

## 验证限制 / Validation limits

这是隔离的合成测试样例。未运行模型推理、板端测试或机器人闭环测试；占位产物不代表实际模型。

This is an isolated synthetic fixture. Model inference, board tests, and closed-loop robot
tests have not been run. Placeholder artifacts are not actual models.
