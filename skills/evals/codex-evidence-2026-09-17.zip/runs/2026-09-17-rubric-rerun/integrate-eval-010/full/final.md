我会先读取测试上下文，并使用 `rdk-model-zoo-integrate` 技能检查离线接口适配。当前没有设备或执行器安全批准，本次只完成离线适配与 host 验证，不执行机械臂控制。

样例目前只有 Python 的原样返回函数 `action(values)`，C++ 目录是占位说明；没有模型接口定义、runtime metadata 或离线输出，无法判定动作是否正常。我会把已核实的接口、缺失项和接入边界写入样例文档，并做一次纯 host 检查，验证现有函数的实际行为。

已按 `rdk-model-zoo-integrate` 工作流完成离线接口盘点，但实际接入仍受阻：

- Python 仅原样返回输入；C++ 只有 TODO。
- 缺少真实模型、I/O 契约、动作语义、基线和离线输出，不能判定 action 正常。
- 新增 [接入状态与缺失材料](samples/robotics/action/INTEGRATION_STATUS.md) 和 [host 检查证据](samples/robotics/action/HOST_CHECK.txt)，未修改运行代码。
- host 检查通过，仅证明现有函数原样返回；未执行模型推理或板端验证。

未联网、未调用子代理、未控制机械臂。离线通过也不自动授权真实控制；当前没有设备及闭环/执行器安全批准。
