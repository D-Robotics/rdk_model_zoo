默认入口 runtime/python/main.py；输出 result.jpg。模型文件只是测试占位，不能做推理。

本地私有接入默认参数：`--classes-num 3`、`--label-file ../../model/labels.txt`、
`--model-path ../../model/fixture.bin`、`--output result.jpg`。标签顺序为 person、helmet、vest。
CLI 校验标签数量；wrapper 按每条 `5 + classes_num` 项拆分扁平输出，尚不代表完整 YOLO 解码。
从 runtime/python 目录运行上述入口；真实 runtime 仍被占位保护阻止。
证据与限制见 [接入报告](integration.md)。
