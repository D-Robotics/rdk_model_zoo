# 本地三类别接口适配

目标：X5，rdk_x5，基线 fcf40bdd24a734e9bbc9e334b74f24012c854bb5，Python detect。
这是私有应用接口适配，不是公开贡献或模型发版。上下文明确所有模型字节为占位数据。

| 项目 | 来源与对照 | 处理/状态 |
|---|---|---|
| 类别 | private/model-metadata.json 声明 3 类；labels.txt 同序 person/helmet/vest | Config 默认 3，CLI 支持显式配置并校验标签 |
| 输出 shape | metadata 声明 [1,25200,8]；旧 wrapper 默认每条 85 项 | 默认每条 8 项；host 合成数据验证拆分 |
| 输出名称、节点顺序、dtype/layout | metadata 未提供 | 未知；拆分不能证明输出语义与顺序 |
| 输入名称、shape、dtype/layout | 未提供 | 未验证 |
| 色彩、归一化、量化/反量化、anchors、坐标与分数语义 | 未提供 | 未验证，不推测实现 |
| 产物/runtime | private/custom.hbm 为占位；actual_runtime_verified=false | 不重命名为 bin，不加载、不上传 |
| predict 接口 | 规范要求 (boxes, scores, cls_ids)，现有 fixture 抛错 | 保留阻断；不能声称检测部署完成 |

未提供 export/conversion 或真实编译收据。工具链产物状态：未验证，未运行转换。
样例接入状态：完成三类别配置、标签校验和结构拆分适配；真实推理尚未完成。
utils/postprocess.py 仅复制非空行并保留空结果，没有可复用的真实 YOLO 解码逻辑。

验证计划：在 REPO_ROOT 执行 `python -X utf8 -m unittest discover -s tests -v`，
仅使用标准库和合成数组，不加载模型、不联网、不访问设备。日志存于
`runs/yolov5-integration-host.txt`。覆盖 metadata/标签一致性、25200 条 8 项输出、
空输出、错误宽度、非法类别数、标签数量/空标签、类别覆盖及已有公共后处理空输入测试。
这些检查不证明模型数值、精度、性能或硬件兼容性。板端验证、同输入浮点/工具链/样例
结果比较均为 not-run：缺真实模型、输入契约、基线及设备。

没有执行公开上传，也没有更改下载地址或发布清单。当前任务禁止联网，且未明确
要公开的具体资产、服务器目标和授权范围；任何后续发布均需先明确这些信息。
私有权重及历史 runs/previous-evidence.txt 保持原样。
