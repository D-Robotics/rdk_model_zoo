"""Synthetic host checks only; no model loading or hardware inference."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / 'samples/vision/yolov5'
sys.path.insert(0, str(SAMPLE / 'runtime/python'))
from main import build_model, parse_args
from yolov5 import Config, Model


class TestIntegration(unittest.TestCase):
    def test_metadata_and_full_synthetic_output(self):
        metadata = json.loads((ROOT / 'private/model-metadata.json').read_text(encoding='utf-8'))
        args = parse_args(['--label-file', str(SAMPLE / 'model/labels.txt')])
        model, labels = build_model(args)
        self.assertEqual(labels, metadata['labels'])
        self.assertEqual(model.config.classes_num, metadata['classes'])
        batch, count, width = metadata['outputs']
        self.assertEqual(batch, 1)
        self.assertEqual(width, 5 + model.config.classes_num)
        row = list(range(width))
        self.assertEqual(model.decode(row * count), [row] * count)

    def test_bad_width_and_empty(self):
        model = Model(Config())
        with self.assertRaises(ValueError):
            model.decode([0] * 7)
        self.assertEqual(model.decode([]), [])

    def test_invalid_classes(self):
        for value in (0, -1, True, 3.5):
            with self.assertRaises(ValueError):
                Config(value)

    def test_label_mismatch_and_blank(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            labels = Path(directory) / 'labels.txt'
            for content in ('person\nhelmet\n', 'person\n\nvest\n'):
                labels.write_text(content, encoding='utf-8')
                with self.assertRaises(ValueError):
                    build_model(parse_args(['--label-file', str(labels)]))

    def test_class_override(self):
        args = parse_args(['--classes-num', '2'])
        self.assertEqual(args.classes_num, 2)
        self.assertEqual(Model(Config(args.classes_num)).decode(list(range(7))), [list(range(7))])
