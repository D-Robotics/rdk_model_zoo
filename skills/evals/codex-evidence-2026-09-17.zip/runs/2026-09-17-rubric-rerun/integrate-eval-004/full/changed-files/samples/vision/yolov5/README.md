# YOLOv5
Run from samples/vision/yolov5/runtime/python: python main.py --model-path ../../model/fixture.bin --output result.jpg
Python entry: runtime/python/main.py. Wrapper: yolov5.py. Output result.jpg. Download requires explicit task scope; asset URL is deliberately non-routable.

Local private integration defaults: `--classes-num 3`, `--label-file ../../model/labels.txt`,
`--model-path ../../model/fixture.bin`, `--output result.jpg`. Labels are person, helmet,
vest in that order. The CLI validates label count before the fixture runtime guard.
The wrapper splits a flat output into records of `5 + classes_num` values; this is
only structural parsing, not verified YOLO decoding or inference. See
[the local integration report](integration.md) for missing runtime evidence.
