# Cross-platform and comparison gaps

Run: `behavior-2026-09-17-codex-01450-auth-blocked`

The Pack metadata says the maintenance branch is `rdk_x5`. That metadata was kept separate from the platform named by an individual case; it is not evidence that a case targeting X3 or RDK S runs on X5.

The machine-readable overlay in `cross-platform-cases.yaml` contains six platform-gap cases. Each is represented in all three variants in `cross-platform-results.jsonl` (18 additional planned records); these records are separate from the 75 core task cases (70 original plus five repository-integration cases) and are also `not-run`.

## Planned platform coverage

- X5 context: `zoo-eval-001`, `zoo-eval-006`, `integrate-eval-002`, and `validate-eval-002` explicitly name X5. Other cases inherit platform context only from their task fixture and are not reclassified here.
- X3 context: `zoo-eval-002` and `review-eval-002` explicitly name the historical `demos/` layout.
- RDK S context: `zoo-eval-003` names S600 with an S100 manifest value; `repo-eval-007` names an S-branch target; `release-eval-003` compares X5 and S registration.
- S100/S600 comparison: `zoo-eval-003` is a no-extrapolation case. Its fixture deliberately supplies only an S100 value while asking about S600.

## Gaps actually observed

- No authenticated Agent session was available. The one isolated Codex CLI probe returned HTTP 401 before a model turn, so the 75 full cases, 75 agents-only cases, and 75 no-Skill baseline cases are all `not-run`.
- No board or remote executor was exposed. X3, X5, S100, S100P, and S600 runtime behavior, performance, and hardware-specific path claims remain unverified.
- No real repository fixture was mounted into a case session. Platform labels above are task-definition contexts only; they do not establish that a runtime, model artifact, or board command exists.
- No full-versus-agents-only or full-versus-baseline behavioral comparison is available. A common auth blocker prevented all three variants equally; the result must not be read as a parity finding.
- No candidate/target cross-platform inference was made: the candidate Pack's `rdk_x5` maintenance metadata does not override the X3/RDK S contexts in the task files.

## Re-run gate

After an authenticated isolated Codex session is available, rerun every variant in a fresh session with the exact task-file hashes in `run-manifest.json`. Keep board-dependent assertions `not-run` unless the named board, command, model artifact, input, and output evidence are observed.

## Additional core cases

`repo-eval-011` checks an X3 target with Skills maintained on X5; `repo-eval-012` checks an explicit S600/X5 checkout conflict; `repo-eval-013` checks ambiguous current/historical manifests; `zoo-eval-011` checks legacy without a manifest; `zoo-eval-012` checks that aggregate S compatibility does not certify an S100P artifact. These were added after the failed probe and were not dispatched.
