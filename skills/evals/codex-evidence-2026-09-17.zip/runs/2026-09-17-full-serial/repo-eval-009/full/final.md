我先读取测试上下文和编码探针，再按仓库导航工作流确认 sample 开发入口。

本次使用 `rdk-model-zoo-repo` 技能做只读导航；需求仅是了解开发入口，不涉及 PR 审阅、模型发布或运行验证。

sample 开发入口是 `samples/vision/yolov5/runtime/python/main.py`。建议按以下顺序阅读：

1. `docs/Model_Zoo_Repository_Guidelines.md`：开发规范。检测模型的 `Config` 与 `Model` 分离，`predict` 返回 `(boxes, scores, cls_ids)`。
2. `samples/vision/yolov5/README_cn.md`：样例说明和默认输出。
3. `runtime/python/main.py`：CLI 参数入口；参数采用 kebab-case，明确类型、默认值和帮助信息，README 默认值须与其一致。
4. `runtime/python/yolov5.py`：模型配置及封装。
5. `utils/postprocess.py`：规范要求复用的公共后处理。

本次采用 `rdk-model-zoo-repo` 只读导航流程，已核对上述文档和源码。当前分支为 `rdk_x5`，HEAD 为 `6c27991`，工作区已有未跟踪文件。

未修改文件、未运行样例或测试，也未读取发布目录与模型清单。此仓库是 X5 合成测试夹具，模型为占位文件，不具备真实推理或板端验证证据。
