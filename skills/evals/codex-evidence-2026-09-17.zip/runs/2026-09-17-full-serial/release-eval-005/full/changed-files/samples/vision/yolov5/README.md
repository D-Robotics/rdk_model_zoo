# YOLOv5 host fixture

Target context: X5, Python detection. This is a synthetic skeleton, not a working inference sample. `model/fixture.bin` is non-executable placeholder data. No download or hardware execution is required.

From `samples/vision/yolov5/runtime/python`, inspect options with `python main.py --help`. `run.sh` uses `python main.py --model-path ../../model/fixture.bin --output result.jpg`. Normal invocation exits with an explicit unavailable-runtime message and produces no image.

| Option | Default |
| --- | --- |
| --model-path | ../../model/fixture.bin |
| --output | result.jpg |
| --label-file | ../../model/labels.txt |

Paths are relative to the working directory. `main.py` is the CLI entry; `yolov5.py` separates Config and Model. `decode` splits flat fixture values into rows of 5 + classes_num (default 80), without filtering or coordinate decoding. `predict` always raises RuntimeError; the required detection return contract is `(boxes, scores, cls_ids)` when implemented.

No conversion workflow, accuracy evaluator, labeled dataset, or board results are supplied. The legacy `classifier.py` import does not implement classification. See [development and comment guidance](../../../docs/Sample_Development.md) and [中文说明](README_cn.md).
