# 新增 sample 与注释约定

本文是本次开发说明；现行强制条款以 [目标仓库规范](Model_Zoo_Repository_Guidelines.md) 为准。下述补充建议不自动成为全仓门禁。

| 来源与适用范围 | 要求 | 本次落实 |
| --- | --- | --- |
| 目标规范：检测 Python，强制 | Config / Model 分离；predict 返回 (boxes, scores, cls_ids) | yolov5.py 分离配置；predict 尚未实现，明确抛错 |
| 目标规范：host 后处理，强制 | 复用 utils/postprocess.py | 当前不新增后处理；该 helper 仅复制行，不是 NMS |
| 目标规范：CLI，强制 | main.py；kebab-case；显式 type/default/help；README 默认一致 | 保留入口与参数，补齐双语说明 |
| 目标规范：分类 | 公共接口未定义 | 不制定分类返回接口 |
| 目标规范：robotics，强制 | Python 和 C++ 均需实现 | 本次 vision sample 不适用 |
| 本次注释约定，补充建议 | Python 公共模块、类、函数使用 Google-style docstring；C++ 公共接口建议 Doxygen | 为现有 Python 接口补文档；不新增 C++ 承诺 |

## 新增样例的交付步骤

1. 明确平台、模型变体、任务、语言/runtime、真实模型来源和验收范围；同名模型不能证明 I/O 相同。
2. 先描述 Config、Model、main.py、run.sh 的职责和输入输出，再实现功能。检测接口遵守上述返回约定，空输出也需保持约定形状。
3. 查找公共 utils 后再增加 helper。按真实职责提供 model、runtime、conversion、evaluator、test_data；不能用空目录、TODO 或占位模型声称功能完成。
4. 同步双语 README、入口与脚本默认值；新增或改名时更新已有索引。只有模型资产事实发生变化才同步 Manifest，无发版任务不更改版本、Tag 或发布状态。
5. host 逻辑变更先构造失败用例，再实现并验证；结构与文档检查不导入硬件 runtime。板测、精度、性能分别记录，未运行明确写出原因。

## 注释如何写

模块说明用途和运行边界；类说明职责与配置字段；公共方法按需要写 Args、Returns、Raises。张量接口说明形状、dtype、坐标系及空结果；未知内容明确标注，不能根据模型名称猜测。行内注释解释原因，不复述代码。未实现接口只描述当前实际异常及未来合同，不声称已有返回值。

## 当前 YOLOv5 的交付边界

X5 是上下文目标，不是已验证兼容性。现有 decode 只按 5 + classes_num 切分一维序列，类数要求为正；不进行坐标解码、阈值过滤或 NMS。predict 恒抛 RuntimeError。CLI 默认模型为测试占位文件，不能推理，不产生 result.jpg。

真实模型、I/O metadata、转换环境、数据集和硬件 runtime 均未提供。因此完整可运行 sample、转换复现、精度/性能验收尚未完成；本次仅完成开发说明与现有骨架注释。现有 evaluator/README.md 也明确没有评估实现。独立 review 未执行，作者自检不能替代独立评审。
