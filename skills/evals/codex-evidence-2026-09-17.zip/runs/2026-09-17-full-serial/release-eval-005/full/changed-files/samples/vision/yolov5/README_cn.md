# YOLOv5 host 测试骨架

目标上下文为 X5、Python 检测。这不是已完成的推理样例；`model/fixture.bin` 仅为不可执行的占位数据，不需要下载或访问设备。

在 `samples/vision/yolov5/runtime/python` 下运行 `python main.py --help` 查看参数。`run.sh` 使用 `python main.py --model-path ../../model/fixture.bin --output result.jpg`。普通启动会明确提示 runtime 不可用并退出，不会生成图像。

| 参数 | 默认值 |
| --- | --- |
| --model-path | ../../model/fixture.bin |
| --output | result.jpg |
| --label-file | ../../model/labels.txt |

相对路径基于当前工作目录。`main.py` 是入口；`yolov5.py` 将 Config 和 Model 分离。`decode` 仅按 5 + classes_num（默认 80 类）拆分一维测试值，不过滤、不解码坐标。`predict` 恒抛 RuntimeError；真实实现必须遵守 `(boxes, scores, cls_ids)` 检测返回约定。

未提供转换流程、精度评估器、标注数据集或板测证据。遗留的 `classifier.py` 导入不代表已实现分类。参见[新增 sample 与注释说明](../../../docs/Sample_Development.md)及 [English](README.md)。
