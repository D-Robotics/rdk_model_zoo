"""YOLOv5 host fixture interfaces; no hardware inference is implemented."""

from dataclasses import dataclass


@dataclass
class Config:
    """Configure the fixture decoder.

    Attributes:
        classes_num: Number of class values following five box/objectness values.
    """

    classes_num: int = 80


class Model:
    """Expose host row splitting and an explicitly unavailable inference entry."""

    def __init__(self, config):
        """Initialize the wrapper.

        Args:
            config: Decoder configuration with a positive class count.
        """
        self.config = config

    def decode(self, values):
        """Split flat fixture values into rows without decoding coordinates.

        Args:
            values: Sliceable flat sequence with rows of 5 + classes_num values.

        Returns:
            A list of row slices, or an empty list for empty input. No confidence
            filtering, NMS, or coordinate transformation is performed.

        Raises:
            ValueError: The sequence length does not contain complete rows.
        """
        width = 5 + self.config.classes_num
        if len(values) % width:
            raise ValueError('output class dimension mismatch')
        return [values[i:i + width] for i in range(0, len(values), width)]

    def predict(self, image):
        """Reject inference because this fixture has no executable runtime.

        Args:
            image: Input image, unused in this fixture.

        Raises:
            RuntimeError: Always. A real detection implementation must return
                (boxes, scores, cls_ids); this fixture produces no predictions.
        """
        raise RuntimeError('Fixture: no real runtime')
