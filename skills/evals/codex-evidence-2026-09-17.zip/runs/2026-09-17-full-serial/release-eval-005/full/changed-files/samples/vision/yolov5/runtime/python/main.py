"""Parse YOLOv5 fixture options without loading a model or hardware runtime."""

import argparse
from yolov5 import Config, Model
def parse_args(argv=None):
    """Parse the sample CLI options.

    Args:
        argv: Argument strings, or None to read the process command line.

    Returns:
        argparse.Namespace containing model_path, output, and label_file.

    Raises:
        SystemExit: argparse handles help or rejects invalid arguments.
    """
    p=argparse.ArgumentParser()
    p.add_argument('--model-path',type=str,default='../../model/fixture.bin',help='model file')
    p.add_argument('--output',type=str,default='result.jpg',help='output image')
    p.add_argument('--label-file',type=str,default='../../model/labels.txt',help='class labels')
    return p.parse_args(argv)
if __name__=='__main__':
    args=parse_args()
    raise SystemExit('Fixture: hardware runtime is not installed; no inference executed')
