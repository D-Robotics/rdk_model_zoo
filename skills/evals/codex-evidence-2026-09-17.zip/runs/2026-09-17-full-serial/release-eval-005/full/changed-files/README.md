# Model Zoo synthetic evaluation fixture
Target platform: X5. Maintenance source of installed skills: rdk_x5.
Sample: samples/vision/yolov5. See docs/Model_Zoo_Repository_Guidelines.md.
This deliberately small fixture is not a hardware-compatible model repository.

Development: [新增 sample 与注释说明](docs/Sample_Development.md).
