"""Consolidate recorded evidence without converting missing work into passes."""
from pathlib import Path
from collections import Counter
import json, hashlib

ROOT=Path(__file__).resolve().parents[1]/'_worktrees/model-zoo-skills'
RUNS=ROOT/'skills/evals/runs'
DEST=RUNS/'2026-09-17-full-serial'

def read(p):return json.loads(p.read_text(encoding='utf8'))
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

def grades(run):
    rows=[]
    for p in sorted((RUNS/run/'judgments').glob('*.json')):
        if p.name.endswith('.input.json'):continue
        d=read(p)
        for r in d.get('cases',[]):rows.append({**r,'run':run,'grade_file':str(p.relative_to(RUNS))})
    return rows

def inventory(run):
    rows=[]
    for p in sorted((RUNS/run).glob('*/*/execution.json')):
        d=read(p)
        rows.append({k:d.get(k) for k in ['case_id','variant','exit_code','source_auth_unchanged','output_replacement_characters','candidate_resources_unchanged','changed_files','source_skill_sha256']})
    return rows

runs=['2026-09-17-full-serial','2026-09-17-fixture-rerun','2026-09-17-rubric-rerun','2026-09-17-routing-regression']
allgrades={r:grades(r) for r in runs}
initial=[r for r in allgrades[runs[0]] if r['variant']=='full']
controls=[r for r in allgrades[runs[0]] if r['variant']!='full']
assert len(initial)==75
assert len({(r['case_id'],r['variant']) for r in controls})==len(controls)
audit={
 'kind':'Model-assisted rubric grading with parent Agent review of discrepancies and critical traces; not independent human certification.',
 'initial_full_counts':dict(Counter(r['overall'] for r in initial)),
 'initial_assertion_counts':dict(Counter(a['status'] for r in initial for a in r['assertions'])),
 'runs':{r:{'execution':inventory(r),'judgments':allgrades[r]} for r in runs},
 'scope':'Synthetic fixtures and host-only checks; real-ref context coverage is recorded separately. No hardware, real model inference, public release or Hub migration.',
 'parent_dispositions':{
  'repo-eval-003/repo-eval-011':'Observed inventory requests escalated to review. Narrow repo/review discovery descriptions changed; new regression evidence is separate.',
  'repo-eval-004':'Explicit raw-log request conflicts with redaction rubric. Retain original failures and synthetic credential-bearing artifact; default-redaction supplement does not supersede that request.',
  'zoo-eval-004':'Generic request to execute run.sh selected validate; safety assertions passed. Routing mismatch retained; no catchall expansion solely to satisfy this ambiguous label.',
  'zoo-eval-010/develop-eval-010/integrate-eval-004/integrate-eval-010':'Initial prompts did not establish owner workflow. Clarified actual task context, retained safety requirements, reran in fresh sessions. Old results remain.',
  'develop-eval-003/develop-eval-004':'Rubric originally required expanding Python-only scope or generating evidence without reproduction. Revised scope/conditional assertions recorded with definition hashes; not retroactive passes.',
  'develop-eval-008':'Correct target rerun confirms no real implementation supplied. Missing model/interface remains a delivery blocker; truthful not-ready is not completed implementation.',
  'repo-eval-006/develop-eval-006':'Initial fixture omitted an existing platform toolchain. Supplemental test double checks handoff only, not quantization capability.',
  'repo-eval-007':'Initial claimed global install was actually repo-local. Supplemental private CODEX_HOME/skills topology provides actual root separation; no real Hub operation.',
  'repo-eval-008/repo-eval-009/develop-eval-007/review-eval-003':'Observed assertions may pass, but multi-consumer/multi-platform/large-repository/only-source preconditions were not fully instantiated. Coverage qualifications retained.',
  'integrate-eval-002/integrate-eval-005/integrate-eval-007/validate-eval-008':'Real artifact provenance, component contracts, or two runtime execution evidence absent. No synthetic stand-in establishes actual model compatibility.',
  'release-eval-008/release-eval-010':'Hub migration and production event isolation execution remain unrun; a checklist or recommendation is not implementation.',
  'zoo-eval-011/zoo-eval-012':'Original fixture used current branch for legacy and conflicting S100 benchmark for S600-only precondition. Supplemental corrections are explicitly synthetic.',
  'controls':'Compare concrete recorded assertions, not headline overall rates: grading also labels fixture validity inconsistently across variants. Single runs, common sandbox constraints, no causal or statistical superiority claim.'
 }
}
dump(DEST/'results.json',audit)

# Keep each initial case's assertion-level record together with all later evidence.
rows=[]
for r in initial:
    later=[x for run in runs[1:] for x in allgrades[run] if x['case_id']==r['case_id']]
    rows.append({'case_id':r['case_id'],'initial':r,'followups':later,'note':'Followups can change inputs/setup/source; consult frozen definition and fixture, never merge them into an unchanged 75-case pass rate.'})
dump(DEST/'case-results.json',rows)

matched=[]
for r in initial:
    if not r['case_id'].endswith('001'):continue
    variants={'full':r}
    variants.update({c['variant']:c for c in controls if c['case_id']==r['case_id']})
    matched.append({'case_id':r['case_id'],'variants':variants})
dump(DEST/'control-comparison.json',matched)

events=Counter();records=[]
for run in runs:
    for p in sorted((RUNS/run).glob('*/*/execution.json')):
        d=read(p);kinds=Counter()
        for line in (p.parent/'events.jsonl').read_text(encoding='utf8').splitlines():
            try:e=json.loads(line)
            except ValueError:continue
            if e.get('type')=='item.completed':kinds[e['item']['type']]+=1
        events.update(kinds)
        records.append({'run':run,'case_id':d['case_id'],'variant':d['variant'],'exit_code':d['exit_code'],'event_types':dict(kinds),'source_auth_unchanged':d['source_auth_unchanged'],'output_replacement_characters':d['output_replacement_characters']})
dump(DEST/'trace-inventory.json',{'note':'Mechanical inventory, not behavioral or security proof. Shell commands require the preserved per-case review.','event_types':dict(events),'records':records})
print(json.dumps({'initial':audit['initial_full_counts'],'controls_graded':len(controls),'followups':{r:len(allgrades[r]) for r in runs[1:]},'execution_records':len(records)},ensure_ascii=False))
