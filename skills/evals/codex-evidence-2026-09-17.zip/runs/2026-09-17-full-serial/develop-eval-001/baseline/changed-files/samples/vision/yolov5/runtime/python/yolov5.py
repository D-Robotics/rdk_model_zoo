"""Host adapter for decoded YOLOv5 predictions; no device backend is bundled."""

from dataclasses import dataclass
from pathlib import Path
import sys

# Support the documented direct-script entry from runtime/python.
sys.path.insert(0, str(Path(__file__).resolve().parents[5]))
from utils.postprocess import select_boxes


@dataclass
class Config:
    classes_num: int = 80

    def __post_init__(self):
        if type(self.classes_num) is not int or self.classes_num <= 0:
            raise ValueError('classes_num must be a positive integer')


class Model:
    """backend(image) supplies flat decoded cx,cy,w,h,obj,class-prob rows.

    Coordinates remain in the backend's coordinate space. Raw device tensors,
    image preprocessing and coordinate rescaling require a real backend.
    """

    def __init__(self, config, backend=None):
        self.config = config
        self.backend = backend

    def decode(self, values):
        values = list(values)
        width = 5 + self.config.classes_num
        if len(values) % width:
            raise ValueError('output class dimension mismatch')
        return [values[i:i + width] for i in range(0, len(values), width)]

    def predict(self, image):
        """Return (boxes, scores, cls_ids), with xyxy boxes and zero-based IDs."""
        if self.backend is None:
            raise RuntimeError('Fixture: no real runtime; no inference executed')
        rows = select_boxes(self.decode(self.backend(image)))
        boxes, scores, cls_ids = [], [], []
        for row in rows:
            cx, cy, width, height, objectness = row[:5]
            cls_id = max(range(self.config.classes_num), key=lambda i: row[5 + i])
            boxes.append([cx - width / 2, cy - height / 2,
                          cx + width / 2, cy + height / 2])
            scores.append(objectness * row[5 + cls_id])
            cls_ids.append(cls_id)
        return boxes, scores, cls_ids
