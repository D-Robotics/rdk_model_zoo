# YOLOv5 detection sample (host fixture)

Target platform: X5. Python entry: `runtime/python/main.py`; adapter: `yolov5.py`.
From `samples/vision/yolov5/runtime/python`, run `python main.py --help`.
On a POSIX host, `sh run.sh --help` forwards arguments to that entry.

| CLI flag | Type | Default |
| --- | --- | --- |
| --model-path | str | ../../model/fixture.bin |
| --output | str | result.jpg |
| --label-file | str | ../../model/labels.txt |

Paths are relative to the runtime/python working directory. The shell wrapper
changes to that directory. Running without --help exits with an explicit runtime
unavailable message; no output image is generated.

`Config(classes_num=80)` and `Model(config, backend=None)` are separate.
An injected backend receives the image and returns flat, decoded rows of
`[cx, cy, width, height, objectness, class probabilities...]` in its own coordinate
space. `predict(image)` returns `(boxes, scores, cls_ids)` as three aligned lists:
xyxy boxes, objectness times maximum class probability, and zero-based class IDs.
Ties select the first class; empty input returns `([], [], [])`. Invalid row width
raises ValueError. Shared `utils/postprocess.py::select_boxes` is reused; this
fixture only preserves rows and does not implement thresholding or NMS.

Run host checks from the repository root: `python -m unittest discover -s tests -v`.
Tests use synthetic decoded values, not a model. `model/fixture.bin` is a
non-executable placeholder. No real preprocessing, device backend, raw-head
YOLO decoding, board execution, accuracy or performance validation is provided.
A real backend and verified model are required for deployment.
