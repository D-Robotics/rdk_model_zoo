# YOLOv5 检测样例（host 测试骨架）

目标平台：X5。Python 入口为 `runtime/python/main.py`，模型适配器为 `yolov5.py`。
在 `samples/vision/yolov5/runtime/python` 中运行 `python main.py --help`。
POSIX 环境可使用 `sh run.sh --help`，脚本切换到入口目录并转发参数。

| CLI 参数 | 类型 | 默认值 |
| --- | --- | --- |
| --model-path | str | ../../model/fixture.bin |
| --output | str | result.jpg |
| --label-file | str | ../../model/labels.txt |

相对路径以 runtime/python 工作目录为基准。不带 --help 执行时明确报运行时不可用，
不会生成输出图片。

配置 `Config(classes_num=80)` 与 `Model(config, backend=None)` 分离。
注入的 backend 接收 image，返回展平的已解码行：
`[cx, cy, width, height, objectness, 各类别概率...]`，坐标保持后端坐标系。
`predict(image)` 返回 `(boxes, scores, cls_ids)` 三个对齐列表：
xyxy 框、objectness 乘最大类别概率、从零开始的类别 ID。概率相同选首个类别。
空输入返回 `([], [], [])`；行宽不匹配抛出 ValueError。
复用 `utils/postprocess.py::select_boxes`，当前公共实现只保留输入行，不含阈值过滤或 NMS。

仓库根目录执行 host 测试：`python -m unittest discover -s tests -v`。
测试仅使用合成的已解码数值。`model/fixture.bin` 为不可执行占位文件，不能作为实际模型。
尚无实际预处理、设备后端、YOLO 原始输出头解码；板端推理、精度及性能均未运行。
部署需要真实后端和经过验证的模型。
