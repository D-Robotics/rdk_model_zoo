import argparse
if __package__:
    from .yolov5 import Config, Model
else:
    from yolov5 import Config, Model
def parse_args(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--model-path',type=str,default='../../model/fixture.bin',help='model file')
    p.add_argument('--output',type=str,default='result.jpg',help='output image')
    p.add_argument('--label-file',type=str,default='../../model/labels.txt',help='class labels')
    return p.parse_args(argv)
if __name__=='__main__':
    args=parse_args()
    raise SystemExit('Fixture: hardware runtime is not installed; no inference executed')
