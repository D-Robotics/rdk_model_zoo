import unittest
from unittest.mock import patch

from samples.vision.yolov5.runtime.python.main import parse_args
from samples.vision.yolov5.runtime.python.yolov5 import Config, Model


class TestDetection(unittest.TestCase):
    def test_tuple_and_coordinates(self):
        image = object()
        def backend(value):
            self.assertIs(value, image)
            return [10, 20, 4, 8, 0.5, 0.2, 0.8]
        self.assertEqual(Model(Config(2), backend).predict(image),
                         ([[8, 16, 12, 24]], [0.4], [1]))

    def test_empty(self):
        self.assertEqual(Model(Config(2), lambda _: []).predict(None),
                         ([], [], []))

    def test_dimension_mismatch(self):
        with self.assertRaisesRegex(ValueError, 'dimension mismatch'):
            Model(Config(2), lambda _: [0] * 6).predict(None)

    def test_config_validation(self):
        for value in (0, -1, 1.5, True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                Config(value)

    def test_missing_backend(self):
        with self.assertRaisesRegex(RuntimeError, 'no inference executed'):
            Model(Config()).predict(None)

    def test_shared_postprocessing(self):
        with patch('samples.vision.yolov5.runtime.python.yolov5.select_boxes',
                   return_value=[]) as select:
            self.assertEqual(Model(Config(1), lambda _: [0] * 6).predict(None),
                             ([], [], []))
            select.assert_called_once_with([[0] * 6])

    def test_cli(self):
        defaults = parse_args([])
        self.assertEqual(vars(defaults), {
            'model_path': '../../model/fixture.bin',
            'output': 'result.jpg', 'label_file': '../../model/labels.txt'})
        args = parse_args(['--model-path', 'custom.bin', '--output', 'out.jpg',
                           '--label-file', 'classes.txt'])
        self.assertEqual(vars(args), {'model_path': 'custom.bin',
                                     'output': 'out.jpg', 'label_file': 'classes.txt'})


if __name__ == '__main__':
    unittest.main()
