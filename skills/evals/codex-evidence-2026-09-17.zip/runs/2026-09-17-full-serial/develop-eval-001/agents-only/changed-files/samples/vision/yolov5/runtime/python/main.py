import argparse
import json
from yolov5 import Config, Model
def parse_args(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--model-path',type=str,default='../../model/fixture.bin',help='model file')
    p.add_argument('--output',type=str,default='result.json',help='host detection JSON output')
    p.add_argument('--label-file',type=str,default='../../model/labels.txt',help='class labels')
    p.add_argument('--classes-num', type=int, default=3, help='number of class scores per detection')
    p.add_argument('--host-input', type=str, default=None, help='JSON flat decoded detections for host-only validation; default: disabled')
    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    if args.host_input is None:
        raise SystemExit('Fixture: hardware runtime is not installed; no inference executed')
    with open(args.host_input, encoding='utf-8') as stream:
        values = json.load(stream)
    boxes, scores, cls_ids = Model(Config(args.classes_num)).postprocess(values)
    with open(args.output, 'w', encoding='utf-8') as stream:
        json.dump(dict(host_only=True, boxes=boxes, scores=scores, cls_ids=cls_ids), stream)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
