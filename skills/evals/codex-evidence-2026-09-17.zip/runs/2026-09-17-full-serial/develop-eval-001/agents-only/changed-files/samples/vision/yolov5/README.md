# YOLOv5 detection host sample

Entry: runtime/python/main.py. Adapter: runtime/python/yolov5.py. Target: X5.
The model is a non-executable placeholder; no board inference is implemented.

Config(classes_num=3) and Model(config, backend=None) are separate.
Model.predict(image) requires an injected callable backend and returns
(boxes, scores, cls_ids), three lists; empty output is ([], [], []).
The backend handles preprocessing, inference and raw YOLO head decoding,
returning flat rows [cx, cy, w, h, objectness, class scores...].
Each row has 5 + classes_num values. Boxes are xyxy in backend coordinates;
scores are objectness multiplied by the best class score.
Shared utils/postprocess.py select_boxes currently only copies rows:
no confidence filtering, NMS or original-image coordinate restoration.

CLI defaults (paths relative to current working directory):
- --model-path: ../../model/fixture.bin (reserved, unused in host mode)
- --label-file: ../../model/labels.txt (reserved, unused in host mode)
- --output: result.json
- --classes-num: 3 (matches supplied labels)
- --host-input: None (host mode disabled)

From the sample directory, create decoded.json containing
[10,20,4,6,0.5,0.1,0.8,0.1], then run:

```sh
python runtime/python/main.py --host-input decoded.json --output result.json
```

Output JSON includes host_only: true. Without --host-input the CLI fails
explicitly without inference. run.sh forwards arguments to main.py.
Host validation does not establish model correctness or board compatibility.
