from dataclasses import dataclass
from pathlib import Path
import sys

# Allow the documented direct script invocation from any working directory.
sys.path.insert(0, str(Path(__file__).resolve().parents[5]))
from utils.postprocess import select_boxes


@dataclass
class Config:
    classes_num: int = 3

    def __post_init__(self):
        if self.classes_num <= 0:
            raise ValueError('classes_num must be positive')


class Model:
    """Adapter for a backend returning flat decoded xywh/objectness/class rows.

    A backend must perform preprocessing, inference and raw YOLO head decoding.
    No board backend or executable model is supplied in this fixture.
    """

    def __init__(self, config, backend=None):
        self.config = config
        self.backend = backend

    def decode(self,values):
        width=5+self.config.classes_num
        if len(values)%width: raise ValueError('output class dimension mismatch')
        return [values[i:i+width] for i in range(0,len(values),width)]

    def postprocess(self, values):
        boxes, scores, cls_ids = [], [], []
        for row in select_boxes(self.decode(values)):
            x, y, width, height, objectness = row[:5]
            cls_id = max(range(self.config.classes_num), key=lambda i: row[5+i])
            boxes.append([x-width/2, y-height/2, x+width/2, y+height/2])
            scores.append(objectness * row[5+cls_id])
            cls_ids.append(cls_id)
        return boxes, scores, cls_ids

    def predict(self,image):
        if self.backend is None:
            raise RuntimeError('Fixture: no real runtime; inject a backend explicitly')
        return self.postprocess(self.backend(image))
