# YOLOv5 检测 host 样例

入口 runtime/python/main.py；接口 runtime/python/yolov5.py；目标平台 X5。
模型是不可执行占位文件，没有板端推理实现。
Config(classes_num=3) 与 Model 分离，三个类别对应提供的标签。
predict(image) 需要显式注入后端，返回 (boxes, scores, cls_ids) 三个列表；
空结果为 ([], [], [])。后端负责预处理、推理、原始 YOLO 输出解码，
返回展开的 [cx, cy, w, h, objectness, 各类别分数...]，每行 5+classes_num 个数。
框为后端坐标系的 xyxy，分数为 objectness 乘最大类别分数。
复用 utils/postprocess.py 的 select_boxes，目前只复制行；没有阈值过滤、
NMS 或原图坐标还原。未注入后端时 predict 明确报错。

CLI 默认值：
- --model-path：../../model/fixture.bin（预留，host 模式不读取）
- --label-file：../../model/labels.txt（预留，host 模式不读取）
- --output：result.json
- --classes-num：3
- --host-input：None（默认禁用 host 输入）

路径相对当前工作目录。在样例目录创建 decoded.json，内容为
[10,20,4,6,0.5,0.1,0.8,0.1]，执行：

```sh
python runtime/python/main.py --host-input decoded.json --output result.json
```

输出标记 host_only: true。不传 --host-input 时明确退出，不执行推理。
run.sh 转发参数到 main.py。host 验证不代表模型正确性或板端兼容性。
