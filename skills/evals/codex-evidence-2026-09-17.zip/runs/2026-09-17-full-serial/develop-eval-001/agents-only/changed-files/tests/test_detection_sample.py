import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'samples/vision/yolov5/runtime/python'
sys.path.insert(0, str(RUNTIME))
from yolov5 import Config, Model
from main import parse_args

class TestDetectionSample(unittest.TestCase):
    def test_predict(self):
        image = object()
        def backend(value):
            self.assertIs(value, image)
            return [10, 20, 4, 6, 0.5, 0.1, 0.8, 0.1]
        self.assertEqual(Model(Config(), backend).predict(image),
                         ([[8, 17, 12, 23]], [0.4], [1]))

    def test_empty_and_errors(self):
        self.assertEqual(Model(Config(), lambda _: []).predict(None), ([], [], []))
        with self.assertRaises(ValueError):
            Model(Config()).postprocess([1, 2])
        with self.assertRaises(ValueError):
            Config(0)
        with self.assertRaises(RuntimeError):
            Model(Config()).predict(None)

    def test_cli(self):
        self.assertEqual(parse_args([]).output, 'result.json')
        self.assertEqual(parse_args([]).classes_num, 3)
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            work = Path(directory)
            (work / 'input.json').write_text('[]', encoding='utf-8')
            command = [sys.executable, '-X', 'utf8', str(RUNTIME / 'main.py')]
            result = subprocess.run(command + ['--host-input', 'input.json'], cwd=work,
                                    capture_output=True, text=True, encoding='utf-8')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads((work / 'result.json').read_text(encoding='utf-8')),
                             dict(host_only=True, boxes=[], scores=[], cls_ids=[]))
            result = subprocess.run(command, cwd=work, capture_output=True,
                                    text=True, encoding='utf-8')
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('no inference executed', result.stderr)

if __name__ == '__main__':
    unittest.main()
