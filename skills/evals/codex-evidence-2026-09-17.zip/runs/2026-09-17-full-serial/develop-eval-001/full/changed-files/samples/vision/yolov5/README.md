# YOLOv5 detection contract sample (synthetic X5 fixture)

This Python sample implements a host detection interface, not hardware inference.
`model/fixture.bin` is non-executable placeholder data; the manifest URL is
deliberately non-routable. No download, conversion, accuracy or performance claim
is made. A real model and verified runtime adapter are still required.

From `samples/vision/yolov5/runtime/python`:

```sh
python -B main.py --help
sh run.sh --classes-num 80
```

The second command exits nonzero with an explicit missing-runtime message and
does not write an image. `run.sh` changes to its own directory and forwards flags.

| Flag | Default |
|---|---|
| `--model-path` | `../../model/fixture.bin` |
| `--label-file` | `../../model/labels.txt` |
| `--output` | `result.jpg` |
| `--classes-num` | `80` |

Paths are relative to the runtime directory when using the commands above.
Output/model/label arguments reserve the CLI contract; this fixture does not
load those files or generate `result.jpg`.

`runtime/python/yolov5.py` separates `Config` and `Model`. A supplied backend
receives the image and returns decoded rows `[x1,y1,x2,y2,score,class_id]`, with
coordinates in the original image. `predict` validates rows, reuses
`utils/postprocess.py:select_boxes`, and returns `(boxes, scores, cls_ids)` as
equally sized Python lists. Empty output is `([], [], [])`. NumPy is not required;
these lists do not expose ndarray shapes. The shared fixture helper only copies
rows: it does not implement NMS. Raw tensor decoding, preprocessing, thresholding,
NMS and coordinate restoration belong to the future verified runtime adapter.
`decode` only groups flat raw values by `5 + classes_num`; it is not that adapter.

Host verification from repository root:

```sh
python -B -m unittest discover -s tests
```

Tests use synthetic backend rows and cover empty/nonempty tuples, invalid rows,
class dimensions, missing runtime and CLI defaults. Conversion and evaluator
implementation are unavailable because real model metadata and datasets are absent.
