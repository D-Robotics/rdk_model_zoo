"""CLI entry for the synthetic detection sample; inference is unavailable."""

import argparse
from yolov5 import Config, Model
def parse_args(argv=None):
    """Parse optional CLI argument strings and return an argparse namespace."""
    p=argparse.ArgumentParser()
    p.add_argument('--model-path',type=str,default='../../model/fixture.bin',help='model file')
    p.add_argument('--output',type=str,default='result.jpg',help='output image')
    p.add_argument('--label-file',type=str,default='../../model/labels.txt',help='class labels')
    p.add_argument('--classes-num',type=int,default=80,help='number of detection classes')
    return p.parse_args(argv)
if __name__=='__main__':
    args=parse_args()
    config = Config(classes_num=args.classes_num)
    raise SystemExit('Fixture: hardware runtime is not installed; no inference executed')
