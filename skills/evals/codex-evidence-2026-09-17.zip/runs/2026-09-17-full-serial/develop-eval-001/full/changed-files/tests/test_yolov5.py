"""Host contract checks; no model or device is loaded."""

import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

RUNTIME = Path(__file__).resolve().parents[1] / 'samples/vision/yolov5/runtime/python'
sys.path.insert(0, str(RUNTIME))
from yolov5 import Config, Model


class TestDetection(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(Model(Config(), backend=lambda image: []).predict(None),
                         ([], [], []))

    def test_tuple_and_shared_helper(self):
        rows = [[1, 2, 3, 4, 0.9, 1]]
        with patch('yolov5.select_boxes', return_value=rows) as select:
            result = Model(Config(), backend=lambda image: rows).predict('image')
        self.assertEqual(result, ([[1, 2, 3, 4]], [0.9], [1]))
        select.assert_called_once_with(rows)

    def test_invalid_rows(self):
        for row in ([1, 2], [1, 2, 3, 4, 2, 0],
                    [3, 2, 1, 4, .9, 0], [1, 2, 3, 4, .9, 80],
                    [1, 2, 3, 4, float('nan'), 0]):
            with self.subTest(row=row), self.assertRaises(ValueError):
                Model(Config(), backend=lambda image: [row]).predict(None)

    def test_no_runtime(self):
        with self.assertRaisesRegex(RuntimeError, 'runtime'):
            Model(Config()).predict(None)

    def test_config_and_decode(self):
        with self.assertRaises(ValueError):
            Config(classes_num=0)
        model = Model(Config(classes_num=2))
        self.assertEqual(model.decode(list(range(7))), [list(range(7))])
        with self.assertRaises(ValueError):
            model.decode([1])

    def test_cli_defaults(self):
        spec = importlib.util.spec_from_file_location('detection_main', RUNTIME / 'main.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        args = module.parse_args([])
        self.assertEqual(args.classes_num, Config().classes_num)
        self.assertEqual(args.output, 'result.jpg')


if __name__ == '__main__':
    unittest.main()
