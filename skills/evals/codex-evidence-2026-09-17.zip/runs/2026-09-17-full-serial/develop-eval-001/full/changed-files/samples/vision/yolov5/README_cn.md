# YOLOv5 检测接口样例（X5 合成测试仓库）

本样例完成 Python host 检测接口，不提供硬件推理。
`model/fixture.bin` 是不可执行占位数据，Manifest 下载地址不可用；
未下载模型、未转换，也没有精度或性能结论。真实部署仍需模型与验证过的 runtime 适配器。

在 `samples/vision/yolov5/runtime/python` 下运行：

```sh
python -B main.py --help
sh run.sh --classes-num 80
```

第二条命令明确报告缺少 runtime，以非零状态退出，不生成图片。
`run.sh` 自动进入脚本目录并透传参数。

| 参数 | 默认值 |
|---|---|
| `--model-path` | `../../model/fixture.bin` |
| `--label-file` | `../../model/labels.txt` |
| `--output` | `result.jpg` |
| `--classes-num` | `80` |

以上命令的相对路径以 runtime 目录为基准。模型、标签和输出参数保留入口约定；
当前不会读取这些文件或生成 `result.jpg`。

`runtime/python/yolov5.py` 分离 `Config` 与 `Model`。注入的 backend 接收图像，
返回已解码的 `[x1,y1,x2,y2,score,class_id]` 行，坐标对应原图。
`predict` 校验行内容、复用 `utils/postprocess.py:select_boxes`，返回
`(boxes, scores, cls_ids)` 三个等长 Python 列表，空结果为 `([], [], [])`。
无需 NumPy，列表不具有 ndarray 的 shape 属性。公共测试 helper 仅复制行，不执行 NMS。
预处理、原始张量解码、阈值过滤、NMS 与坐标还原仍需真实 runtime 适配器实现并验证。
`decode` 仅按 `5 + classes_num` 将原始一维数据分行，不是推理解码器。

在仓库根目录执行 host 测试：

```sh
python -B -m unittest discover -s tests
```

测试使用合成 backend 输出，覆盖空/非空 tuple、非法行、类别维度、缺少 runtime 和 CLI 默认值。
缺少真实模型元数据和数据集，因此未实现 conversion 与精度 evaluator。
