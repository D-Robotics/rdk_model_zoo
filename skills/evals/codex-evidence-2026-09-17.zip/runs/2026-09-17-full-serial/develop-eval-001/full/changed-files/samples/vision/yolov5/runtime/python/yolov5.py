"""Detection contract for the synthetic X5 sample; no hardware adapter included."""

from dataclasses import dataclass
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[5]))
from utils.postprocess import select_boxes


@dataclass(frozen=True)
class Config:
    """Detection configuration.

    Attributes:
        classes_num: Number of valid class IDs, starting at zero.
    """

    classes_num: int = 80

    def __post_init__(self):
        if type(self.classes_num) is not int or self.classes_num <= 0:
            raise ValueError('classes_num must be a positive integer')


class Model:
    """Host wrapper with an explicitly supplied decoded-detection backend."""

    def __init__(self, config, backend=None):
        """Initialize without loading any model.

        Args:
            config: Detection Config.
            backend: Optional callable returning rows of x1,y1,x2,y2,score,class_id
                in original-image coordinates. Raw YOLO tensors are not accepted.
        """
        self.config = config
        self.backend = backend

    def decode(self, values):
        """Group flat raw rows by 5 + class count; does not decode boxes.

        Args:
            values: Flat sequence of raw prediction values.

        Returns:
            Raw rows, separate from the decoded backend contract.

        Raises:
            ValueError: The class dimension does not match the configuration.
        """
        width = 5 + self.config.classes_num
        if len(values) % width:
            raise ValueError('output class dimension mismatch')
        return [values[i:i + width] for i in range(0, len(values), width)]

    def post_process(self, rows):
        """Validate decoded rows and apply the shared fixture selector.

        Args:
            rows: Sequence of six-value decoded detection rows.

        Returns:
            Tuple of Python lists (boxes, scores, cls_ids); empty is ([], [], []).

        Raises:
            ValueError: A row has invalid coordinates, score, or class ID.
        """
        rows = list(rows)
        for row in rows:
            if len(row) != 6:
                raise ValueError('expected six values per decoded detection')
            x1, y1, x2, y2, score, cls_id = row
            if (not all(isinstance(v, (int, float)) and math.isfinite(v)
                        for v in row) or x2 < x1 or y2 < y1
                    or not 0 <= score <= 1 or int(cls_id) != cls_id
                    or not 0 <= cls_id < self.config.classes_num):
                raise ValueError('invalid decoded detection')
        selected = select_boxes(rows)
        return ([list(row[:4]) for row in selected],
                [row[4] for row in selected], [int(row[5]) for row in selected])

    def predict(self, image):
        """Run the supplied backend and return the detection tuple.

        Args:
            image: Input passed unchanged to the supplied backend.

        Returns:
            Tuple (boxes, scores, cls_ids) of equally sized Python lists.

        Raises:
            RuntimeError: No real runtime or host test backend was supplied.
        """
        if self.backend is None:
            raise RuntimeError('Fixture: no real runtime; supply a decoded backend')
        return self.post_process(self.backend(image))
