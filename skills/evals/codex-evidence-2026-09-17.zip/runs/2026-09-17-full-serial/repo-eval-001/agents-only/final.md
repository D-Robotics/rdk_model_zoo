我会先读测试上下文和编码探针，再根据仓库文件梳理目录、模型样例和开发入口。全程只在临时仓库内读取，不联网。


当前仓库是精简的合成测试夹具：目标平台为 X5，当前分支为 `feature/new`；README 中的 `rdk_x5` 指技能维护来源，不能当作当前分支。没有可用的 `rdk-model-zoo-repo` 技能，我会直接按仓库导览流程梳理，并核对样例入口与实际代码。


这个 fork 当前呈现的是**精简的合成测试仓库**，可以用来理解组织方式，但不是可直接上板推理的完整 Model Zoo。

主工作流为仓库导览（`rdk-model-zoo-repo`）；没有可用的对应技能，因此直接核对了文档与代码。

| 位置 | 用途与实际状态 |
|---|---|
| `README.md`、`VERSION` | 总入口；声明目标平台 X5，版本 `1.1.2` |
| `samples/vision/yolov5/` | 目标检测样例，包含说明、模型资产、Python 运行入口与评测目录 |
| `samples/classification/` | 极简分类示例；仓库尚未定义分类公共接口 |
| `utils/postprocess.py` | 共享 host 后处理；目前只复制输入列表或返回空列表 |
| `tests/test_postprocess.py` | 仅覆盖空输入的单元测试 |
| `docs/Model_Zoo_Repository_Guidelines.md` | 接口、CLI 和文档约定 |
| `docs/manifests/` | 模型目录及性能记录；本仓库内容均为测试数据 |
| `.github/workflows/` | 发布工作流骨架，目前只执行 `echo fixture` |
| `build/`、`logs/`、`runs/` | 构建及历史产物位置；目录存在不代表验证通过 |

理解 YOLOv5 样例时，建议按这条顺序阅读：

`README_cn.md` → `runtime/python/main.py` → `yolov5.py` → `utils/postprocess.py`

- `main.py` 是 CLI 入口，定义模型路径、输出文件和标签路径；`run.sh` 封装启动命令。
- `yolov5.py` 分开定义 `Config` 和 `Model`。规范要求 `predict` 返回 `(boxes, scores, cls_ids)`，但当前实现直接报错，没有真实推理。
- `model/fixture.bin` 是占位文件；`evaluator/` 只有说明，没有精度评测实现。性能清单里的 `42 FPS` 也是合成记录。

**分支与平台需分开理解**：当前分支是 `feature/new`；X5 来自 README 和模型清单；`rdk_x5` 在 README 中指技能维护来源，不是当前分支。

本次只读核对，未修改文件、未运行测试或推理、未联网。以上结论仅适用于当前临时仓库，不构成真实模型可用性或板端性能证据。
