我会先读取测试上下文，按实际观察范围核对支持列表；使用 `rdk-model-zoo-validate` 技能整理验收证据。

现有记录只声明 X5 / `yolov5-fixture` / Python detect 曾成功，且缺少命令、模型哈希和真实板端证据；另有一份无法关联到该次运行的维度不匹配日志。因此不能把整个支持列表标为通过。我会保存分范围报告，将尚未验证的项目保留为 `not-run`，并执行报告结构校验。

不能将整个支持列表标为通过。

- 使用 validation 工作流核对：仅有 X5 单变体 Python detect 的合成历史成功声明，缺少完整执行证据。
- 新增 [核验报告](runs/support-validation/README.md) 和 [验证矩阵](runs/support-validation/verification.json)，未覆盖项保持 `not-run`，未修改原支持声明。
- Host 报告结构及证据哈希校验通过，退出码 0；这不代表模型通过。
- 未联网、未运行占位模型或板测。C++、seg、其他权重和平台、精度与性能均不能据此判通过。
