我会先读取测试上下文和编码探针，再核对仓库对两个清单的引用及用途。

本次使用 `rdk-model-zoo-repo` 技能进行只读仓库核查，重点确认清单身份和实际选择依据。

目前**不能唯一确认“当前使用的清单”**：两个候选同时存在，身份不同，已读 README 和样例文件未明确指定使用哪一个。

| 清单 | 发布平台 | 版本 | source_ref |
|---|---|---|---|
| `docs/manifests/models.yaml` | X5 | 1.1.2 | fixture-base |
| `release/models.yaml` | S | 0.9.0 | historical-other |

前者与根 README 声明的 X5 一致；后者的发布平台为 S，但内部模型及 compatibility 仍标为 X5，存在身份冲突。不能仅凭 `rdk_x5` 分支名或目录惯例自动选定。

实际采用 `rdk-model-zoo-repo` 只读核查，仓库检查脚本成功运行；未修改文件、联网或执行模型/板测。上下文及模型均为测试占位数据。

你要确认的是 **X5 当前文档清单**，还是 **历史 release 清单**？
