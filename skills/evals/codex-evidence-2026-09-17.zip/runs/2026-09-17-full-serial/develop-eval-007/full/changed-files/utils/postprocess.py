def select_boxes(rows):
    """Return a shallow copy of the rows, including an empty input.

    Args:
        rows: Sliceable sequence of result rows.

    Returns:
        A full slice of rows preserving their order and contents.
    """
    return rows[:]
