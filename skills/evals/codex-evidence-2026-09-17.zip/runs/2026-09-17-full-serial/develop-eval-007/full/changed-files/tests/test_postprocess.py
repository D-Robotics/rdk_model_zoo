import unittest

from samples.classification.main import classify
from samples.vision.yolov5.runtime.python.classifier import (
    select_boxes as yolov5_select_boxes,
)
from utils.postprocess import select_boxes


class TestPostprocess(unittest.TestCase):
    consumers = (select_boxes, classify, yolov5_select_boxes)

    def test_empty(self):
        for consumer in self.consumers:
            with self.subTest(consumer=consumer.__module__):
                rows = []
                result = consumer(rows)
                self.assertEqual(result, [])
                self.assertIsNot(result, rows)

    def test_nonempty_preserves_rows_and_order(self):
        for consumer in self.consumers:
            for rows in ([[1, 2, 3, 4]], [[1, 2, 3, 4], [5, 6, 7, 8]]):
                with self.subTest(consumer=consumer.__module__, rows=rows):
                    expected = [row[:] for row in rows]
                    result = consumer(rows)
                    self.assertEqual(result, expected)
                    self.assertEqual(rows, expected)
                    self.assertIsNot(result, rows)
                    for actual, original in zip(result, rows):
                        self.assertIs(actual, original)
                    result.pop()
                    self.assertEqual(rows, expected)


if __name__ == "__main__":
    unittest.main()
