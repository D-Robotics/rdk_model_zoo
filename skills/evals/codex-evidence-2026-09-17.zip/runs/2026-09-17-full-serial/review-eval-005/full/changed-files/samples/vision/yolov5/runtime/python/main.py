"""CLI metadata for the fixture; no hardware inference is available."""
import argparse
def parse_args(argv=None):
    """Parse optional argument strings into the sample CLI namespace."""
    p=argparse.ArgumentParser()
    p.add_argument('--model-path',type=str,default='../../model/fixture.bin',help='model file')
    p.add_argument('--output',type=str,default='result.jpg',help='output image')
    p.add_argument('--label-file',type=str,default='../../model/labels.txt',help='class labels')
    p.add_argument('--classes-num',type=int,default=80,help='positive class count')
    args = p.parse_args(argv)
    if args.classes_num <= 0:
        p.error('--classes-num must be positive')
    return args
if __name__=='__main__':
    args=parse_args()
    raise SystemExit('Fixture: hardware runtime is not installed; no inference executed')
