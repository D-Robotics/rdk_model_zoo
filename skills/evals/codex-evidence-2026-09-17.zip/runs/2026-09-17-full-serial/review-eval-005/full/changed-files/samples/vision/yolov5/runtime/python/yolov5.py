"""Host adapter for decoded YOLOv5 rows, independent of device runtime."""
from dataclasses import dataclass
import math

from utils.postprocess import select_boxes


@dataclass(frozen=True)
class Config:
    """Detection settings.

    Attributes:
        classes_num: Positive number of class probabilities per row.
    """
    classes_num: int = 80

    def __post_init__(self):
        if type(self.classes_num) is not int or self.classes_num <= 0:
            raise ValueError('classes_num must be a positive integer')


class Model:
    """Parse host rows; this class does not load the fixture model.

    Args:
        config: Detection configuration.
        infer: Optional callable accepting the original image and returning a
            flat sequence of decoded cx, cy, w, h, objectness, class probabilities.
            Coordinates must already refer to the original image. The callable
            owns preprocessing, device execution and raw head decoding.
    """

    def __init__(self, config, infer=None):
        self.config = config
        self._infer = infer

    def decode(self, values):
        """Split flat decoded values into rows using the configured class count.

        Args:
            values: Flat numeric sequence, not raw feature maps or logits.

        Returns:
            List of rows of width 5 + classes_num.

        Raises:
            ValueError: The sequence contains an incomplete row.
        """
        width = 5 + self.config.classes_num
        if len(values) % width:
            raise ValueError('output class dimension mismatch')
        return [list(values[i:i + width]) for i in range(0, len(values), width)]

    def forward(self, image):
        """Return decoded rows from the injected inference callable.

        Args:
            image: Input owned by the inference callable.

        Returns:
            Flat decoded output sequence.

        Raises:
            RuntimeError: No inference callable was supplied.
        """
        if self._infer is None:
            raise RuntimeError('Fixture: no real runtime; supply an inference callable')
        return self._infer(image)

    def post_process(self, values):
        """Convert decoded rows to detection lists via the shared selector.

        Args:
            values: Flat decoded cx, cy, w, h, objectness, probabilities.

        Returns:
            Tuple of boxes (N rows of four xyxy coordinates), scores and class
            IDs (N entries each). Empty output is ([], [], []). The fixture
            selector preserves all rows; it does not implement NMS.

        Raises:
            ValueError: Values are nonfinite, dimensions negative or
                probabilities outside [0, 1].
        """
        rows = self.decode(values)
        for row in rows:
            if (not all(math.isfinite(value) for value in row)
                    or row[2] < 0 or row[3] < 0
                    or any(value < 0 or value > 1 for value in row[4:])):
                raise ValueError('invalid decoded detection values')
        boxes, scores, cls_ids = [], [], []
        for row in select_boxes(rows):
            cx, cy, width, height, objectness = row[:5]
            cls_id = max(range(self.config.classes_num), key=lambda i: row[5 + i])
            boxes.append([cx - width / 2, cy - height / 2,
                          cx + width / 2, cy + height / 2])
            scores.append(objectness * row[5 + cls_id])
            cls_ids.append(cls_id)
        return boxes, scores, cls_ids

    def predict(self, image):
        """Run the supplied backend and return boxes, scores and class IDs.

        Args:
            image: Input passed unchanged to the backend.

        Returns:
            Detection tuple as documented by post_process.
        """
        return self.post_process(self.forward(image))
