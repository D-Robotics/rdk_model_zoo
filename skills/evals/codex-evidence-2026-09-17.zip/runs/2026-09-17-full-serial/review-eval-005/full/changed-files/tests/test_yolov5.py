"""Host contract tests; no model or device is loaded."""
import unittest

from samples.vision.yolov5.runtime.python.yolov5 import Config, Model
from samples.vision.yolov5.runtime.python.main import parse_args


class TestModel(unittest.TestCase):
    def test_cli(self):
        self.assertEqual(parse_args([]).classes_num, 80)
        self.assertEqual(parse_args(['--classes-num', '2']).classes_num, 2)

    def test_custom_classes(self):
        self.assertEqual(Model(Config(classes_num=2)).decode([0] * 7), [[0] * 7])

    def test_invalid_classes(self):
        for value in (0, -1, True, 1.5):
            with self.assertRaises(ValueError):
                Config(classes_num=value)

    def test_bad_width(self):
        with self.assertRaises(ValueError):
            Model(Config(classes_num=2)).decode([0] * 8)

    def test_predict(self):
        model = Model(Config(classes_num=2), infer=lambda image: [10, 20, 4, 6, .8, .1, .9])
        boxes, scores, cls_ids = model.predict(object())
        self.assertEqual(boxes, [[8, 17, 12, 23]])
        self.assertAlmostEqual(scores[0], .72)
        self.assertEqual(cls_ids, [1])

    def test_empty(self):
        self.assertEqual(Model(Config(), infer=lambda image: []).predict(None), ([], [], []))

    def test_missing_runtime(self):
        with self.assertRaises(RuntimeError):
            Model(Config()).predict(None)

    def test_invalid_values(self):
        model = Model(Config(classes_num=1))
        for values in ([0, 0, -1, 2, .5, .5], [0, 0, 1, 2, float('nan'), .5]):
            with self.assertRaises(ValueError):
                model.post_process(values)
