# 开发与验证记录

- 目标：X5 / YOLOv5 fixture / Python detect；起始 HEAD
  `7a069c105c2bd2a92f1b525f1e6f77226f1c41ff`，在原分支开发，没有 PR 操作。
- 主流程：develop；验证采用 validate 的 host 范围。不是 PR review。
- 适用强制规则：`docs/Model_Zoo_Repository_Guidelines.md` 中 Config/Model
  分离、检测三元组、公共 select_boxes 复用、main CLI、kebab-case 与默认值同步。
- done：修正 decode 写死 80；实现注入回调、后处理、输入校验；同步双语文档。
  接口只接受已解码的原图坐标和概率，不推定 fixture.bin 的 I/O。
- done：先运行 `python -B -m unittest tests.test_yolov5 -v`，退出 1，
  7 项中 1 failure、4 errors；复现类别宽度、缺失实现及参数校验问题。
- done：实现后 `python -B -m unittest discover -v`，8 项通过，退出 0；
  随后补充 CLI 默认值/覆盖测试，最终同一命令 9 项通过，退出 0。
- done：`git -c core.excludesFile=NUL diff --check`，退出 0，无空白错误。
- done：`python -B samples/vision/yolov5/runtime/python/main.py --help`，退出 0。
- 公共工具未修改；现有分类消费者行为未改变，原有空结果测试保留并通过。
- not-run：真实预处理、检测头解码、模型加载、NMS、板端 smoke、精度、性能；
  没有可执行模型、真实 I/O metadata、runtime、设备或数据集，不能声明端到端完成。
- not-applicable：本次未更换模型、转换、发布或修改平台范围，未改 Manifest、
  evaluator、分类索引；目标规则不要求此 vision 样例交付 C++。
- 独立 review 未执行（用户禁止子代理）；这里只是作者自检。
- 环境限制：NumPy 未安装，未联网或安装依赖。rg 启动失败后使用 PowerShell
  文件枚举。首次 Git 默认读取全局 ignore 被权限拒绝；后续禁用全局配置。
