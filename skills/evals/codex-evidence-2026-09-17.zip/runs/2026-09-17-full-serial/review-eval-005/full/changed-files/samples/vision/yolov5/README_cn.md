默认入口 runtime/python/main.py；输出 result.jpg。模型文件只是测试占位，不能做推理。

Host 接口：仓库根目录位于 `sys.path` 时，从
`samples.vision.yolov5.runtime.python.yolov5` 导入 `Config, Model`。
`Model(Config(classes_num=2), infer=callback).predict(image)` 返回 Python
列表组成的 `(boxes, scores, cls_ids)`，空结果为 `([], [], [])`。
回调返回展平的已解码行 `[cx, cy, w, h, objectness, p0, ...]`，坐标必须
已映射回原图，概率须在 [0, 1]。回调负责图像预处理、真实推理和原始检测头
解码。这是明确的 host 适配接口，并非已验证的模型 metadata。
置信度为 objectness 乘最大类别概率；并列取首个类别。复用的公共
`utils.postprocess.select_boxes` 仅保留行，不执行 NMS 或阈值过滤。

CLI 默认值：`--model-path ../../model/fixture.bin`、`--output result.jpg`、
`--label-file ../../model/labels.txt`、`--classes-num 80`。CLI 仅校验参数并
报告 runtime 不可用，不生成图片或加载占位模型。Host 测试不依赖 NumPy。
在仓库根目录执行 `python -B -m unittest discover -v`。
