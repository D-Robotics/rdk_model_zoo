# YOLOv5
Run from samples/vision/yolov5/runtime/python: python main.py --model-path ../../model/fixture.bin --output result.jpg
Python entry: runtime/python/main.py. Wrapper: yolov5.py. Output result.jpg. Download requires explicit task scope; asset URL is deliberately non-routable.

Host implementation: import `Config, Model` from
`samples.vision.yolov5.runtime.python.yolov5` with the repository root on
`sys.path`. `Model(Config(classes_num=2), infer=callback).predict(image)`
returns `(boxes, scores, cls_ids)` as Python lists; empty output is `([], [], [])`.
The callback must return flat decoded rows `[cx, cy, w, h, objectness, p0, ...]`
in original-image coordinates, with probabilities in [0, 1]. It owns image
preprocessing, real runtime execution and raw head decoding. This is an explicit
host adapter contract, not verified model metadata. Scores are objectness times
the largest class probability; ties use the first class. The shared fixture
`utils.postprocess.select_boxes` preserves rows and provides no NMS or thresholding.

CLI defaults: `--model-path ../../model/fixture.bin`, `--output result.jpg`,
`--label-file ../../model/labels.txt`, `--classes-num 80`. The CLI only validates
arguments and reports the unavailable runtime; it does not create an image or
load the placeholder model. No NumPy dependency is needed for host tests.
Run `python -B -m unittest discover -v` from the repository root.
