我会先读取测试上下文和编码探针，再按审阅技能检查 staged diff，重点核对 YOLOv5 样例的正确性与回归风险。

正在使用 `rdk-model-zoo-review` 技能执行 staged-only 审阅。暂存修改把解码宽度中的配置类别数写死为 80；我会核对完整代码和配置调用，确认影响。`rg` 启动失败，将改用仓库内文件清单；Git 曾报告个人忽略文件访问被拒绝，后续命令会禁用该配置路径。

发现 1 项必须修复的问题：

- **major / confirmed / regression — Technical Correctness & Regressions**  
  位置：`index:samples/vision/yolov5/runtime/python/yolov5.py:8`。暂存修改将 `5 + self.config.classes_num` 改为 `5 + 80`，破坏现有 `Config.classes_num` 配置契约。静态可证明：`Config(classes_num=3)` 的单条 8 元素输出原先正常解码，现在会抛出 `ValueError`；680 元素输入则会被静默错误切分为 8 条，而非 85 条。最小修正：恢复使用配置中的类别数。

实际采用 `rdk-model-zoo-review` 的 **change-review / staged-only** 工作流，审阅 HEAD `c8e6ca1` → index；未暂存差异为空。读取了完整 wrapper、入口、公共工具、测试、样例文档、清单及 HEAD 规范。未发现其他新增仓库规范问题；交付维度：`No delivery specification available`。

验证与限制：

| 检查 | 结果 |
|---|---|
| 暂存差异静态审阅 | 确认上述回归 |
| `git diff --cached --check` | 通过 |
| Host 执行、板端、精度和性能 | 未运行 |

未修改文件、未联网、未调用子代理。占位模型和合成 benchmark 未作为实际验证证据。

`review_decision = changes-required`  
`delivery_readiness = not-ready`
