import argparse
from pathlib import Path
from yolov5 import Config, Model
def parse_args(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--model-path',type=str,default='../../model/fixture.bin',help='model file')
    p.add_argument('--output',type=str,default='result.jpg',help='output image')
    p.add_argument('--label-file',type=str,default='../../model/labels.txt',help='class labels')
    p.add_argument('--classes-num',type=int,default=None,help='class count; default: infer from label file')
    return p.parse_args(argv)

def build_model(args):
    labels = Path(args.label_file).read_text(encoding='utf-8').splitlines()
    labels = [label.strip() for label in labels]
    if not labels or any(not label for label in labels):
        raise ValueError('label file must contain one non-empty label per class')
    classes_num = len(labels) if args.classes_num is None else args.classes_num
    config = Config(classes_num=classes_num)
    if classes_num != len(labels):
        raise ValueError('class count does not match label file')
    return Model(config), labels

if __name__=='__main__':
    args=parse_args()
    model, labels = build_model(args)
    raise SystemExit('Fixture: hardware runtime is not installed; no inference executed')
