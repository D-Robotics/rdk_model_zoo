"""Host-only checks using synthetic values; never load model artifacts."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'samples/vision/yolov5/runtime/python'))
from main import build_model, parse_args
from yolov5 import Config, Model


class LocalInterfaceTests(unittest.TestCase):
    def args(self, *extra):
        return parse_args(['--label-file', str(ROOT / 'samples/vision/yolov5/model/labels.txt'), *extra])

    def test_metadata_contract(self):
        metadata = json.loads((ROOT / 'private/model-metadata.json').read_text(encoding='utf-8'))
        model, labels = build_model(self.args())
        self.assertEqual(labels, metadata['labels'])
        self.assertEqual(model.config.classes_num, metadata['classes'])
        batch, count, width = metadata['outputs']
        self.assertEqual(batch, 1)
        self.assertEqual(width, 5 + len(labels))
        row = [1., 2., 3., 4., .9, .1, .8, .1]
        decoded = model.decode(row * count)
        self.assertEqual(len(decoded), count)
        self.assertTrue(all(item == row for item in decoded))

    def test_explicit_count(self):
        model, _ = build_model(self.args('--classes-num', '3'))
        self.assertEqual(model.config.classes_num, 3)
        for count in ('80', '0', '-1'):
            with self.assertRaises(ValueError):
                build_model(self.args('--classes-num', count))

    def test_invalid_labels(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'private') as folder:
            path = Path(folder) / 'labels.txt'
            for content in ('', 'person\n\nvest\n'):
                path.write_text(content, encoding='utf-8')
                with self.assertRaises(ValueError):
                    build_model(parse_args(['--label-file', str(path)]))

    def test_decode_boundaries(self):
        model = Model(Config(classes_num=3))
        self.assertEqual(model.decode([]), [])
        with self.assertRaises(ValueError):
            model.decode([0.] * 7)
        self.assertEqual(len(Model(Config()).decode([0.] * 85)), 1)


if __name__ == '__main__':
    unittest.main()
