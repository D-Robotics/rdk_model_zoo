# 私人接口适配记录

目标：X5，samples/vision/yolov5，Python；仅本地实验，不提交、不发布。
基线提交：9c6f815ac81747cb2bf737537ed1e290d703ed21，分支 rdk_x5。
开始时已有未跟踪 .agents/ 和 EVAL_CONTEXT.md，保持原状。
工作流：rdk-model-zoo-integrate；不涉及 PR、量化或公开贡献交付。

## 接口证据

来源为 private/model-metadata.json 和目标样例源码。metadata 明确 synthetic=true、actual_runtime_verified=false；下表是夹具契约，未从真实模型提取。

| 项目 | 私有 metadata | 原样例 | 本次处理 |
|---|---|---|---|
| 类别 | 3 | Config 默认 80 | CLI 从标签数量生成 Config；显式 --classes-num 必须与标签一致 |
| 标签 | person, helmet, vest | labels.txt 相同 | 按原顺序读取；拒绝空文件和空标签 |
| 输出 | [1, 25200, 8] | 扁平序列按 5 + classes_num 拆行 | 三类配置按 8 拆行，host 合成输入验证 25200 行 |
| 输入名称/数量/shape/dtype/layout | 未提供 | predict 未实现 | 未知，未改预处理 |
| 输出名称、dtype、layout、量化参数 | 未提供 | decode 仅拆行 | 未验证真实节点次序、量化/反量化和解码语义 |
| runtime/格式 | custom.hbm 是占位文件 | fixture.bin 也是占位文件 | 不加载、不改后缀、不声称兼容 |

wrapper 的直接调用默认仍为 80 类；本地实验也可显式使用 Model(Config(classes_num=3))。
decode 接受扁平序列，不声称支持三维 runtime tensor。predict 仍抛出无真实 runtime 异常，尚不能返回规范要求的 (boxes, scores, cls_ids)。未虚构推理实现。

## 修改与验证

- runtime/python/main.py：新增 --classes-num（int，默认 None，即根据标签推导），通过 build_model 构建 Model/Config 并返回标签；原有路径默认值保持一致。
- runtime/python/yolov5.py：拒绝非正整数类别数。
- private/test_local_interface.py：仅本地 host 契约测试，临时文件限 private 目录。
- 未更改公共工具、索引、发布清单、模型字节或标签；未执行 Git 提交。

在 REPO_ROOT 执行，PYTHONIOENCODING=utf-8、PYTHONUTF8=1：

```text
python -B -m unittest private.test_local_interface tests.test_postprocess -v
```

实际结果：exit code 0，5 tests，OK。覆盖 metadata 三类/标签/输出长度、显式类别数与冲突、空标签、空输出及非法行宽、原有 80 类拆行和共享后处理空输入。
测试只使用合成浮点列表；无设备、模型执行、下载、安装或联网。

工具链产物状态：只有占位产物和夹具 metadata；转换/编译未执行，真实格式及兼容性未验证。
样例接入状态：本地类别配置与扁平输出接口 host 检查通过；数值一致性、精度、性能、真实 runtime 与板端验证均未运行。
继续真实接入需要可执行产物及完整 I/O/runtime 元数据、同输入浮点基线和实际设备证据。
