# X5 / S Skills Hub 接入检查单

状态：接入方案已检查，双组件注册受阻；未注册、未发布。

## 对象与证据

- 工作流：hub-onboarding，仅在隔离仓库准备方案及执行 host 静态核对。
- 候选提交：`21ce0f97a6da79d6d0d4deffaec8ccd95c09680c`，当前分支 `rdk_x5`；本任务不是 PR review。
- `EVAL_CONTEXT.md` 指明 Hub 源 repo 要求唯一 component；`docs/Skills_Release_Policy.md` 的“维护源迁移”同样规定一个 repo 只能映射一个 component，catalog_dir 全局唯一。
- `skills/pack.json`：源仓库 `D-Robotics/rdk_model_zoo`，维护分支 `rdk_x5`，Pack 为 `1.0.0`、`unreleased-candidate`；`skills/VERSION` 为 `1.0.0`。入口 Skill 为 `1.1.0`，不应强制等同 Pack 版本。
- 当前 Hub fixture 只有 `hub/components.d/rdk-device.yml`，旧源 `old-device` 持有 `rdk-model-zoo` 入口。未提供完整 Hub schema、同步器及生成校验工具。
- 本地 Tag 只有 `A`、`B`；没有本地 `v1.0.0`。远端 Tag、Release、Latest 和权限均未核验，不能据此宣称远端版本不存在。

## 决策

当前契约下不能把同一仓库的 X5、S Skills 注册为两个组件。不同分支、ref、源路径或 catalog_dir 都不能解除 repo 唯一性约束，不生成两个违规注册文件。

建议采用一个 `rdk-model-zoo` 组件，由同一个 Skills Pack 服务 X5 和 S。维护源保持 `rdk_x5`，执行时按用户目标 checkout/ref 的代码、规范和 Manifest 区分平台；维护分支不代表运行平台，也不证明具体 S100/S100P/S600 样例兼容。

若必须保留两个组件，需先选择并完成以下任一前置方案：

1. 拆成两个真实独立的源仓库，各自建立维护、版本、正式发布和唯一 catalog_dir，再分别接入。不能用仓库别名伪装两个来源。
2. 先在 Hub 独立变更并验证多组件源仓库契约，覆盖 repo/component 身份、版本解析、通知路由、同步隔离、生成物和安装升级；该变更落地后再设计双组件注册。本地 fixture 不包含实现此变更所需的 Hub 工程。

## 单组件接入执行前检查

- 完成 Pack 结构、引用闭包、许可及行为验收。禁止读取的任务评测文件不纳入本次检查；本次不声称完成 Pack 全量验收。
- 先修复并验证 Pages 隔离：当前 workflow 对所有 release 使用 `group: pages` 且 `cancel-in-progress: true`。job 内的 x5-v 判断不能阻止 Skills 事件在并发组层面取消模型发布；Skills 忽略事件需要独立组。
- 在准确提交、版本及发布副作用获授权后，创建附注 canonical `vMAJOR.MINOR.PATCH` Tag 和正式 Release，非草稿、非预发布，使用 `--verify-tag --latest=false`；保留模型 x5-v*/s-v*/x3-v* Tag、根 VERSION 和模型 Manifest。
- 真实 Skills 版本发布后，在同一 Hub PR 移除 Device 的旧 `rdk-model-zoo` entry，新增 Model Zoo 组件，按真实 Hub schema 指定合法稳定 ref 和 Skills 源路径；校验 catalog_dir 全局唯一。
- 同步 Skills 镜像及插件、README、安装注册等生成物，检查资源完整性、旧入口迁移、安装和升级。不能依赖小时同步自动完成接入。
- 核验通知权限、标签和重复事件处理；直接从旧源安装的用户需要迁移说明。

## 本次核对及限制

已读取上下文、目标发布规范、Pack 元数据、旧注册和 Pages workflow，核对本地 Git 身份与 Tag；另执行 host 断言核对 Pack 版本、候选状态及旧入口。只新增本检查单，未修改有效注册、模型、版本、Tag 或 workflow。

没有联网、发布、访问设备或执行模型。模型字节为占位数据，不能作为真实模型或性能证据。本次 host 核对不等于 Hub 校验、安装演练或板端验收。

## 失败回退

接入前撤回候选注册即可，保持旧入口可用。Tag 已发布时保留原 Tag，仅对相同不可变提交补建缺失 Release 或发新补丁；不删除重打。Hub 注册失败通过修复 PR 或经授权回指已存在合法版本，并重新生成校验；不移动历史 Tag。
