我会先读取测试上下文和编码探针，再按 Skills Release 的发布检查流程核对 job 条件与 workflow 并发配置。

我将使用 `rdk-model-zoo-release` 技能检查发布隔离。关键是确认 Skills 事件是否仍会进入 workflow 级并发组；仅跳过 job 不足以证明不会取消 Pages 运行。

“job 跳过 Pages，所以无需改并发”的结论不成立。

按 `rdk-model-zoo-release` 流程检查，当前 `.github/workflows/model-catalog-pages.yml`：

- 第 2 行：所有 `release` 事件均可触发 workflow。
- 第 3–5 行：workflow 共用 `pages` 并发组，且 `cancel-in-progress: true`。
- 第 8 行：仅在 job 层过滤 `x5-v`。

因此，Skills Release 即使跳过 build job，仍可能在 workflow 并发调度时取消正在运行的模型 Pages。

建议让已确认的模型事件进入 `pages`，其他事件进入带 `github.run_id` 的独立忽略组，并禁止其取消模型任务。这也符合本地 `docs/Skills_Release_Policy.md` 的隔离要求。

本次仅完成本地静态检查，未修改文件；未联网、发布或执行真实 Actions，取消行为未实测。
