我会先读取测试上下文和编码探针，再使用 `rdk-model-zoo-review` 技能审查目标样例及 A→B 差异；全程只读，不联网或调用设备。

发现 1 项必须修复的回归。

- **major / confirmed — Technical Correctness & Regressions**
  **位置：** B 的 [yolov5.py:8](D:/20_Dev_Projects/21_RDK_MODEL_ZOO/rdk_model_zooo_mccc/.skill-eval-work/rdk-full-bmo2w_ge/target/samples/vision/yolov5/runtime/python/yolov5.py:8)。
  **问题：** `decode()` 将输出宽度从 `5 + self.config.classes_num` 改为固定 `5 + 80`，使现有类别配置失效。
  **证据与影响：** 静态推导：`Config(classes_num=3)` 的单条输出长度应为 8；A 能正确拆分，B 会因 `8 % 85 != 0` 抛出异常。其他恰好整除 85 的输入还可能被错误拆分。
  **依据：** A 中已有的可配置类别接口；属于本次引入的功能回归。
  **最小修正：** 恢复按 `classes_num` 计算宽度，并验证非 80 类输入。

审查采用 `rdk-model-zoo-review` 的只读 `change-review` 流程，目标为 X5 / YOLOv5 / Python：

- base：`34f0354c13f1d1eca673a662701a5f566c89e304`
- head：`9edc8e03d66c7f906295f4e003d63c533d837ac5`
- merge-base 与 base 相同；非浅克隆，差异仅上述一行。
- 已检查完整样例文本、base 规范、公共工具、已有测试及模型和指标清单。仓库规范维度未发现新增问题；交付规格：`No delivery specification available`。

| 验证 | 结果 |
|---|---|
| Git 范围及完整源码静态审查 | 已完成，发现上述回归 |
| Host 测试 | 未运行；已有测试仅覆盖公共工具空输入 |
| 推理、精度、板端性能 | 未运行；无真实模型或设备 |

未修改文件、未联网、未调用子代理。占位模型和合成 FPS 记录均未作为有效验证证据。

**review_decision = changes-required**  
**delivery_readiness = not-ready**
