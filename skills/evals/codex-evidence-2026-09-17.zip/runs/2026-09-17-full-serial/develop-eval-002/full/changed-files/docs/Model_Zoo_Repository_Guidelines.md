# Approved target fixture rules
Detection Config and Model are separate. predict returns (boxes, scores, cls_ids).
Reuse utils/postprocess.py for host postprocessing; main.py is the CLI entry.
CLI flags use kebab-case with explicit type/default/help. README defaults must match main.py.
Classification public interface: not defined; proposals are not approved repository policy.
Candidate classification contract: [Classification Interface Proposal](Classification_Interface_Proposal.md). Status: proposal; not an active repository requirement.
Robotics delivery requires both Python and C++ implementations. A directory or placeholder is not an implementation.
No board execution or model correctness evidence is included in this fixture.
