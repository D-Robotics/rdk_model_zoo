# 分类公共接口提案 / Classification interface proposal

状态：proposal，待维护者确认；不是现行全仓规范或审查门禁。
Status: proposal pending maintainer confirmation; not active repository policy or a review gate.

## 来源与范围 / Basis and scope

目标规范 `Model_Zoo_Repository_Guidelines.md` 明确分类接口未定义。当前测试仓库为 X5，只有 YOLOv5 检测样例，其 `(boxes, scores, cls_ids)` 约定不能作为分类接口依据。本文件响应全仓格式需求，提出候选合同，不声称已有分类实现、真实模型或跨平台验证。

The target guidelines leave classification undefined. This X5 fixture contains only a YOLOv5 detection sample. Its detection tuple is not classification precedent. This document proposes a repository-wide contract without claiming an implementation or platform validation.

首版候选范围：单图、单标签图像分类的公开 `predict` 返回值。输入类型、色彩空间、尺寸、归一化及 runtime 由样例文档明确。批处理、多标签、分割、姿态、检测及模型原始 tensor 不在本合同范围内，不强制适配。

Initial scope: public `predict` results for single-image, single-label classification. Samples document input types, color order, dimensions, normalization and runtime. Batch, multilabel, segmentation, pose, detection and raw model tensors are outside this contract.

## 候选合同 / Proposed contract

Python 返回具名 `ClassificationResult`，含以下字段；具体共享类型所在模块在实施时确定，不要求各样例立即创建副本。C++ 使用对应具名结构。此处声明的是逻辑类型，不新增实现或强制双语言交付。

Python would return a named `ClassificationResult`; C++ would use an equivalent named structure. The shared implementation location remains an implementation decision. These are logical types, not implemented utilities or a requirement for dual-language delivery.

| 字段 / Field | Python | C++ | 语义 / Meaning |
|---|---|---|---|
| `class_ids` | ndarray, int64, shape `(K,)` | vector<int64_t>, size K | 从 0 开始的类别索引，与样例标签表对应 / Zero-based indices into the sample label map |
| `scores` | ndarray, float32, shape `(K,)` | vector<float>, size K | 与索引逐项对应的有限概率，范围 [0,1] / Corresponding finite probabilities in [0,1] |

- `C >= 1` 为模型类别数；`top_k` 默认为 5，接受正整数，`K = min(top_k, C)`。Python 拒绝 bool、非整数或非正数；C++ 在转换为无符号类型之前验证参数。无效输入是错误，不作为空结果成功返回。
- 按 score 降序，同分按 class ID 升序；ID 不重复。正常单标签分类总返回 K 项，不附加置信度阈值过滤。
- 分数来自完整 C 类的概率分布；返回 top-K 后不重新归一化，因此返回分数之和可以小于 1。类别标签文字由调用方通过版本明确的标签表解析，不另作必需返回字段。
- 模型输出为 logits 时，对完整类别轴使用稳定 softmax 一次；输出已经是概率时不再 softmax。样例依据模型输出合同声明分数来源、反量化责任和概率校验容差，不能根据数值范围猜测。NaN、Inf、非法 shape、标签数不匹配或无效概率应报告错误。
- Python 以 `ValueError` 表示输入或输出合同错误，runtime 失败保留可诊断异常；C++ 沿用目标 runtime 的显式错误返回约定，失败时结果无效。不得以零分、空数组或旧结果伪装成功。

English contract:

- With C >= 1 classes, `top_k` defaults to 5 and must be a positive integer; K = min(top_k, C). Reject Python booleans and invalid values; validate C++ arguments before unsigned conversion. Invalid input is an error, not a successful empty result.
- Sort by descending score, breaking ties by ascending class ID, with unique IDs. Return exactly K entries without confidence filtering.
- Scores come from the complete C-class distribution. Do not renormalize top-K scores. Resolve label strings through a versioned label map at the caller.
- Apply stable softmax once across all classes for logits; do not apply it to probabilities. Document output semantics, dequantization responsibility and probability validation tolerance from the model contract. Reject nonfinite values, invalid shapes, mismatched label counts and invalid probabilities.
- Use Python `ValueError` for contract violations and diagnostic exceptions for runtime failures. C++ follows the target runtime's explicit error convention; failed results are invalid. Never disguise errors as empty, zero-filled or stale successful results.

示意 / Illustration（非模型运行结果 / not inference evidence）：C=3，概率为 `[0.1, 0.6, 0.3]`，top_k=2，得到 `class_ids=[1,2]`、`scores=[0.6,0.3]`。

## 采纳与验证 / Adoption and verification

待维护者确认：适用任务与平台范围、具名返回结构、分数定义、默认 top_k、错误合同、共享类型归属和迁移时限。批准前不据此认定旧样例不合规，也不批量修改调用方；批准后再盘点分类生产者及消费者，为旧接口提供明确迁移说明，并更新正式规范。

Maintainers should confirm scope, result type, score semantics, default top_k, errors, shared type ownership and migration timing. Until adoption, this proposal does not make existing samples noncompliant. Inventory classification producers and consumers before implementation and document migration from existing interfaces.

实施时的 host 验收覆盖：C=1、top_k>C、非法 top_k、同分排序、dtype/shape、完整 softmax 与 top-K 不重归一化、非有限值和错误路径。真实 runtime、数值一致性及平台适配须另行验证。本文仅进行文档静态检查；没有执行上述实现测试、板测或精度/性能评估。

Future host checks should cover C=1, top_k>C, invalid top_k, tie ordering, dtype/shape, full softmax without top-K renormalization, nonfinite values and errors. Runtime behavior, numerical consistency and platform support need separate verification. Only static documentation checks were performed for this proposal; implementation, board, accuracy and performance tests were not run.
