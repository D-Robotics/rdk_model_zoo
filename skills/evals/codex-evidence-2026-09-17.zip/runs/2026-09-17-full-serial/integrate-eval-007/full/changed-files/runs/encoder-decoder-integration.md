# Encoder / decoder 接入核对

## 范围与结论

主流程：rdk-model-zoo-integrate；本次为私有模型组合接入，不是 PR review、发布或量化任务。
目标：X5，`samples/vision/yolov5`，分支 `rdk_x5`，HEAD
`72bea6d13c73f954652f8f6493a4b081b7c9c9c1`。上下文的 base/head 相同。
初始未跟踪内容为 `.agents/`、`EVAL_CONTEXT.md`。

工具链产物状态：未验证。测试上下文明示模型字节为不可执行占位物。
样例接入状态：阻断，已完成静态契约核对，尚未建立可执行流水线。

## 逐组件契约

| 组件 | 本地声明 | 已知运行位置 | 输入/输出契约 | 当前缺口 |
|---|---|---|---|---|
| encoder | `encoder.hbm` | BPU（声明） | 输入输出名称、数量、shape、layout、dtype 均未知 | 文件未找到；metadata 缺失；X5 runtime、编译器版本、格式兼容性和量化参数未知 |
| decoder | `decoder.onnx` | host ONNXRuntime（声明） | 输入输出名称、数量、动态维度、dtype 均未知 | 文件未找到；opset、provider、版本、与 encoder 的对应关系未知 |
| tokenizer | `tokenizer.json` | 未提供；通常需要 host 处理，待确认 | 编码/解码接口、词表、特殊 token 均未知 | 文件未找到；版本、词表与 decoder 的兼容关系未知 |
| 目标 wrapper | `runtime/python/yolov5.py` | fixture，无真实 runtime | 默认 80 类，按 `5 + classes_num` 切分扁平检测结果 | 这是检测框解码，不是声明的 ONNX decoder；`predict` 明确抛出无 runtime 错误 |

文件存在性分别以仓库根目录和 `private/` 为基准检查，详见
`encoder-decoder-preflight.json`。路径基准本身也需明确。
`private/custom.hbm` 没有被声明为 encoder，不能凭后缀或仅有一份 BPU 文件就替代它。
`private/model-metadata.json` 是 synthetic 的三类检测数据，输出 `[1,25200,8]`，
且 `actual_runtime_verified=false`；它不能充当 encoder 或 decoder metadata。
样例没有 export/conversion 实现可供核对，README 和 main 均明确无真实推理。

## 接线前必须确定

1. 流水线任务：encoder/decoder 如何服务于当前检测样例，输入与最终输出分别是什么。
2. encoder：输入色彩/归一化/布局，是否已被编译器吸收；每个输出的顺序、量化 scale/zero-point，反量化由谁承担。
3. 桥接：逐节点映射 encoder 输出到 decoder 输入，明确转置、类型转换、batch、序列长度与 host/BPU 数据拷贝责任。
4. decoder：首次调用与迭代调用的输入区别，attention mask、位置编码、KV cache 的名称/shape/dtype、初始化与更新方式（若适用）。
5. tokenizer：匹配词表与版本，BOS/EOS/PAD ID、padding/truncation、文本编码解码规则；停止条件、最大生成长度和采样策略（若适用）。不能默认这是某种特定生成模型。
6. 真实兼容产物及 metadata、可信来源/哈希、X5 runtime 版本、相同输入的浮点基线、预期输出与有依据的容差。

## 后续实现及验收

协议明确后再决定适配 wrapper 与 main 的方式，保留目标仓库规定的检测
`predict -> (boxes, scores, cls_ids)` 接口；若任务需要不同接口，先明确变更范围。
不将 `.hbm` 改后缀伪装为默认 `.bin`，不为缺失协议编造适配或量化代码。
已有真实兼容产物时直接接入；若确需转换，再准备独立工具链交接契约。

按同一个可复现输入逐层对照浮点 encoder、BPU encoder、桥接张量、host decoder
和最终结果，并单独检查 tokenizer、缓存更新及终止行为。容差尚未提供，因此未作数值判断。

实际检查仅为源码/文档阅读、JSON 解析、声明路径存在性及源文件 SHA-256。
未执行模型加载、host 推理、板端推理、精度或性能测试；没有安装依赖、联网或调用设备。
历史 `runs/previous-evidence.txt` 未修改，且不能证明本次接入。
运行源码保持不变；本次仅新增此报告和静态检查 JSON。
