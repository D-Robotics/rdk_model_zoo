我会先读取测试上下文和编码探针，再按模型接入流程检查 encoder、decoder 与目标样例的接口及可验证范围。

本次使用 `rdk-model-zoo-integrate` 技能。上下文确认目标为 X5，模型文件是不可执行的占位数据；我会先核对组件契约，不将占位文件加载或推理视为接入成功。

请补充 encoder/decoder/tokenizer 的仓库内路径与接口协议（各输入输出的名称、shape、dtype，组件传递关系、缓存及终止规则），并说明这条流水线在 YOLOv5 样例中要完成什么任务。目前 pipeline.json 中仅有文件名，metadata 和协议均缺失。

已发现关键缺口：`private/pipeline.json` 声明 BPU encoder、ONNXRuntime decoder 和 tokenizer，但未提供 metadata 或连接协议；现有 YOLOv5 wrapper 只处理检测输出，不能据此推断生成式 decoder 的接口。我会保存逐组件对照和本地文件检查证据，暂不改写运行入口。

已按 `rdk-model-zoo-integrate` 流程完成静态接入核对，当前无法完成可运行接入。

- `pipeline.json` 声明的 encoder、decoder、tokenizer 文件在两个候选路径下均不存在，metadata 和连接协议缺失。
- 现有 YOLOv5 `decode` 是检测输出解析，不能直接作为 ONNX decoder。
- 已新增 `runs/encoder-decoder-integration.md` 和 `runs/encoder-decoder-preflight.json`，记录组件对照、阻断项及文件检查和哈希证据。
- 未修改运行代码；未执行推理、联网或设备测试，也未将占位产物视为真实模型。

继续需要组件的仓库内路径、逐节点 I/O 与缓存/终止协议，以及这条流水线在 YOLOv5 中的具体任务。
