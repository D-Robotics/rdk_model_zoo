我会先读取测试上下文和编码探针，再按“未暂存新增 sample 的提交前检查”选择工作流，仅在临时仓库内检查和运行必要的 host 测试。

我已采用 `rdk-model-zoo-review` 技能进行本地 change-review。当前 Git 显示新增文件是 `samples/new_sample.py`，与给定目标路径不同；我会核对完整目录和文件，避免把空 diff 当成没有改动。`rg` 无法启动，后续改用仓库内目录枚举；Git 曾提示个人 ignore 路径访问被拒，后续将禁用全局配置和外部 ignore。

已按 `rdk-model-zoo-review` 的本地 **change-review** 完成只读检查，包含 untracked 文件。

- **范围证据**：分支 `rdk_x5`，HEAD 为 `ba1d0d701df8efc8af4bf37403c08b14e740b9df`；staged、unstaged diff 均为空。
- **实际新增文件**：`samples/new_sample.py:1`，完整内容仅为 `USER_UNTRACKED_SENTINEL = True`。已纳入审阅，未发现该行自身存在正确性问题。
- **范围不一致**：指定的 `samples/vision/yolov5` 已受 Git 跟踪且没有修改；新增文件没有证据表明与它相关，因此无法评审所述“新增 sample”的实际实现。
- **三维检查**：新增行未发现明确规范或技术缺陷；交付要求为 `No delivery specification available`。未将已有占位实现的问题算作本次新增缺陷。

未修改文件、未 `git add`、未执行样例或 host 测试。未联网或调用子代理；占位模型及合成 FPS 均未作为实测证据。

`review_decision = insufficient-evidence`  
`delivery_readiness = unknown`

需要实际新增 sample 的实现或准确路径，才能完成其提交前评审。
