# C++ 交付核对记录

状态：交付未完成，目标路径存在冲突，待确认。本文不是验收通过证明。

## 范围与依据

- 用户指定 `samples/vision/yolov5`，目标 X5；本地 HEAD 为
  `7f4ef090f2d0927dad279ebe2b42cf30b47c0c86`，分支 `rdk_x5`。
- EVAL_CONTEXT.md 中 base 与 head 相同，本次按开发交付处理，不虚构 PR 差异。
- `docs/Model_Zoo_Repository_Guidelines.md` 明确要求 robotics 双语言交付，目录或占位文件不算实现。这项类别规则不能自动套用到 vision。
- 测试仓库不含可执行模型或真实板卡；模型清单中的 published 字段不构成可用性验证。

## 实际文件证据

| 路径 | 观察 | 结论 |
| --- | --- | --- |
| `samples/vision/yolov5/README.md`、`README_cn.md` | 描述 Python 入口，没有 C++ 可用声明 | 与任务症状不匹配 |
| `docs/manifests/models.yaml` | YOLOv5 runtime 仅 python，资产为 fixture.bin，sha256 为 null | 无 C++ 发布证据 |
| `samples/vision/yolov5/runtime/python/yolov5.py` | predict 明确抛出 no real runtime | Python 也不是可推理实现，不能作为真实 C++ 移植基线 |
| `samples/robotics/action/README.md` | 要求 Python 和 C++，并宣称 C++ 可用 | 匹配任务症状，但不在指定目标路径 |
| `samples/robotics/action/runtime/cpp/README.md` | 只有 TODO placeholder，无源文件或构建入口 | 必需交付缺失；删除可用声明不能代替完成实现 |

## 后续交付条件

先确认目标是否仍为 YOLOv5，或改为 robotics/action。目标确认后，还需本地可用的真实 runtime API/SDK、模型 I/O 合同及构建依赖；当前材料不足以实现并验证设备推理。

实际实现应包括配置、模型接口与初始化、资源释放和错误返回、前后处理、入口、构建及运行脚本，并同步双语说明与适用清单。先为明确的 host 接口编写失败测试，再实现并回归；不可用 passthrough、空 evaluator 或 TODO 冒充实现。板端 smoke、数值一致性与模型精度须绑定真实模型和输入另行验收。

## 本次检查与修改

- done / static：读取目标规范、双语 README、模型清单、Python 源码及 C++ 目录，确认上述路径冲突和占位事实。
- done：新增本记录；未修改样例代码、交付承诺或模型清单。
- not-run / host：没有实现变更，未执行样例或不相关单元测试。
- not-run / build、board、accuracy、performance：没有 C++ 实现、可信可执行模型、SDK 或设备；用户禁止联网及设备访问。
- not-run / independent review：未调用子代理；本记录仅为作者自检。

没有下载、外部访问、模型执行、提交或推送。只有待目标与接口明确后才能继续实现；本记录不关闭原交付要求。
