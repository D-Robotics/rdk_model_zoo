默认入口 runtime/python/main.py；输出 result.jpg。模型文件只是测试占位，不能做推理。

在 samples/vision/yolov5/runtime/python 下运行：
```sh
python main.py --model-path ../../model/fixture.bin --label-file ../../model/labels.txt --classes-num 3 --output result.jpg
```
以上参数与 CLI 默认值一致。CLI 将类别数传入 Config；独立使用 Config 仍默认 80 类。标签顺序为 person、helmet、vest（类别 ID 0、1、2），必须与训练顺序一致；入口校验正整数类别数、标签数量和模型文件存在性。

当前 host 解码接口是展平的每行 5+类别数个值，三类别每行 8 个值。真实新产物还需确认输入尺寸、布局、类型与预处理，输出形状和顺序、anchors/strides、量化、解码及 NMS；不能仅靠改类别数适配不同 YOLO 导出格式。

可通过 --model-path 指定产物路径，但此隔离样例不加载或执行模型，会明确退出，不生成 result.jpg。占位文件不是实际模型；真实 X5 兼容性、推理、精度和性能均未验证。
仓库根目录 host 测试：python -m unittest discover -s tests -v。
