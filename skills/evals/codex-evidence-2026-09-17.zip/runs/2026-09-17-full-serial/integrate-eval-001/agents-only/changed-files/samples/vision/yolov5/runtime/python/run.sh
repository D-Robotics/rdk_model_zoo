#!/bin/sh
python main.py --model-path ../../model/fixture.bin --label-file ../../model/labels.txt --classes-num 3 --output result.jpg
