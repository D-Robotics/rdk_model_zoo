# YOLOv5
Run from samples/vision/yolov5/runtime/python: python main.py --model-path ../../model/fixture.bin --label-file ../../model/labels.txt --classes-num 3 --output result.jpg
Python entry: runtime/python/main.py. Wrapper: yolov5.py. Output result.jpg. Download requires explicit task scope; asset URL is deliberately non-routable.

The CLI defaults to 3 classes and passes this value into Config; standalone Config retains its 80-class default. Labels are ordered person, helmet, vest (IDs 0, 1, 2) and must match training order. Label count and positive class count are checked before runtime entry.

The host decoder accepts flat rows of 5 + classes_num values (8 for this sample). This is only the fixture's interface contract: a real export must separately confirm input shape/layout/dtype, preprocessing, output shapes/order, anchors/strides, quantization, decoding and NMS. Changing class count alone cannot adapt a different YOLO output format.

fixture.bin is a non-executable placeholder. --model-path can select a supplied artifact, but this fixture does not load or execute it; the CLI exits with an explicit no-inference message and creates no result.jpg. Real X5 artifact compatibility, inference, accuracy and performance remain unverified.

Host checks from repository root: python -m unittest discover -s tests -v
