import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / 'samples/vision/yolov5'
sys.path.insert(0, str(SAMPLE / 'runtime/python'))
from main import build_model, parse_args
from yolov5 import Config, Model


class TestYoloIntegration(unittest.TestCase):
    def args(self, *extra):
        return parse_args(['--model-path', str(SAMPLE / 'model/fixture.bin'),
                           '--label-file', str(SAMPLE / 'model/labels.txt'), *extra])

    def test_three_class_wiring_and_decode(self):
        model, labels = build_model(self.args())
        self.assertEqual(model.config.classes_num, 3)
        self.assertEqual(labels, ['person', 'helmet', 'vest'])
        rows = list(range(16))
        self.assertEqual(model.decode(rows), [rows[:8], rows[8:]])
        self.assertEqual(model.decode([]), [])
        with self.assertRaises(ValueError):
            model.decode(list(range(85)))

    def test_standalone_default(self):
        self.assertEqual(len(Model(Config()).decode(list(range(85)))[0]), 85)

    def test_invalid_class_count(self):
        for count in (0, -1):
            with self.subTest(count=count), self.assertRaises(ValueError):
                build_model(self.args('--classes-num', str(count)))

    def test_label_mismatch_rejected_before_model_creation(self):
        with patch('main.Model') as constructor:
            with self.assertRaises(ValueError):
                build_model(self.args('--classes-num', '80'))
            constructor.assert_not_called()

    def test_empty_label_and_missing_model(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            labels = Path(folder) / 'labels.txt'
            labels.write_text('person\n\nvest\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                build_model(self.args('--label-file', str(labels)))
            with self.assertRaises(ValueError):
                build_model(self.args('--model-path', str(Path(folder) / 'missing.bin')))


if __name__ == '__main__':
    unittest.main()
