import argparse
from pathlib import Path
from yolov5 import Config, Model
def parse_args(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--model-path',type=str,default='../../model/fixture.bin',help='model file')
    p.add_argument('--output',type=str,default='result.jpg',help='output image')
    p.add_argument('--label-file',type=str,default='../../model/labels.txt',help='class labels')
    p.add_argument('--classes-num',type=int,default=3,help='number of model classes (must match labels and output)')
    return p.parse_args(argv)

def build_model(args):
    config = Config(classes_num=args.classes_num)
    labels = Path(args.label_file).read_text(encoding='utf-8').splitlines()
    if len(labels) != config.classes_num or any(not label.strip() for label in labels):
        raise ValueError('label count must match classes-num, with no empty labels')
    if not Path(args.model_path).is_file():
        raise ValueError('model file does not exist')
    return Model(config), labels

if __name__=='__main__':
    args=parse_args()
    model, labels = build_model(args)
    raise SystemExit('Fixture: hardware runtime is not installed; no inference executed')
