#!/bin/sh
python main.py --model-path ../../model/fixture.bin --classes-num 3 --label-file ../../model/labels.txt --output result.jpg
