# YOLOv5
Run from samples/vision/yolov5/runtime/python: python main.py --model-path ../../model/fixture.bin --classes-num 3 --label-file ../../model/labels.txt --output result.jpg
Python entry: runtime/python/main.py. Wrapper: yolov5.py. Output result.jpg. Download requires explicit task scope; asset URL is deliberately non-routable.

The CLI defaults to 3 classes and passes that value to Config/Model. The reusable wrapper retains its 80-class default. Labels are ordered class IDs: 0=person, 1=helmet, 2=vest; the label count must match --classes-num. The fixture decoder expects flattened rows of 5 + classes_num values (8 for this sample); this is a host contract, not verified model output metadata.

All flags above show CLI defaults; paths are relative to the working directory. fixture.bin is a non-executable placeholder. The entry validates configuration then exits without inference. Real X5 integration still requires an executable model and verification of input preprocessing, output shapes/layout, quantization, anchors/strides, decoding and NMS on the target runtime. No accuracy or performance claim is made.

Host checks from repository root: python -m unittest discover -s tests -v
