from dataclasses import dataclass
@dataclass
class Config:
    classes_num: int = 80

    def __post_init__(self):
        if type(self.classes_num) is not int or self.classes_num <= 0:
            raise ValueError('classes_num must be a positive integer')
class Model:
    def __init__(self,config): self.config=config
    def decode(self,values):
        width=5+self.config.classes_num
        if len(values)%width: raise ValueError('output class dimension mismatch')
        return [values[i:i+width] for i in range(0,len(values),width)]
    def predict(self,image):
        raise RuntimeError('Fixture: no real runtime')
