默认入口 runtime/python/main.py；输出 result.jpg。模型文件只是测试占位，不能做推理。

在 samples/vision/yolov5/runtime/python 目录执行：
```sh
python main.py --model-path ../../model/fixture.bin --classes-num 3 --label-file ../../model/labels.txt --output result.jpg
```
以上参数均为 CLI 默认值，路径相对于工作目录。CLI 将类别数 3 传入 Config/Model；通用 wrapper 保留默认 80 类。标签按类别 ID 排列：0=person、1=helmet、2=vest，标签数量必须等于类别数，且不得为空。

host 解码约定为每行 5 + 类别数个值，三类时为 8；这不是实际模型输出元数据的验证。入口完成配置校验后退出，不执行推理。真实 X5 接入仍需可执行模型，并核验预处理、输出形状和布局、量化、anchors/strides、解码及 NMS；当前没有精度或性能证据。

仓库根目录 host 测试：`python -m unittest discover -s tests -v`。
