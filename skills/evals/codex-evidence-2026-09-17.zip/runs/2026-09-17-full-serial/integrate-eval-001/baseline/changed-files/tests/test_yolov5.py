import importlib.util
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'samples/vision/yolov5/runtime/python'
sys.path.insert(0, str(RUNTIME))
from yolov5 import Config, Model

spec = importlib.util.spec_from_file_location('yolov5_entry', RUNTIME / 'main.py')
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)


class TestYoloIntegration(unittest.TestCase):
    def args(self, *extra):
        return entry.parse_args(['--label-file', str(RUNTIME.parents[1] / 'model/labels.txt'), *extra])

    def test_three_class_cli_wiring_and_decode(self):
        model, labels = entry.build_model(self.args())
        self.assertEqual(labels, ['person', 'helmet', 'vest'])
        self.assertEqual(model.config.classes_num, 3)
        rows = [1, 2, 3, 4, .9, .1, .2, .7] * 2
        self.assertEqual(model.decode(rows), [rows[:8], rows[8:]])
        self.assertEqual(model.decode([]), [])
        with self.assertRaises(ValueError):
            model.decode([0] * 85)

    def test_mismatched_labels(self):
        with self.assertRaisesRegex(ValueError, 'label count'):
            entry.build_model(self.args('--classes-num', '80'))

    def test_invalid_class_count(self):
        for count in (0, -1, 3.5, True):
            with self.subTest(count=count), self.assertRaises(ValueError):
                Config(classes_num=count)

    def test_wrapper_default_compatibility(self):
        self.assertEqual(Model(Config()).decode([0] * 85), [[0] * 85])


if __name__ == '__main__':
    unittest.main()
