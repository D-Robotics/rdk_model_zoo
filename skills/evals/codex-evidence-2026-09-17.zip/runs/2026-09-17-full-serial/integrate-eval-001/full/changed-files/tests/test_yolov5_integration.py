"""Host-only checks; no model loading or device execution."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'samples/vision/yolov5/runtime/python'))
from main import build_model, parse_args
from yolov5 import Config, Model


class TestIntegration(unittest.TestCase):
    def test_metadata_contract(self):
        metadata = json.loads((ROOT / 'private/model-metadata.json').read_text(encoding='utf-8'))
        args = parse_args(['--label-file', str(ROOT / 'samples/vision/yolov5/model/labels.txt')])
        model, labels = build_model(args)
        self.assertEqual(labels, metadata['labels'])
        self.assertEqual(model.config.classes_num, metadata['classes'])
        batch, count, width = metadata['outputs']
        self.assertEqual(batch, 1)
        self.assertEqual(width, 5 + model.config.classes_num)
        row = [10, 20, 30, 40, 0.9, 0.1, 0.2, 0.7]
        decoded = model.decode(row * count)
        self.assertEqual(len(decoded), count)
        self.assertTrue(all(value == row for value in decoded))

    def test_bad_width(self):
        with self.assertRaises(ValueError):
            Model(Config(3)).decode([0] * 85)

    def test_empty(self):
        self.assertEqual(Model(Config(3)).decode([]), [])

    def test_legacy_config(self):
        self.assertEqual(len(Model(Config()).decode([0] * 85)[0]), 85)

    def test_invalid_classes(self):
        for value in (0, -1, True, 3.5):
            with self.assertRaises(ValueError):
                Config(value)

    def test_bad_labels(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            path = Path(directory) / 'labels.txt'
            for content in ('person\nhelmet\n', 'person\n\nvest\n'):
                path.write_text(content, encoding='utf-8')
                with self.assertRaises(ValueError):
                    build_model(parse_args(['--label-file', str(path)]))


if __name__ == '__main__':
    unittest.main()
