# YOLOv5
Run from samples/vision/yolov5/runtime/python: python main.py --model-path ../../model/fixture.bin --classes-num 3 --label-file ../../model/labels.txt --output result.jpg
Python entry: runtime/python/main.py. Wrapper: yolov5.py. Output result.jpg. Download requires explicit task scope; asset URL is deliberately non-routable.

The CLI defaults to 3 classes and validates the labels (person, helmet, vest).
Direct Config() callers retain the 80-class default; use Config(classes_num=3)
for this custom contract. decode() only splits flat rows of width 5 + classes_num;
it does not validate tensor axes or implement YOLO box decoding/NMS.
The entry point deliberately exits without inference. Neither model file is executable.
The custom .hbm is not installed as the default .bin: runtime compatibility is unknown.
See [integration evidence](INTEGRATION.md) for the I/O comparison and remaining blockers.
