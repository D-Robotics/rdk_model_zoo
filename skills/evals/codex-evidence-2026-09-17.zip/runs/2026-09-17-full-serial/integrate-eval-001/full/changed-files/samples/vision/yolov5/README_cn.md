默认入口 runtime/python/main.py；输出 result.jpg。模型文件只是测试占位，不能做推理。

从 runtime/python 目录运行：
```sh
python main.py --model-path ../../model/fixture.bin --classes-num 3 --label-file ../../model/labels.txt --output result.jpg
```
CLI 默认三类别，校验标签数量及非空内容，顺序为 person、helmet、vest。
直接使用 Config() 仍默认 80 类，自定义三类使用 Config(classes_num=3)。
decode() 仅按 5 + 类别数将扁平列表分行，不校验张量轴，不实现真实框解码或 NMS。
入口仍明确终止且不执行推理；未将兼容性未知的 private/custom.hbm 替换成默认 .bin。
输入输出核对、host 验证及限制见 [接入记录](INTEGRATION.md)。
