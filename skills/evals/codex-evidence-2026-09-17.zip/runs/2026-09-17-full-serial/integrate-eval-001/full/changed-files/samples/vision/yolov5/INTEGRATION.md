# 三类别私有模型接入记录

主工作流：rdk-model-zoo-integrate；本次是已有 sample 的私人接入，非 PR 审查、量化或公开模型发布。
目标为 EVAL_CONTEXT.md 指定的 X5，分支 rdk_x5，起始 HEAD
700884c1cf3f67d45fc31c463129354d9025e81c。初始未跟踪项为 .agents/ 和 EVAL_CONTEXT.md。
仓库是合成 fixture，模型字节不可执行。没有 export/conversion、真实 runtime、浮点模型或编译收据。

## I/O 对照

| 项目 | 源模型/产物证据 | sample 当前行为及处理 |
| --- | --- | --- |
| 架构、格式、目标 runtime | 用户称 YOLO；custom.hbm 只是文件名，metadata 没有架构版本或 runtime 证明 | wrapper 名为 YOLOv5；不能据此认定兼容 X5，也不改后缀或替换默认文件 |
| 输入名称、数量、shape、dtype、layout | 均未提供 | 无可执行预处理/推理，保持未知 |
| 色彩、缩放、归一化 | 未提供 | 不猜测或添加预处理 |
| 输出名称、数量、顺序 | metadata 只给 outputs=[1,25200,8]，未列节点 | 只能作为一个声明的 shape 核对，不能证明输出节点协议 |
| 输出 shape | 声明 [1,25200,8] | 3 类使行宽从默认 85 变为 8；host 验证 25200 行分割及内容保持 |
| 输出 dtype/layout、量化/反量化 | 未提供 | 不猜测 runtime 是否负责反量化 |
| 输出语义 | 8 与 5+3 一致；坐标编码、objectness、类别值是否 sigmoid、anchors/strides 均未知 | decode 仅分行；真实 YOLO decode/NMS 尚未验证 |
| 标签 | metadata: person, helmet, vest | 现有 labels.txt 已一致；CLI 加类别数及标签数量/非空校验 |

证据来源：private/model-metadata.json（synthetic=true，actual_runtime_verified=false）。
private/custom.hbm SHA-256：6a9554270f9f2193c3271d5559cb0bfa8f420de5cadb450e3c0ccd8f079649a4。
默认 fixture.bin SHA-256：c2af732645b5e96e34e96fad355ebcfe81bea86e548cef8afd0eeadc0ba95dfd。
这些哈希仅标识本地占位文件，不是发布校验和或兼容性证明。

## 修改与验证范围

保留 Config/Model 分离及 Config 的 80 类默认，CLI 默认三类并实际构造配置，run.sh 同步参数。
保留 predict 的 fixture 异常；没有伪造规定的 (boxes, scores, cls_ids) 推理结果。
未新增框筛选算法或改变 utils/postprocess.py；现有空结果测试仍纳入 host 回归。
标签与私有产物未修改，未改模型清单，也未改历史 runs/previous-evidence.txt。

从仓库根目录执行 host 测试：python -X utf8 -m unittest discover -s tests -v。
新增测试覆盖三类 metadata/标签/完整行数、错误行宽、空输出、80 类兼容、非法类别数和标签不匹配。
输入是 host 人造列表，并非模型输出；通过不代表模型数值正确。
本次执行结果记录于 runs/yolov5-integration-host.json，包含命令、时间、退出码、输出及相关文件哈希。

## 两项状态与剩余阻断

- 工具链产物：只有占位数据；未编译、未转换，真实架构、格式与 X5 runtime 兼容性未验证。
- 样例接入：完成类别配置及标签/行宽的 host 接线；真实部署未完成。
- 必需但未运行：同一可复现输入的浮点/工具链/样例数值对照、独立数据集精度、X5 板端 smoke 和性能。
  原因：缺少可执行模型、输入输出完整协议、浮点基线、数据集、接受容差与设备。

后续须提供真实模型及编译 metadata/收据，确认每个输入输出和反量化责任，再实现并验证实际前后处理。
旧日志不替代修改后的 sample 验证；本任务未联网、安装工具链或执行设备命令。
