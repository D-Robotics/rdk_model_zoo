"""Offline release checks; deliberately never read evaluation task definitions."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[3]
PACK = ROOT / 'skills'
errors = []

def check(ok, message):
    if not ok:
        errors.append(message)

manifest = json.loads((PACK / 'pack.json').read_text(encoding='utf-8'))
check(manifest['version'] == (PACK / 'VERSION').read_text(encoding='utf-8').strip() == '1.0.0', 'Pack version')
members = manifest['skills']
check(len(members) == 7, 'Seven members required')
for member in members:
    root = PACK / member['name']
    content = (root / 'SKILL.md').read_text(encoding='utf-8')
    version = re.search(r'^version: "([^"]+)"$', content, re.M).group(1)
    expected = '1.1.0' if member['name'] == 'rdk-model-zoo' else '1.0.0'
    check(version == member['version'] == expected, member['name'] + ': version')
    check((root / 'NOTICE.md').is_file(), member['name'] + ': NOTICE')
    for path in root.rglob('*.md'):
        for link in re.findall(r'\[[^\]\n]*\]\(([^\s)]+)\)', path.read_text(encoding='utf-8')):
            parsed = urlsplit(link)
            if parsed.scheme or link.startswith('#'):
                continue
            dest = (path.parent / unquote(parsed.path)).resolve()
            check(dest.is_relative_to(root) and dest.exists(), str(path.relative_to(ROOT)) + ': ' + link)
    for path in root.rglob('*.py'):
        ast.parse(path.read_text(encoding='utf-8'))
    for path in root.rglob('*.json'):
        json.loads(path.read_text(encoding='utf-8'))

workflow = (ROOT / '.github/workflows/model-catalog-pages.yml').read_text(encoding='utf-8')
check("group: ${{ startsWith(github.event.release.tag_name, 'x5-v') && 'pages' || format('pages-ignored-{0}', github.run_id) }}" in workflow, 'Pages group isolation')
check("cancel-in-progress: ${{ startsWith(github.event.release.tag_name, 'x5-v') }}" in workflow, 'Pages cancellation isolation')
check('types: [published]' in workflow, 'Published event filter')
check("if: startsWith(github.event.release.tag_name, 'x5-v')" in workflow, 'Model job filter')
snapshots = {}
for name in ('VERSION', 'docs/manifests/models.yaml', 'docs/manifests/benchmarks.yaml'):
    original = subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=ROOT)
    current = (ROOT / name).read_bytes()
    check(original.replace(b'\r\n', b'\n') == current.replace(b'\r\n', b'\n'), name + ': changed')
    snapshots[name] = hashlib.sha256(current).hexdigest()
result = dict(valid=not errors, errors=errors, skills_checked=len(members),
              model_file_sha256=snapshots, behavior_evaluated=False, board_verified=False,
              full_pack_validation=False, remote_checked=False,
              head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip())
output = json.dumps(result, ensure_ascii=False, indent=2)
(Path(__file__).parent / 'local-checks.json').write_text(output + '\n', encoding='utf-8')
print(output)
raise SystemExit(bool(errors))
