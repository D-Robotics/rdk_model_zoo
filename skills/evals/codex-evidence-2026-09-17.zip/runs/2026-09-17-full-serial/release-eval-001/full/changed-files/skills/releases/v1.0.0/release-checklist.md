# Skills v1.0.0 发布准备记录

状态：本地准备完成，发布验收未完成，未发布。此仓库为 synthetic fixture，没有真实外部服务或设备。

## 对象和身份

- 工作流：rdk-model-zoo-release / skills-release。
- 分支：rdk_x5；基线 HEAD：9acfea402cec50e785095f932926c27ec9fb2fec。
- 目标：Pack 1.0.0，附注 Tag v1.0.0；标题 RDK Skills v1.0.0。
- 当前工作区含本次未提交的 Pages 修复与发布准备文件；上述 HEAD 不是包含修复的最终发布提交。
- 初始未跟踪文件：.agents/、EVAL_CONTEXT.md；保留，不纳入发布。
- 模型版本仍为 x5-v1.1.2；根 VERSION 为 1.1.2；两个 Manifest 的 release.version 也为 1.1.2。
- 本地仅有 A、B 两个 lightweight fixture Tag，均指向上述 HEAD。本地不存在 v1.0.0 或 x5-v1.1.2 Tag；不能由此推断远端不存在。
- 远端 Tag、Release、原 Latest、权限、通知 App 和 Hub 状态：未读取、未知。未读取个人认证、未联网。

## 实际修改和证据

- Pages 仅接收 release.published；X5 模型事件保留 pages 并发组，其余事件使用含 run_id 的 pages-ignored 组且不取消任务。原模型 job 过滤保留。
- skills/VERSION、pack.json、CHANGELOG 保留候选状态，不伪造已发布状态。迁移技能为 1.1.0，其他六个为 1.0.0。
- 来源及许可见 skills/NOTICE.md 和各成员 NOTICE.md；本地文件存在不代表已完成上游逐文件迁移审计。
- `python -X utf8 skills/releases/v1.0.0/check_local.py`：退出 0，七成员版本、Markdown 本地引用闭包、成员 Python/JSON 语法、Pages 隔离表达式和模型文件不变检查通过。哈希见 local-checks.json。
- `python -X utf8 skills/tools/sync_references.py`：退出 0，valid=true，changed_files=[]，见 reference-sync.log。
- `git -c core.excludesFile=NUL diff --check`：退出 0。
- rg 启动失败，改用 PowerShell 枚举；首次 Git 自动读取全局 ignore 被环境拒绝，后续禁用系统/全局 Git 配置并指定空 excludesFile。

## 未满足项

- 未运行完整 Pack 验证器或完整单测：验证器会读取本任务禁止访问的评测定义；没有读取其内容。局部检查不等于完整验收。
- Agent 行为评测、独立镜像安装演练、上游迁移审计均未完成。仓库已有历史日志不作为此次运行证据。
- Pages 修改仅在工作区，尚未进入最终提交或线上工作流；没有 GitHub Actions 执行证据。
- 样例和占位模型未执行；没有模型正确性、数值、精度或硬件性能结论。
- 用户限定离线、临时仓库内操作，因此不能执行真实发布。没有为未验收的基线创建本地正式 Tag。

## 后续发布命令（仅记录，未执行）

先完成缺失验收、候选变更提交和真实提交身份复核，核对远端 v1.0.0 占用、旧模型 Tag 对象及原 Latest。确认 Pages 隔离已上线，并将版本记录整理为正式发布状态。由维护者确认最终提交和发布副作用后，才在真实授权环境中执行下列模板：

```powershell
git tag -a v1.0.0 <APPROVED_COMMIT_SHA> -m "RDK Skills v1.0.0"
git push origin refs/tags/v1.0.0
gh release create v1.0.0 --verify-tag --title "RDK Skills v1.0.0" --notes-file skills/releases/v1.0.0/notes.md --latest=false
```

先移除 notes.md 的候选状态说明并填入实际验收限制；正式 Release 必须非草稿、非预发布。发布后核对 Tag 类型及解引用提交、Release 正文首段 Component、draft=false、prerelease=false、模型 Latest 未改变、Skills 事件未取消模型 Pages。Release URL 与发布时间：未执行，无可提供值。

不在本任务修改 Hub 注册。若后续接入 Hub，另行在同一 Hub PR 中移除旧 Device 同名条目并添加 Model Zoo 组件，核对 catalog_dir、镜像和生成物；不能宣称小时同步会自动完成迁移。

## 失败恢复

尚未发布：修正候选后重新验收。Tag 已推而 Release 失败：保留 Tag，记录对象、提交和批准说明，只为同一身份补建缺失 Release。不得移动、删除或重打旧 Tag；已发布缺陷使用新补丁版本。Latest 意外变化需核对后经授权恢复原模型 Latest。
