Component: RDK Model Zoo Skills

# RDK Skills v1.0.0

发布说明候选；尚未发布。

- 首个独立 Skills Pack，包含模型查询、仓库定位、集成、开发、验证、评审和发布七个技能。
- Pack 版本为 1.0.0；迁移入口 rdk-model-zoo 为 1.1.0，其余六个技能为 1.0.0。
- 每个技能携带本地引用资源，保留来源和许可记录。
- 模型仍为 x5-v1.1.2；根 VERSION 与模型 Manifest 不变。

本次为隔离测试仓库的本地发布准备。行为验收、真实安装、远端 Release、Latest 和 Hub 同步均未验证；不包含模型或板测结论。
