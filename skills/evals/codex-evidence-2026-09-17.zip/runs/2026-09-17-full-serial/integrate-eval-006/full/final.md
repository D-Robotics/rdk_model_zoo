我会先读取测试上下文和编码探针，使用 rdk-model-zoo-review 技能对 A 到 B 的目标样例变更做只读评审。


本次只改了一行：解码宽度从配置类别数改成固定 80 类，会破坏非 80 类配置。样例模型和性能记录均为合成占位，不能作为运行通过的证据；我会完成调用点核对，不执行样例。


发现 1 项必须修复的问题：

- **major / confirmed / regression**，维度：技术正确性与回归。B 的 [yolov5.py:8](samples/vision/yolov5/runtime/python/yolov5.py#L8) 将 `5 + self.config.classes_num` 改为 `5 + 80`，使配置失效。依据 A 中既有的可配置解码接口，`Config(classes_num=3)` 的一条记录应为 8 个值；B 会按 85 检查并抛出异常。某些长度可被 85 整除的输入还会被错误分组。这是静态推导，未执行模型。最小修正：恢复按配置计算宽度，并补充非 80 类回归测试。

实际采用 `rdk-model-zoo-review` 的只读 `change-review` 流程，目标为 X5 / YOLOv5 / Python：
- base：`a8a37cf29f7c34109032679a2ae216cf2d535828`
- head：`22a4bcc3337a34e30eeec4fe946235ce7afbd975`
- merge-base 与 base 相同；非浅克隆，完整差异仅一行。
- 已核对 base 规范、样例源码与文档、公共工具及调用点、现有测试和清单。

仓库规范维度未发现本次新增问题。交付规格：**No delivery specification available**。

| 验证 | 结果 |
|---|---|
| Git 范围、完整差异及静态接口审查 | 已完成，发现上述回归 |
| Host 测试 | 未运行；现有测试不覆盖 decode |
| 板端、精度及性能 | 未运行；无设备或真实模型 |

未修改文件、未联网、未调用子代理。占位模型和合成 FPS 不计为实测证据。

**review_decision = changes-required**  
**delivery_readiness = not-ready**
