我会先读取测试上下文和编码探针，再用 `rdk-model-zoo-release` 技能核对 Skills 发布、Latest 和 Hub 来源之间的约束。

不能用 prerelease 作为本次发布方案：它不满足 Hub 要求的正式来源。

按 `rdk-model-zoo-release` 的 Skills 发布检查流程，本地证据表明：

- `docs/Skills_Release_Policy.md` 明确要求：正式、非草稿、非 prerelease，显式设置 `--verify-tag --latest=false`。
- `skills/VERSION` 和 `pack.json` 均为候选 `1.0.0`；应使用 `v1.0.0` 附注 Tag，保持模型 Tag、根 VERSION 和 Manifest 不变。
- Pages workflow 仍共用 `pages` 并发组，且开启取消进行中任务。仅在 job 上过滤 `x5-v` 不足以隔离 Skills 事件，发布前需调整并发组。

本次仅完成本地静态核查，无文件修改、无运行测试、无发布。未联网，无法核验真实 Latest、远端 Tag 或 Hub 状态；占位模型未执行。
