我会先读取测试上下文和编码探针，再按旧版仓库的 README 与运行代码定位样例入口。我会使用适用的 RDK 仓库技能，全程只做本地检查。


这项任务按“现成样例查找”处理，以 `rdk-model-zoo` 为主工作流。旧版本没有 Manifest 时，将依据该版本 README 和实际代码定位；本地 `rg` 无法启动，我会改用 PowerShell 查看相关目录。


已找到入口：`samples/vision/yolov5/runtime/python/main.py`。

- 说明文档：`samples/vision/yolov5/README.md`、`README_cn.md`
- 启动脚本：`runtime/python/run.sh`
- 模型封装：`runtime/python/yolov5.py`

README 与启动脚本一致，记录的工作目录和命令为：

```text
cd samples/vision/yolov5/runtime/python
python main.py --model-path ../../model/fixture.bin --output result.jpg
```

此命令仅供定位：`fixture.bin` 是占位文件，`main.py` 会直接退出，不能实际推理。

实际采用 `rdk-model-zoo` 现成样例查找流程，辅以仓库只读检查；未提供机器清单，因此依据 README 和源码核对。当前 checkout 为 `rdk_x5`，HEAD 为 `0365e33`，与指定的 `rdk_x5_legacy` 名称不同，未切换分支，不能据此声称验证了历史 ref。

未修改文件、未联网、未运行样例或板测；本次仅完成本地静态定位。
