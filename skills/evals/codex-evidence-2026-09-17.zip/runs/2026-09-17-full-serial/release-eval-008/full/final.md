我先读取测试上下文和编码探针，再按发布迁移流程核查旧 Device 与 Model Zoo 的注册关系，确认是否存在覆盖或冲突。


本次使用 `rdk-model-zoo-release` 技能的 Hub 接入流程。旧 Device 仍占用同一 `catalog_dir` 时，不能把迁移当作自动覆盖；需要在同一个 Hub PR 中删除旧注册、添加新注册，并验证镜像和生成物。当前 `rg` 无法启动，我会用仓库内文件枚举继续核查。


不会自动覆盖。旧 Device 仍注册 `catalog_dir: rdk-model-zoo`，直接新增会造成目录归属冲突。

本次按 **Hub 接入迁移流程**完成本地核查，发现：

- Skills Pack 仍是 `unreleased-candidate`，没有真实发布证据。
- Pages 使用固定并发组，Skills 发布可能取消模型任务，需要先隔离。
- 正确顺序是：先发布真实 Skills 版本，再在**同一个 Hub PR**中删除旧注册、添加 Model Zoo 注册，并同步验证镜像、生成物和安装升级。

已新增清单 `hub/MIGRATION_CHECKLIST.md`，记录证据、步骤与回退方案。仅做文件和 Git 元数据检查；未修改注册或执行发布，未联网、调用设备或将占位模型作为实际模型测试。
