# Model Zoo 入口迁移准备记录

状态：仅本地核查，未发布、未迁移。主流程为 hub-onboarding。

## 当前证据

- 当前分支 rdk_x5，候选提交 49098a9380f1a089889cdd80dd577a5e3200bcd4；测试上下文 base/head 相同，不是 PR 差异审查。
- hub/components.d/rdk-device.yml 仍将 catalog_dir: rdk-model-zoo 注册给 old-device。新增相同目录不是自动覆盖；必须保证全局唯一，一个 repo 只能映射一个 component。
- skills/VERSION 与 skills/pack.json 的 Pack 版本均为 1.0.0；pack 的 release_state 为 unreleased-candidate。入口 Skill 版本为 1.1.0，二者无需相等。
- 本地 tag 列表只有 A、B；这不能证明远端没有 v1.0.0，也不能证明正式 Release 存在。外部查询按任务约束未执行。
- .github/workflows/model-catalog-pages.yml 在 workflow 层使用固定 pages 并发组且 cancel-in-progress: true。job 的 x5-v 条件不能隔离 Skills 事件对模型任务的并发取消风险；发布前需修复并验证。

## 待执行顺序

1. 确定并批准真实源提交、Pack 版本及发布副作用；检查 Tag 占用、原 Latest、模型 Tag/Manifest 快照。先修复 Pages 事件与并发隔离，Skills 事件使用含 run_id 的独立忽略组。
2. 检查 Pack 结构、版本、许可、引用闭包和独立平铺安装；执行真实的 host 检查与行为验收并保存输出。不得把已有报告当本次测试。
3. 在批准的真实提交创建只增不改的附注 canonical stable Tag（vMAJOR.MINOR.PATCH），发布正式非草稿、非预发布 Release。标题 RDK Skills vX.Y.Z，首段 Component: RDK Model Zoo Skills；发布命令必须包含 --verify-tag --latest=false。先有真实源 Release，再切换 Hub。
4. 在同一个 Hub PR 中删除 components.d/rdk-device.yml 的 rdk-model-zoo 条目，新增 components.d/rdk-model-zoo.yml。按真实 Hub schema 填写源仓库、已发布 ref、skills/ 下的源路径及唯一 catalog_dir；不得把候选版本当已发布 ref。
5. 在该 PR 同步镜像、插件/README/安装注册等生成物。检查全局 catalog_dir 唯一、repo/component 一对一、只镜像 Skills、各 Skill 的 references/assets 完整；运行 Hub 校验、安装与升级演练。当前 fixture 无完整 Hub schema、生成器和服务，不能声称这些已通过。
6. 保留上游署名、许可和历史；旧 Device 新版本说明迁移，Hub 公共入口名继续使用 rdk-model-zoo。直接从旧仓库安装的用户需要处理旧副本，避免重复加载；不使用 OE workspace 安装器，不放入可能被 OE 升级清理的 .drobotics/ 或 .horizon/。
7. 单独核对 notifier 的 App/权限、标签、CI 与重复事件处理。小时同步不是首次注册迁移的替代品。本任务不读取认证、不访问服务。

## 验证与回退

- 已执行：本地文件和 Git 元数据只读检查、Pack 版本比对。rg 启动失败，改用 PowerShell 文件读取。未运行模型、板测、Hub CI 或安装演练；模型为不可执行占位文件。
- 本次仅新增此清单；未改注册、根 VERSION、模型 Manifest、Tag 或 Release。
- 合入前可撤回迁移候选；Tag 发布后保留不可变 Tag，仅为同一身份补建缺失 Release，或发布新补丁。Hub 故障通过经批准的新 PR 修正注册及生成物，必要时回指已存在的合法 ref；不删除、移动旧 Tag。
- 待真实环境授权后才执行发布/Hub 写入；本地没有真实 Release URL、Latest 或设备结果。
