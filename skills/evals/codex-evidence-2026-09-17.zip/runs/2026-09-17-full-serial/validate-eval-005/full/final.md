我会先读取测试上下文和编码探针，再查目标样例已有的 FPS 发布记录，不执行性能重测。


本任务采用 `rdk-model-zoo` 技能的已发布指标查询流程。上下文标明目标平台为 X5，且仓库记录是合成测试数据；我会保留记录中的版本、测试条件和来源，明确区分记录值与真实板端实测。


查到已有记录：**42.0 FPS**。

- 对象：`samples/vision/yolov5`，模型 `yolov5-fixture`，X5，Python，detect。
- 发布版本：`1.1.2`，来源引用 `fixture-base`。
- 证据：[benchmarks.yaml](docs/manifests/benchmarks.yaml) 的 `published-fixture` 记录，并由 [models.yaml](docs/manifests/models.yaml) 核对样例映射。
- 限制：来源明确为合成发布记录，不能作为真实板卡性能证据。计时范围、输入尺寸、batch、预热和测量次数均未提供，模型哈希未知。

实际采用 `rdk-model-zoo` 已发布指标查询流程，仅做本地只读核对；未修改文件、未运行样例或性能测试、未联网。
