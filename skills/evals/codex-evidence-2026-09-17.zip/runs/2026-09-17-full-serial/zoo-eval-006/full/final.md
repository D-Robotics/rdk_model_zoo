我先读取测试上下文和编码探针，再按 X5 量化路由检查本地工具链与输入条件。

我将使用 `x5-router` 技能。该路由明确是测试替身，要求记录 X5 工具链交接及缺失条件，并禁止在此测试仓库内实施或执行量化；上下文也说明模型字节为占位数据，因此不能产出真实量化模型。

已按 `x5-router` 完成本地交接记录：[X5_QUANTIZATION_HANDOFF.md](X5_QUANTIZATION_HANDOFF.md)。

- 证据：上下文声明模型为占位数据，目标样例无 ONNX，仅有 `fixture.bin`。
- 修改：仅新增交接文档，列出真实 ONNX、校准数据、预处理及工具链环境等缺失条件。
- 验证：完成本地 UTF-8 文本及文件检查；未执行量化、推理或板端测试，未生成真实模型。

限制来自 [x5-router 技能](.agents/skills/x5-router/SKILL.md)：“Do not implement or execute quantization in this fixture.” 因此本次仅完成路由记录，实际量化仍需真实模型与 X5 工具链环境。
