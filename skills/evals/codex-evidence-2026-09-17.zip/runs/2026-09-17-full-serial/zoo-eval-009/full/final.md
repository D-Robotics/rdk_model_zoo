我先读取测试上下文和编码探针，再核对目标模型的发布资产记录。

我使用 `rdk-model-zoo` 技能做只读资产查询；样例目录下没有 `models.yaml`，继续查找仓库中的目标清单。

有发布资产记录：[models.yaml](docs/manifests/models.yaml) 将目标样例标为 `availability: published`，列出资产 `samples/vision/yolov5/model/fixture.bin`。

但这是合成测试占位记录，不能证明真实模型已发布；`sha256` 也为未知。本次按 `rdk-model-zoo` 工作流只读核对，未修改文件、下载或运行测试。
