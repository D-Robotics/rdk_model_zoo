import ast
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sample = root / 'samples/vision/yolov5'
runtime = sample / 'runtime/python'
sys.path[:0] = [str(runtime), str(root)]
for path in list(sample.rglob('*.py')) + list((root / 'utils').glob('*.py')):
    ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
print('PASS: Python syntax')
from main import parse_args
from yolov5 import Config, Model
from utils.postprocess import select_boxes
args = parse_args([])
assert args.model_path == '../../model/fixture.bin'
assert args.output == 'result.jpg'
assert args.label_file == '../../model/labels.txt'
assert (runtime / args.model_path).is_file()
assert (runtime / args.label_file).is_file()
custom = parse_args(['--model-path', 'custom.bin', '--output', 'custom.jpg', '--label-file', 'custom.txt'])
assert (custom.model_path, custom.output, custom.label_file) == ('custom.bin', 'custom.jpg', 'custom.txt')
readme = (sample / 'README.md').read_text(encoding='utf-8')
assert '--model-path ../../model/fixture.bin --output result.jpg' in readme
print('PASS: CLI defaults, overrides and documented paths')
for count in (3, 80):
    model = Model(Config(classes_num=count))
    assert model.decode([]) == []
    values = list(range(2 * (5 + count)))
    assert model.decode(values) == [values[:5+count], values[5+count:]]
    try:
        model.decode([0])
    except ValueError as exc:
        assert str(exc) == 'output class dimension mismatch'
    else:
        raise AssertionError('Expected malformed dimension rejection')
assert select_boxes([]) == []
rows = [[1, 2, 3]]
assert select_boxes(rows) == rows and select_boxes(rows) is not rows
print('PASS: synthetic decode boundaries and host postprocess empty/copy behavior')
try:
    Model(Config()).predict(None)
except RuntimeError as exc:
    assert str(exc) == 'Fixture: no real runtime'
else:
    raise AssertionError('Placeholder must not claim inference')
labels = (runtime / args.label_file).read_text(encoding='utf-8').splitlines()
print(f'LIMITATION: Config default classes={Config().classes_num}, labels={len(labels)}; real model contract unknown')
print('PASS: explicit unavailable-runtime error; no model execution or accuracy evidence')
