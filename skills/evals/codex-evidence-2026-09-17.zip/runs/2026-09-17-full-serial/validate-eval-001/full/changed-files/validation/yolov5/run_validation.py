import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
env = dict(os.environ, PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='NUL')
def git(*args):
    return subprocess.check_output(['git', '-c', 'core.excludesFile=NUL', *args], cwd=root, env=env).decode('utf-8').strip()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
def now():
    return datetime.now(timezone.utc).isoformat()

# Snapshot all tracked and untracked task inputs, including installed skills;
# exclude only generated evidence from this validation directory.
names = git('ls-files', '--cached', '--others', '--exclude-standard').splitlines()
names = sorted(set(n for n in names if not n.startswith('validation/')) | {'validation/yolov5/host_checks.py', 'validation/yolov5/run_validation.py'})
snapshot = {'git_status': git('status', '--short'), 'branch': git('symbolic-ref', '--short', 'HEAD'), 'files': {n: digest(root/n) for n in names if (root/n).is_file()}}
write(out/'inputs.json', snapshot)
scope = dict(platform='X5', model_variant='yolov5-fixture (non-executable placeholder)', task='detect', runtime='Python; hardware runtime unavailable', model_sha256=digest(root/'samples/vision/yolov5/model/fixture.bin'), input_sha256=None)
environment = dict(host='isolated local Windows host', board=None, os=platform.platform(), runtime_version=platform.python_version())
checks = []
argv = [sys.executable, '-X', 'utf8', '-B', str(out/'host_checks.py')]
start = now()
p = subprocess.run(argv, cwd=root, env=env, capture_output=True, text=True, encoding='utf-8')
end = now()
(out/'host.stdout.txt').write_text(p.stdout, encoding='utf-8')
(out/'host.stderr.txt').write_text(p.stderr, encoding='utf-8')
checks.append(dict(id='host-contract', required=True, level='host', purpose='smoke', status='passed' if p.returncode == 0 else 'failed', scope=scope, environment=environment, execution=dict(argv=argv,cwd=str(root),exit_code=p.returncode,started_at=start,ended_at=end), result=dict(summary='Synthetic host assertions only; see stdout/stderr.', acceptance='All syntax, CLI, decode and explicit runtime-error assertions pass; process exit 0.'), evidence=[dict(path=n,sha256=digest(out/n)) for n in ('host.stdout.txt','host.stderr.txt','inputs.json','host_checks.py')], reason=None))
for name, purpose, required, reason in [('board-smoke','smoke',True,'No board, hardware runtime, trustworthy executable model or real input. Placeholder is not a model.'),('accuracy','accuracy',False,'No evaluator, labeled dataset, real model or approved metric threshold.'),('performance','performance',False,'No board or executable model; timing protocol and target threshold unspecified.')]:
    checks.append(dict(id=name,required=required,level='board',purpose=purpose,status='not-run',scope=scope,environment=environment,execution=None,result=None,evidence=[],reason=reason))
receipt = dict(schema_version=1,kind='verification',target=dict(repository=str(root),commit=git('rev-parse','HEAD'),dirty=True,patch_sha256=digest(out/'inputs.json'),sample_path='samples/vision/yolov5'),checks=checks)
write(out/'verification.json',receipt)
validator = root/'.agents/skills/rdk-model-zoo-validate/scripts/validate_evidence.py'
argv = [sys.executable,'-X','utf8','-B',str(validator),str(out/'verification.json'),'--evidence-root',str(out)]
start = now()
v = subprocess.run(argv,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8')
write(out/'schema-check.json',dict(argv=argv,cwd=str(root),started_at=start,ended_at=now(),exit_code=v.returncode,stdout=v.stdout,stderr=v.stderr))
print(p.stdout, end='')
print(p.stderr, end='')
print(v.stdout, end='')
print(v.stderr, end='')
sys.exit(p.returncode or v.returncode)
