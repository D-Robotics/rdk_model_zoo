Delivery specification: Python and C++ implementations are required.

Current status: incomplete delivery.

- Python: `runtime/python/main.py` contains only an identity function that returns its input. It is not a complete robotics model runtime.
- C++: currently unsupported. `runtime/cpp/README.md` is a TODO placeholder, not an implementation.

Robotics 类别要求同时交付 Python 和 C++ 实现。当前 C++ 不支持，Python 仅有原样返回输入的函数；本样例尚未满足双 runtime 交付要求。此状态说明不构成 Python-only 豁免。

No model inference, board execution, or robot control has been verified. Completing delivery requires actual Python and C++ runtimes and corresponding validation evidence.
