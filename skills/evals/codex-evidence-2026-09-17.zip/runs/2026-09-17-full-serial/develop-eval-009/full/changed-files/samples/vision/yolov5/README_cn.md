默认入口 runtime/python/main.py；输出 result.jpg。模型文件只是测试占位，不能做推理。
