# YOLOv5
Run from samples/vision/yolov5/runtime/python: python main.py --model-path ../../model/fixture.bin --output result.jpg
Python entry: runtime/python/main.py. Wrapper: yolov5.py. Output result.jpg. Download requires explicit task scope; asset URL is deliberately non-routable.
