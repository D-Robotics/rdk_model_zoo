我先读取测试上下文和编码探针，再核对样例实际输出路径，只修改相关 README。


本次采用 `rdk-model-zoo-develop` 的文档修复流程，按源码核对 README。`rg` 无法启动，将用 PowerShell 读取仓库文件；后续 Git 检查会禁用用户级配置。


已按 `rdk-model-zoo-develop` 文档修复流程，将样例中英文 README 的三处 `old.jpg` 改为 `result.jpg`，与 `main.py` 默认参数及 `run.sh` 一致，运行实现未改。

静态路径检查和 `git diff --check` 均通过。未运行推理、板测或独立审阅；未将占位模型作为真实模型验证。
