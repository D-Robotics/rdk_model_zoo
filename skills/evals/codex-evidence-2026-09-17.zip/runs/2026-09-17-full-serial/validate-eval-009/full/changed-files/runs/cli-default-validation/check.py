import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
from datetime import datetime, timezone

sys.stdout.reconfigure(encoding='utf-8')
sys.dont_write_bytecode = True
root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
env = dict(os.environ, GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull,
           XDG_CONFIG_HOME=str(out), HOME=str(out), USERPROFILE=str(out))
def git(*args):
    p = subprocess.run(['git', '-c', 'core.excludesFile=' + os.devnull, *args], cwd=root, env=env, capture_output=True)
    if p.returncode:
        raise RuntimeError(p.stderr.decode('utf-8', errors='replace'))
    return p.stdout
def digest(data):
    return hashlib.sha256(data).hexdigest()
def now():
    return datetime.now(timezone.utc).isoformat()
start = now()
sample = 'samples/vision/yolov5'
entry = sample + '/runtime/python/main.py'
base = git('show', 'A:' + entry).decode('utf-8')
current = (root / entry).read_text(encoding='utf-8')
patch = git('diff', '--binary', 'B', '--', sample)
(out / 'sample.patch').write_bytes(patch)
snapshot = {}
paths = [root / 'EVAL_CONTEXT.md', Path(__file__)] + list((root / sample).rglob('*'))
for path in paths:
    if path.is_file():
        snapshot[path.relative_to(root).as_posix()] = {'sha256': digest(path.read_bytes()), 'content_hex': path.read_bytes().hex()}
(out / 'snapshot.json').write_text(json.dumps(snapshot, indent=2), encoding='utf-8')
checks = []
log = []
def check(name, fn):
    try:
        fn()
        log.append(name + ': passed')
    except Exception as exc:
        log.append(name + ': failed: ' + repr(exc))
        checks.append(name)
def require(ok):
    assert ok
check('only intended default changed', lambda: require(current == base.replace("default='result.jpg'", "default='new-result.jpg'")))
check('A and B same commit', lambda: require(git('rev-parse', 'A') == git('rev-parse', 'B')))
check('sample diff limited to main.py', lambda: require(git('diff', '--name-only', 'B', '--', sample).decode().strip() == entry))
ast.parse(current)
sys.path.insert(0, str(root / sample / 'runtime/python'))
spec = importlib.util.spec_from_file_location('sample_cli', root / entry)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
check('default output', lambda: require(module.parse_args([]).output == 'new-result.jpg'))
check('explicit output override', lambda: require(module.parse_args(['--output', 'custom image.jpg']).output == 'custom image.jpg'))
check('legacy explicit output', lambda: require(module.parse_args(['--output', 'result.jpg']).output == 'result.jpg'))
check('other defaults unchanged', lambda: require(vars(module.parse_args([])) == {'model_path': '../../model/fixture.bin', 'output': 'new-result.jpg', 'label_file': '../../model/labels.txt'}))
check('all explicit overrides', lambda: require(vars(module.parse_args(['--model-path', 'custom.bin', '--label-file', 'custom.txt', '--output', 'x.jpg'])) == {'model_path': 'custom.bin', 'label_file': 'custom.txt', 'output': 'x.jpg'}))
log.append('Documentation observation: README_cn.md still says output result.jpg; README.md and run.sh explicitly pass --output result.jpg, which remains valid.')
log.append('No inference, model loading, accuracy or performance testing executed; model bytes are synthetic placeholders.')
(out / 'host.log').write_text('\n'.join(log) + '\n', encoding='utf-8')
evidence = [{'path': p, 'sha256': digest((out / p).read_bytes())} for p in ['host.log', 'sample.patch', 'snapshot.json', 'check.py']]
scope = dict(platform='X5 (fixture context only)', model_variant=None, task='CLI argument parsing', runtime='Python argparse', model_sha256=None, input_sha256=None)
environment = dict(host='isolated local Windows host', board=None, os=platform.system(), runtime_version=platform.python_version())
report = dict(schema_version=1, kind='verification', target=dict(repository=str(root), commit=git('rev-parse', 'HEAD').decode().strip(), dirty=True, patch_sha256=digest((out / 'snapshot.json').read_bytes()), sample_path=sample), checks=[dict(id='cli-default-and-overrides', required=True, level='host', purpose='smoke', status='failed' if checks else 'passed', scope=scope, environment=environment, execution=dict(argv=[sys.executable, '-I', '-B', '-X', 'utf8', str(Path(__file__).resolve())], cwd=str(root), exit_code=1 if checks else 0, started_at=start, ended_at=now()), result=dict(summary='; '.join(log), acceptance='Only output default changes; default is new-result.jpg; explicit overrides and remaining defaults retain their behavior.'), evidence=evidence, reason=None), dict(id='model-board-validation', required=False, level='board', purpose='smoke', status='not-run', scope=scope, environment=environment, execution=None, result=None, evidence=[], reason='Outside CLI-only scope; no real device, runtime or executable model is available.')])
(out / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('\n'.join(log))
sys.exit(1 if checks else 0)
