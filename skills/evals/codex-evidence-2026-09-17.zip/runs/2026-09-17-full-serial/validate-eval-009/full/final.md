我会先读取测试上下文和编码探针，再按样例验证流程检查 CLI 默认值改动，并运行适用的 host 测试。

我将使用 `rdk-model-zoo-validate` 技能。当前 A、B 指向同一提交，实际改动在工作区：`--output` 默认值从 `result.jpg` 改为 `new-result.jpg`。本次必需检查限定为静态参数对照和 host 默认值／显式覆盖测试，不扩展到模型精度或性能验证。

CLI host 检查已通过：新默认值生效，显式输出路径及其他参数行为保持不变。发现中文 README 仍写“输出 result.jpg”，与新默认值不一致；运行脚本显式指定旧文件名，因此行为不受影响。正在核对已保存的报告和证据哈希。

已按 `rdk-model-zoo-validate` 完成限定范围验证。

- A、B 为同一提交；验证对象是工作区 CLI 默认值修改。
- 8 项检查通过：默认输出为 `new-result.jpg`，显式覆盖及其他默认值保持正常。
- 中文 README 仍写“输出 result.jpg”，存在文档不一致。
- 仅新增验证证据，未修改样例。报告结构及证据哈希校验通过。
- 未执行模型推理、精度、性能或板测；占位模型未用于推理。

证据见 [verification.json](runs/cli-default-validation/verification.json) 和 [host.log](runs/cli-default-validation/host.log)。
