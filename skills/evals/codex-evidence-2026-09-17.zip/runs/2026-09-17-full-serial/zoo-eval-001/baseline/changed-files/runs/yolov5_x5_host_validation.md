# YOLOv5 X5 本地验证

目标：rdk_x5；样例：`samples/vision/yolov5`。复用已有模型资产与 Python runtime 入口，不重新量化、不下载、不连接设备。

## 仓库证据

- `docs/manifests/models.yaml` 声明 X5、detect、python，资产路径为 `samples/vision/yolov5/model/fixture.bin`。
- `EVAL_CONTEXT.md` 和样例中文 README 明确说明资产是不可执行的测试占位；文件大小为 43 字节，不能作为真实预编译模型。
- `runtime/python/main.py` 是 CLI 入口，`yolov5.py` 提供 Config/Model，但 predict 明确抛出无真实 runtime 的异常。
- benchmark 清单的 42 FPS 是合成记录，不是本次测量。

## 实际 host 验证

在样例 `runtime/python` 目录执行：

```text
python -X utf8 main.py --help
python -X utf8 main.py --model-path ../../model/fixture.bin --output result.jpg
```

帮助正常展示 `--model-path`、`--output`、`--label-file`。运行命令退出码为 1，输出：

```text
Fixture: hardware runtime is not installed; no inference executed
```

没有生成 `result.jpg`。仓库根目录执行 `python -X utf8 -m unittest discover -s tests -v`，1 项空输入后处理测试通过。该测试不验证模型推理、精度或性能。

## 限制

未运行板端推理，未测量 FPS 或精度。真正完成 X5 推理需要可执行且兼容 X5 的模型、真实板端 Python 推理实现及运行环境；当前隔离 fixture 不具备这些条件。保留原有入口和模型，不以替换占位文件或生成假结果宣称跑通。
