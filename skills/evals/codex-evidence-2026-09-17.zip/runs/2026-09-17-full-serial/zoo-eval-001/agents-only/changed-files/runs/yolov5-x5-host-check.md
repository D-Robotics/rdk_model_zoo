# X5 现成 YOLOv5：本地检查记录

主工作流：rdk-model-zoo（现成模型使用）。没有可用的对应技能，直接依据仓库事实检查。不重新量化，不下载资产，不连接设备。

## 证据

- `docs/manifests/models.yaml` 声明 `yolov5-fixture` 支持 X5、Python，样例为 `samples/vision/yolov5`。
- `README.md`、`README_cn.md` 与 `runtime/python/run.sh` 指向 `runtime/python/main.py`。
- `model/fixture.bin` 仅 43 字节，内容为 `SYNTHETIC NON-EXECUTABLE MODEL PLACEHOLDER`；清单没有资产 SHA256，不能据此确认真实可执行模型。
- `EVAL_CONTEXT.md` 明确说明隔离合成环境；`main.py` 主动退出，`Model.predict` 没有真实推理实现。

## 已执行的 host 检查

- `python -B -m unittest discover -s tests -v`：1 个测试通过，仅验证空输入后处理。
- `python -B samples/vision/yolov5/runtime/python/main.py --help`：退出码 0，确认 model-path、label-file、output 参数。
- 从 `samples/vision/yolov5/runtime/python` 执行以下命令：

```sh
python -B main.py --model-path ../../model/fixture.bin --label-file ../../model/labels.txt --output result.jpg
```

退出码 1：`Fixture: hardware runtime is not installed; no inference executed`。这是占位入口检查，不是板端推理成功。

## 限制与实际运行前提

未执行板端推理、精度或性能测试，未生成推理图像。要在 X5 上实际运行，仍需要真实的 X5 预编译模型、配套可执行 Python 推理实现及板端 runtime；本仓库占位文件不能替代它们。真实实现的输入参数须以其 CLI 文档为准，本 fixture 没有图片输入参数。无需因本次占位环境重新量化。

本次仅新增此记录，未修改模型、runtime 或样例代码。
