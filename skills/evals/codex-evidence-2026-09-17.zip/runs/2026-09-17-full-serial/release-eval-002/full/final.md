我会先读取测试上下文和编码探针，确认 Hub ref 的规则及相关文件，再按任务范围修改并做本地验证。

我会使用 `rdk-model-zoo-release` 技能检查 Hub 接入与 Tag 兼容性。`skills-v1.0.0` 与已知的 canonical 规则冲突，需要先核对是否涉及完整的命名迁移。

已按 `rdk-model-zoo-release` 的 Hub 接入流程完成本地兼容性检查。

- `docs/Skills_Release_Policy.md` 明确：canonical ref 仅接受 `vMAJOR.MINOR.PATCH`，不接受 `skills-v*`。
- `skills/VERSION` 为 `1.0.0`，因此应使用 `v1.0.0`；可用 Release 标题 `RDK Skills v1.0.0` 和组件名称表达用途。
- 若坚持 `skills-v1.0.0`，需先完成 Hub 解析器、通知过滤及相关测试的配套迁移，不能只改注册 ref。

本次未修改文件、未创建 Tag 或发布。仅做静态检查；仓库未提供 Hub 解析器，未运行其测试，也未联网或访问设备。
