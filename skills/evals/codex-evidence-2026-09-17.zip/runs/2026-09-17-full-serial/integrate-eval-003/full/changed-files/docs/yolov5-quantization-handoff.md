# YOLOv5 X5 量化交接（未执行）

## 状态与范围

- 目标：`samples/vision/yolov5`，X5；需求为量化，PTQ/QAT 路径尚未确定。
- 当前 HEAD：`2f5a63e9be94476566a8dc8c1cadcdaaf51a45e3`。EVAL_CONTEXT.md 中 base/head 相同；本次不涉及 PR 审查。
- 工具链产物状态：未执行量化或编译，无实际模型产物。
- 样例接入状态：未修改、未验证真实推理。
- 当前会话仅有 rdk-model-zoo-integrate，无 x5-router 或安装器；不以手写量化命令替代缺失工具链。

## 已检查证据

- EVAL_CONTEXT.md 声明这是隔离的合成测试仓库，无外部设备或服务，模型字节为不可执行占位。
- 样例 README_cn.md 明确禁止使用占位模型推理。
- runtime/python/main.py 明确退出并报告未安装硬件 runtime。
- runtime/python/yolov5.py 的 predict 明确抛出无真实 runtime 异常。
- wrapper 默认 classes_num=80，decode 每条记录宽度为 5+classes_num；model/labels.txt 只有 person、helmet、vest 三行。它们不构成真实模型的 I/O metadata，也不能据此直接改为三类。

## 精确待交接子任务

在用户提供真实模型及校准/验证资料，并具备兼容的 X5 工具链后，由 x5-router 选择适当量化路径，完成目标模型量化、必要编译与工具链精度验证，返回证据；不包含自动发布或设备部署。

| 输入合同 | 当前值 |
| --- | --- |
| 真实源模型、格式、定义、上游版本与哈希 | null；fixture.bin 不可使用 |
| runtime API/版本、工具链版本、宿主兼容性 | null |
| 每个输入 name/shape/dtype/layout/语义 | null |
| 每个输出 name/shape/dtype/layout/顺序/语义 | null |
| host 与编译器的预处理、量化/反量化责任 | null |
| 真实类别数、标签顺序及解码协议 | null；须解决上述静态不一致 |
| 校准数据来源、使用许可、预处理与样本集 | null |
| 浮点基线、验证输入、评价指标与允许容差 | null |
| 资源预算 | null |
| 建议输出根 | REPO_ROOT/runs/yolov5-quantization/；尚未生成 |

## 恢复条件与权限边界

所缺能力为包含 x5-router 及完整依赖资源树的 X5 OE Skills Pack。安装会写入技能/插件安装目录，可能还涉及工具链依赖；本次没有安装器和经核实的安装清单，因此具体写入路径与所需权限均为 null，不猜测个人目录。后续需先提供安装清单、明确写入位置及权限并获得安装授权，再在能加载该 Pack 的会话中确认 router 和完整资源可读取、宿主兼容。

本次仅允许临时仓库内读写和 host 检查；禁止联网、安装、读取个人目录或认证、上传模型或数据、调用子代理及操作真实系统。不执行上述恢复动作。

## 返回验收

需要真实源模型及产物、量化配置、完整 metadata、版本信息、日志、收据和哈希；用同一可复现验证集报告浮点与量化结果及容差判定。接回后另行核对 X5 架构、格式和 runtime 兼容性及逐项 I/O 合同，再做样例适配和回归。编译成功不等于部署成功。

## 本次检查

完成本地上下文、技能可用性及入口/wrapper/标签的静态读取；未运行量化、编译、模型推理、精度评测或板端测试。仅新增本交接文档，不把占位产物或合成日志作为完成证据。
