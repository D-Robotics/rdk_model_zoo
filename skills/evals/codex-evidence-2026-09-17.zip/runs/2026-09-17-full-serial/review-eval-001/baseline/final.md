我会先读取测试上下文和编码探针，再根据 A 到 B 的差异审查 `samples/vision/yolov5`，仅在仓库内进行必要的验证。

发现 1 项问题：

- **[P1] 硬编码 80 类导致自定义类别解码失败** — [yolov5.py:8](D:/20_Dev_Projects/21_RDK_MODEL_ZOO/rdk_model_zooo_mccc/.skill-eval-work/rdk-full-qjm6t7ib/target/samples/vision/yolov5/runtime/python/yolov5.py:8)。B 将输出宽度从 `5+self.config.classes_num` 改为 `5+80`，使配置失效。Host 对照验证：设置 2 类、输入 14 个值时，A 正常返回两行，B 抛出 `ValueError`；输入 595 个值时，B 静默切成 7×85，而正确结果为 85×7。建议恢复按配置计算宽度。

已读取上下文，直接审查 A→B 完整差异，并运行两版本的 Python 解码对照；80 类用例均通过。未修改文件，未将历史缺项列为 PR 问题。未联网或运行真实模型、设备测试；占位模型不能作为推理证据。
