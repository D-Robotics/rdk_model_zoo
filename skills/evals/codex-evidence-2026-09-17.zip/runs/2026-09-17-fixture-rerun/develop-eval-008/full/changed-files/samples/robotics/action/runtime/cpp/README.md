# C++ runtime — not implemented

This directory contains documentation only. It has no C++ source, build target,
launch script or model inference implementation. There is currently no build or
run command to offer.

C++ remains a required deliverable alongside Python; see
[delivery requirements](../../DELIVERY.md). An identity function or a mock model
would not satisfy the action inference requirement.

本目录仅含文档，尚无 C++ 实现。C++ 与 Python 均为必需交付；不能以目录存在、
透传函数或占位模型作为完成证据。
