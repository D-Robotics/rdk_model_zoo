# Action sample — delivery incomplete

Target: X5. **Delivery specification: Python and C++ support required.**
Neither runtime currently provides model inference. This synthetic fixture is
not ready for use on a robot.

| Runtime | Current evidence | Status |
| --- | --- | --- |
| Python | `runtime/python/main.py` only returns its input | Inference not implemented |
| C++ | `runtime/cpp/README.md` only; no source or build entry | Not implemented |

The previous claim that C++ was available was incorrect. Correcting that claim
does not waive the dual-runtime requirement or complete delivery.

See [delivery requirements and verification](DELIVERY.md) and
[中文说明](README_cn.md). No runnable action model, tensor contract or reference
outputs are provided. Do not use another sample's placeholder model for this task.
