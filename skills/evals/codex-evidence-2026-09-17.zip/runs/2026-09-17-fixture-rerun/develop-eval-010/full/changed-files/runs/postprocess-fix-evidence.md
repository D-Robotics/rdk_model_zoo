# 公共后处理空输入修复记录

## 范围与依据

- 工作流：rdk-model-zoo-develop 主导，rdk-model-zoo-validate 辅助 host 回归；仅作者自检，未执行独立 review（用户禁止子代理）。
- 仓库：当前隔离 REPO_ROOT；分支 rdk_x5；目标 X5 / samples/vision/yolov5 / Python。
- Base A：4cdedf05ec8a7663850d436864ea5974741e9e68。
- Head B：2b7203fbb6ca5791371997b9a69aa1dfcfe4766b；验证对象为 B 加本次源码和测试修改。
- 适用规范：docs/Model_Zoo_Repository_Guidelines.md 中复用公共 postprocess、入口与 README 默认一致条款；规则未修改。此列表辅助函数不等同检测 Model.predict 的三元组接口。
- 用户约束：不联网、不运行系统安装、不使用真实设备、占位模型不作模型证据。

## 原因与修改

B 在 utils/postprocess.py:2 新增未使用的 rows[0]，使空列表在复制前抛出 IndexError。删除该访问，保留列表切片的浅拷贝行为，补充接口文档。

公共工具消费者：samples/classification/main.py 的 classify；samples/vision/yolov5/runtime/python/classifier.py 的导入别名。测试覆盖工具本身及两个消费者。YOLOv5 Model.predict 明确为不可推理 fixture，不能声称完成检测端到端验证。

run.sh 中的 pip install --upgrade、mkdir /opt 和系统文件写入不是 host 开发依赖。静态核对 A 后恢复其原始启动命令，与中英文 README 及 main.py 默认值一致；未执行该脚本。

## 实际检查

所有命令 cwd 均为 REPO_ROOT。Python 设置 PYTHONIOENCODING=utf-8、PYTHONUTF8=1，使用 -B 避免字节码写入；无需安装依赖。

| 检查 | 命令/方式 | 结果 |
| --- | --- | --- |
| 修复前 host 回归 | python -B -m unittest tests.test_postprocess -v | exit 1；2 个测试，空输入的三个子测试均报 IndexError: list index out of range；非空测试通过 |
| 修复后 host 回归 | python -B -m unittest discover -s tests -v | exit 0；2 个测试全部通过，各覆盖工具及两个消费者 |
| 补丁格式 | git -c core.excludesFile=NUL diff --check | exit 0，无输出 |
| 启动入口 | 静态对照 A、main.py、README 双语 | 恢复 A 原命令；未执行 |

接受条件：空列表返回 []；非空行的值和顺序不变；返回新容器且保持浅拷贝，修改返回容器不改变输入容器长度。全部 host 条件通过。

## 交付检查与限制

- done：需求和平台核对、目标规范、先失败后通过、全部已发现消费者覆盖、公共函数文档、脚本副作用移除、diff 自检。
- not-applicable：新模型、转换、评估器、索引、Manifest、C++ 交付；本次不涉及这些接口或资产。
- not-run：板端 smoke、真实模型精度/性能及独立 review。环境没有真实设备或可执行模型，用户禁止子代理。
- 未提交、推送、安装依赖或调用外部服务。保留已有 .agents/ 和 EVAL_CONTEXT.md。
- 工具限制：rg 启动失败后改为仓库内 Get-ChildItem/Select-String 搜索；首次 git 默认配置查找产生个人目录权限拒绝，后续显式禁用全局/系统配置并设置 core.excludesFile=NUL；未读取个人目录内容。
