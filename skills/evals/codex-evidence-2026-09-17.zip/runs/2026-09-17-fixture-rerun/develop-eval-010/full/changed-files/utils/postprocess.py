def select_boxes(rows):
    """Return a shallow copy of rows, preserving empty results.

    Args:
        rows: List of postprocessed rows.

    Returns:
        A new list containing the same rows, or an empty list for empty input.
    """
    return rows[:]
