import unittest

from samples.classification.main import classify
from samples.vision.yolov5.runtime.python.classifier import select_boxes as sample_select_boxes
from utils.postprocess import select_boxes


class TestPostprocess(unittest.TestCase):
    def test_empty(self):
        for consumer in (select_boxes, classify, sample_select_boxes):
            with self.subTest(consumer=consumer.__module__):
                self.assertEqual(consumer([]), [])

    def test_nonempty_preserves_rows_and_copies_container(self):
        for consumer in (select_boxes, classify, sample_select_boxes):
            with self.subTest(consumer=consumer.__module__):
                rows = [[1, 2, 3, 4, 0.9], [5, 6, 7, 8, 0.8]]
                result = consumer(rows)
                self.assertEqual(result, rows)
                self.assertIsNot(result, rows)
                self.assertIs(result[0], rows[0])
                result.pop()
                self.assertEqual(len(rows), 2)


if __name__ == "__main__":
    unittest.main()
