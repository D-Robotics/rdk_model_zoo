#!/bin/sh
python main.py --model-path ../../model/fixture.bin --output result.jpg
