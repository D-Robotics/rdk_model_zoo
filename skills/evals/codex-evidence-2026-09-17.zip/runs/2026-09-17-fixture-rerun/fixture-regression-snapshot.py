"""Regression checks for the evaluation fixtures themselves."""
from pathlib import Path
import importlib.util,tempfile,unittest
spec=importlib.util.spec_from_file_location('suite',Path(__file__).with_name('full_suite.py'))
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)

class FixtureContracts(unittest.TestCase):
    def test_robotics_prompt_target_matches_cpp_delivery_fixture(self):
        for ident in ['develop-eval-003','develop-eval-008']:
            with self.subTest(case=ident),tempfile.TemporaryDirectory(prefix='fixture-regression-',dir=s.ROOT/'.skill-eval-work') as folder:
                root=Path(folder);facts=s.fixture(root,s.CASES[ident],'full')
                self.assertEqual(facts['sample'],'samples/robotics/action')
                self.assertIn('C++',(root/facts['sample']/'README.md').read_text(encoding='utf-8'))
                self.assertTrue((root/facts['sample']/'runtime/cpp/README.md').is_file())

    def test_staged_review_repair_stays_out_of_index(self):
        with tempfile.TemporaryDirectory(prefix='fixture-regression-',dir=s.ROOT/'.skill-eval-work') as folder:
            root=Path(folder);facts=s.fixture(root,s.CASES['review-eval-007'],'full')
            name=facts['sample']+'/runtime/python/yolov5.py'
            self.assertIn('width=5+80',s.git(root,'show',':'+name))
            self.assertIn('width=5+self.config.classes_num',(root/name).read_text(encoding='utf-8'))
            self.assertIn('width=5+self.config.classes_num',s.git(root,'show','HEAD:'+name))

if __name__=='__main__':unittest.main(verbosity=2)
