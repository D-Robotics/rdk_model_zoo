# Robotics action（X5）

本次范围仅限 Python；当前不支持 C++。`runtime/cpp/README.md` 仅为 TODO 占位，并非实现。
现有 `runtime/python/main.py` 中的 `action(values)` 仅原样返回输入，不执行模型推理，不能视为完整 Python runtime。

根据 `../../../docs/Model_Zoo_Repository_Guidelines.md`，robotics 必须交付 Python 和 C++ 两种实现。本次缩小范围不构成规范豁免：双 runtime 交付尚未完成，不能作为完整样例验收。
后续需提供真实模型及 I/O 合同、补齐两种 runtime，并验证各自行为。本仓库为合成测试夹具；未运行模型推理、板端测试、精度或性能测试，占位产物不构成模型证据。

## English

This change is scoped to Python only. C++ is currently unsupported: `runtime/cpp/README.md` is a TODO placeholder, not an implementation.
The existing Python `action(values)` function only returns its input unchanged; it does not perform model inference or constitute a complete Python runtime.

The repository guidelines require both Python and C++ implementations for robotics. This reduced scope does not waive that requirement; dual-runtime delivery remains incomplete and is not ready for full sample acceptance.
Completion requires a real model and I/O contract, both runtime implementations, and verification of each. This repository is a synthetic fixture. Model inference, board, accuracy, and performance tests have not been run; placeholder artifacts are not model evidence.
