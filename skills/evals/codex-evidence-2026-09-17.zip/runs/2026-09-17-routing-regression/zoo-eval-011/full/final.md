我先读取测试上下文和编码探针，再按仓库现有目录与 README 查找旧版 X5 的样例入口。

本次使用 `rdk-model-zoo-repo` 技能进行只读入口定位；没有 Manifest 时，以当前历史版本的 README 和运行代码为依据。`rg` 无法启动，接下来改用 PowerShell 枚举目录。


已找到，旧版没有 Manifest 仍可通过 README 和源码定位：

- **样例目录**：`samples/vision/yolov5`
- **Python 入口**：[main.py](D:/20_Dev_Projects/21_RDK_MODEL_ZOO/rdk_model_zooo_mccc/.skill-eval-work/rdk-full-vwjog2di/target/samples/vision/yolov5/runtime/python/main.py)
- **启动脚本**：同目录 `run.sh`，需从 `samples/vision/yolov5/runtime/python` 启动。
- **模型封装**：同目录 `yolov5.py`；中文说明位于样例 `README_cn.md`。

实际采用 `rdk-model-zoo-repo` 只读定位流程。已核对分支 `rdk_x5_legacy`、版本 `1.1.2`、HEAD `5be7ee8`；未提供机器清单，README、启动脚本和源码均指向上述入口。

未修改文件、未联网、未执行推理或板测。当前 `fixture.bin` 是占位文件，`main.py` 明确退出并提示缺少硬件运行时，不能据此认为真实模型可运行。
