我先读取测试上下文和编码探针，再按仓库上下文技能核对清单的身份及引用关系。

目前**无法唯一确认正在使用哪个清单**：仓库有两个身份不同的候选，已读 README 和引用未明确指定来源。

| 清单 | 发布平台 | 版本 | source_ref |
|---|---|---|---|
| [docs/manifests/models.yaml](docs/manifests/models.yaml) | X5 | 1.1.2 | fixture-base |
| [release/models.yaml](release/models.yaml) | S | 0.9.0 | historical-other |

README 声明目标为 X5，当前分支为 `rdk_x5`，因此前者更吻合；但这不能证明它已被选用。后者还存在发布平台 S 与模型条目 X5 不一致的情况。

实际采用 `rdk-model-zoo-repo` 只读盘点流程，检查了 Git 身份、清单及样例文档；工作区已有改动，本次未修改文件、未运行模型或联网。模型为测试占位产物。

你要确认的是 **当前 X5 清单**，还是 **历史 S 发布清单**？[技能上下文规则](D:/20_Dev_Projects/21_RDK_MODEL_ZOO/rdk_model_zooo_mccc/.skill-eval-work/rdk-eval-host-1r6vz3fr/codex/skills/rdk-model-zoo-repo/references/context-policy.md)要求多个 Manifest 时“逐个列出并让用户或任务范围选择”；目前任务范围尚不能唯一选定。
