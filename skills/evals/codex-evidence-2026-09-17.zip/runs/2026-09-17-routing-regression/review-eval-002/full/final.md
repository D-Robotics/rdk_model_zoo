我会先读取测试上下文和编码探针，再按样例审查流程核对旧 X3 版本的目录约定与目标样例证据。

我使用 `rdk-model-zoo-review` 技能进行只读布局审查。适用规则要求按目标历史版本判断，不能直接套用当前 X5 的目录模板；接下来核对 base 的规范和 X3 样例。

**不违规。** 对已核查的旧 X3 1.1.2，`demos/detect/YOLOv5` 是该版本既有布局，不能套用当前 X5 的 `samples/` 模板要求迁移。

- **工作流与证据**：使用 `rdk-model-zoo-review` 做只读布局审查。分支为 `rdk_x3`；base `95f7655` 的 README 和目录树已采用该路径，head `ef8d6b7` 的模型清单也引用同一路径。base 规范没有禁止 `demos/`。
- **范围**：A→B 未改变目录布局。布局维度 `review_decision = pass`；无额外交付规格（`No delivery specification available`），`delivery_readiness = unknown`。
- **另见代码变化**：B 将 `decode()` 的类别宽度从配置值改为固定 80，属于独立的代码正确性问题，不能据此判定目录违规，也不能把布局通过理解为整个 PR 通过。
- **修改与测试**：未修改文件，仅检查 Git、文档和源码；未运行 host 测试、推理或板测。模型是占位文件，不构成实际模型或硬件验证证据。
