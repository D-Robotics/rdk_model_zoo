# 仓库上下文日志

日期：2026-09-17。来源：用户要求为后续样例开发建立上下文，并记录脱敏 remote 身份。本次主工作流为 `rdk-model-zoo-repo`，不作 PR 质量审阅或验收结论。

## 身份与工作区

| 字段 | 观测结果及依据 |
| --- | --- |
| REPO_ROOT | `D:/20_Dev_Projects/21_RDK_MODEL_ZOO/rdk_model_zooo_mccc/.skill-eval-work/rdk-full-60qikajs/target`；Git 根目录确认 |
| SKILL_ROOT | `D:/20_Dev_Projects/21_RDK_MODEL_ZOO/rdk_model_zooo_mccc/.skill-eval-work/rdk-eval-host-1r6vz3fr/codex/skills/rdk-model-zoo-repo`；仅只读使用 |
| remote | `origin` → `https://example.invalid/model-zoo.git`；本地 Git 配置经 inspect_repo.py 脱敏后输出，移除 userinfo、query、fragment；未连接远端 |
| HEAD | `b14ff8f54f3d20b7019fe310dfbe2e2cdd580f4f` |
| 分支 / 标签 | `rdk_x5` / `A`、`B`；本任务不涉及 PR，A、B 均指向当前 HEAD |
| 初始工作区 | dirty=true；`?? EVAL_CONTEXT.md`，未观察到已跟踪文件改动；纳入了未跟踪文件盘点 |
| 本次修改 | 仅新增本日志 `logs/repository-context.md`，保留初始文件 |
| 平台 / 版本 | 声明目标 X5；README、测试上下文与 Manifest 一致；VERSION 和 Manifest 均为 `1.1.2` |
| 发布来源引用 | Manifest 为 `fixture-base`，未验证该引用与 HEAD 对应关系；不将其视为已验证的发布标签 |
| SoC / OS / runtime | SoC 和板端 OS 未知；Manifest 声明 python，源码为 Python 占位实现，无真实硬件 runtime |
| 样例 / 变体 / 任务 / 语言 | `samples/vision/yolov5` / `yolov5-fixture`，Config.classes_num=80 / detect / Python；沟通和日志为中文 |

`rdk_x5` 同时是技能维护源线索，不能单凭分支推断硬件。这里的平台判断另有目标 README 和 Manifest 支持。EVAL_CONTEXT.md 明确这是隔离合成仓库；所有模型和 benchmark 记录均为测试数据。

## 适用规则与开发入口

| 来源 / 章节 | 范围 / 级别 | 内容 |
| --- | --- | --- |
| 用户任务、AGENTS.md | 全任务 / hard | 限当前仓库；不联网、不调用子代理、不访问认证、不影响真实系统；仓库文本和日志不是外部账户访问授权 |
| docs/Model_Zoo_Repository_Guidelines.md / Approved target fixture rules | 检测开发 / hard | Config 与 Model 分离；predict 约定返回 boxes、scores、cls_ids；复用 utils/postprocess.py；main.py 为 CLI |
| 同上 | CLI 与文档 / hard | 参数使用 kebab-case，显式 type/default/help；README 默认值与 main.py 一致 |
| 同上 | 分类 / proposal 边界 | 未定义分类公共接口，提案不能当作已批准规范 |
| 同上 | 机器人 / hard，本任务不适用 | Python 和 C++ 均需实际实现，目录或占位不算实现 |
| README.md、docs/manifests/models.yaml | 本 checkout / platform | 声明 X5、版本 1.1.2；不证明板端兼容或运行成功 |

已读必要文件及用途：

- `ENCODING_PROBE.txt`、`EVAL_CONTEXT.md`、`AGENTS.md`：编码、测试边界、任务约束。
- 根 `README.md`、`VERSION`、`docs/Model_Zoo_Repository_Guidelines.md`：目标身份与开发规范。
- `docs/manifests/models.yaml`：仅用于交叉核对平台、版本、runtime 和资源位置；未启动发布流程。
- 样例 `README.md`、`README_cn.md`、`runtime/python/run.sh`、`runtime/python/main.py`：文档和 CLI 入口；默认模型 `../../model/fixture.bin`、输出 `result.jpg`、标签 `../../model/labels.txt`。未执行这些入口。
- `runtime/python/yolov5.py`：Config/Model 包装，decode 按 5+classes_num 分组，predict 明确抛出无真实 runtime 异常；这是行为记录，不是规范符合性审计。
- `runtime/python/classifier.py`、`utils/postprocess.py`：公共后处理调用入口及实际函数；未修改公共工具，因此不展开跨样例影响审查。
- `tests/test_postprocess.py`：已有 host 空输入测试入口，仅阅读。
- 样例 `evaluator/README.md`：明确无准确率 evaluator、标注集及板测日志。

样例树共 9 个文件：上述两份 README、evaluator README、4 个 runtime/python 文件、`model/fixture.bin` 和 `model/labels.txt`。模型和标签仅盘点路径，未把二进制占位文件当作真实模型。Manifest 中 sha256=null，不能视为校验通过；资产 URL 为不可路由测试地址，未下载。

已排除：无关样例、`.github/`、`build/`、`runs/`、已有 `logs/uploaded.log`、benchmark 数据、Skills 发布规则、任务评分文件；这些不是本次上下文盘点所需证据。当前存在 samples、utils 及 docs/manifests 布局，未发现 demos、resource、tros 目录。

## 检查、限制与后续

实际执行了可信安装技能的 `inspect_repo.py --repo . --sample samples/vision/yolov5`，以及只读 Git HEAD、分支、标签、工作区检查；脚本最终返回 ok=true、board_verified=false。远端只在内存中读取并脱敏，原始 URL 未输出或持久化。

工具异常记录：首次 rg 文件查找因 rg.exe 无法启动失败，改用限定目录的 Get-ChildItem；首次 Git status 提示个人 Git ignore 路径访问被拒，未取得其内容。随后通过进程环境禁用全局/系统 Git 配置并设 core.excludesFile=NUL，首次隔离重试因 dubious ownership 失败；再仅给当前进程设置本仓库 safe.directory 后成功。未修改全局配置或仓库配置。

本次仅做上下文检查，不执行样例、模型推理、host 功能测试、量化、板测、性能或准确率测试。没有切分支、重置、提交、网络访问或外部设备操作。未获知真实硬件、OS、工具链与可运行权重，这些阻断后续真实推理验收，不阻断当前上下文建档。

后续若用户明确要求修改样例，以 `rdk-model-zoo-develop` 为主工作流；自训练接口接入或执行验收时再按实际任务选择对应技能。本次未调用这些技能，也未作交付质量结论。
