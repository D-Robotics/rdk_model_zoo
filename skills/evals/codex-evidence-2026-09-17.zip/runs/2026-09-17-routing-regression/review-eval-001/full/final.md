我会先读取测试上下文和编码探针，再使用 rdk-model-zoo-review 技能审查 A 到 B 的变更，区分 PR 引入的问题与历史缺项。

唯一变更把解码宽度从配置类别数改成固定 80 类，导致非 80 类配置出现回归。我会在仓库内提取已审阅的纯解码函数，对比 A/B 的行为；不运行样例入口或模型。历史上的推理实现和评估器缺项不会列为本次 PR 新增问题。

发现 1 项必须修复的回归。

- **major / confirmed｜Technical Correctness & Regressions｜regression**  
  位置：B 的 [yolov5.py:8](D:/20_Dev_Projects/21_RDK_MODEL_ZOO/rdk_model_zooo_mccc/.skill-eval-work/rdk-full-1y83j834/target/samples/vision/yolov5/runtime/python/yolov5.py:8)。`width=5+80` 忽略 `Config.classes_num`，破坏 A 中已有的可配置解码行为。3 类配置下，合法的 8 元素输入现在抛异常；680 元素输入则从正确的 85 行×8 列静默变成 8 行×85 列。最小修复：恢复 `5+self.config.classes_num`。

采用 `rdk-model-zoo-review` 的 **change-review** 流程，基于 base 规范审阅完整相关源码、文档和清单。A=`736d4e2`，B=`3a9a053`，merge-base=A；差异仅上述一行。

隔离 host 检查提取并执行了 A/B 的纯解码函数，确认以上回归；80 类和空输入行为一致。未修改文件，未运行样例、联网或上板；占位模型及合成性能记录不作为推理证据。

仓库规范维度未发现新增问题；交付规格：`No delivery specification available`。历史实现缺项未作为本次 PR 阻塞项。

**review_decision = changes-required**  
**delivery_readiness = not-ready**
