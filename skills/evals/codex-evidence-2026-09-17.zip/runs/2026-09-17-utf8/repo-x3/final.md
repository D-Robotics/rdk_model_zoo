我会使用主技能 `rdk-model-zoo-repo`，先检查编码探针和稀疏检出边界，再依据当前仓库证据识别平台及 YOLOv5 规范；全程只读，不运行样例。

当前检出为 detached HEAD，`EVAL_CONTEXT.md` 指向 `origin/rdk_x3`，版本文件为 `1.1.2`。样例文档同时包含 X3 和 X5 内容，我会结合当前清单与源码区分目标平台、跨平台说明和默认参数。

已使用主技能 **`rdk-model-zoo-repo`**，完成只读上下文检查；编码探针中文正常。

| 项目 | 结论与证据 |
|---|---|
| 目标仓库 | 当前工作目录为 `REPO_ROOT`；技能根为其下 `.agents/skills/rdk-model-zoo-repo`。 |
| Git 身份 | HEAD 为 `0eb344ba8bed76923a6bd696e468fd82489cf46e`，detached HEAD，无指向 HEAD 的本地 Tag；工作区 dirty，包含已修改文件及未跟踪技能、上下文文件。 |
| 平台与版本 | **RDK X3 / Bernoulli2，版本 1.1.2**。`EVAL_CONTEXT.md` 声明来源 `origin/rdk_x3`；`VERSION` 与 `docs/manifests/models.yaml` 交叉支持。清单声明 `x3-v1.1.2`，不等于已观测到该 Git Tag。 |
| 样例布局 | 使用历史 `demos/` 布局；重点目录 `demos/detect/YOLOv5`，含 Python 入口、两个 Notebook、中英文 README、`models/download.md`、PTQ YAML 和图片。 |
| 实际 runtime | `YOLOv5_Detect.py` 使用 `hobot_dnn.pyeasy_dnn` BSP Python API，输入转换为 NV12；基础类定义在本文件中，没有导入仓库公共 utils。 |
| 模型范围 | 清单与下载文档记录五个 X3、640×640、NV12 变体：v2.0 的 s/x，以及 v7.0 的 n/s/x。未选择或运行具体变体。 |

规范来源按层次区分：

- **硬约束**：用户的只读与禁止执行要求，以及技能 `context-policy.md` 的目标身份、证据和权限规则。
- **平台及历史约定**：当前检出的根 README、样例 README、下载文档，以及清单 README 的 `Evidence rules`。未发现目标版本的 `AGENTS.md` 或 `Model_Zoo_Repository_Guidelines.md`；不以维护源 X5 规范覆盖 X3 历史布局。
- **已知不一致**：清单 README 仍写 `x3-v1.0.0`，而版本文件与清单为 `1.1.2`；样例 README 写 `model/download.md`，实际为 `models/download.md`；源码默认模型为 672×672，与清单的 640×640 资产不同。这些均保留报告，未修改。

未验证硬件、系统、模型可下载性、校验和、兼容性、精度或性能；未运行样例、安装依赖、联网或调用子代理。无关路径按稀疏检出边界排除，不判为缺陷。Git 曾自动尝试访问个人 ignore 路径并被拒绝，未取得其内容。
