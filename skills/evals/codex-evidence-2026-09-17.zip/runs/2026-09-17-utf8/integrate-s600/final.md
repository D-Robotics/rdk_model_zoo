我会先检查编码探针和稀疏检出说明，再使用适用的模型接入技能，核对 YOLOv5 的接口和 S600 工具链交接要求。


编码探针显示正常。检出基于 `origin/rdk_s`，技能副本来自 `rdk_x5`；我会以目标 S600 和当前源码为依据，使用 `rdk-model-zoo-integrate` 主技能。


已确认：仅替换标签不够，Python 解码仍默认 80 类；C++ 的 `num_classes` 配置没有传给解码函数，还需核对共享实现。现有入口也会在模型缺失时下载官方权重。接下来我会补齐前后处理约束，并用 `rdk-model-zoo-validate` 技能整理后续验证计划。


**目前可完成接口分析，但不能判定三类别 ONNX 可直接接入。**工具链产物尚缺；样例需要同步调整类别配置、输出解码及模型加载路径。

使用主技能 `rdk-model-zoo-integrate`，辅以 `rdk-model-zoo-validate` 制定验证计划。证据基于提交 `380e1a2bf42041af54be6f34935e50197cfadff9`；`EVAL_CONTEXT.md`、根 README 和模型清单均指向 S 系列。技能维护源为 X5 不影响目标选择，**交接目标始终为 S600**。

| 接口 | 当前代码证据及接入要求 |
|---|---|
| 运行时 | Python 使用 `hbm_runtime.HB_HBMRuntime`；C++ 使用 HB-DNN/UCP。需要匹配 S600 和实际 runtime 版本的 HBM，ONNX 不能直接替换，也不能改后缀冒充。 |
| 输入 | Python 按前两个输入依次提交 NV12 的 Y、UV，形状分别为 `[1,H,W,1]`、`[1,H/2,W/2,2]`；从第一个输入的第 1、2 维读取 H/W。必须逐节点核对名称、次序、dtype、布局及尺寸。 |
| 预处理 | 默认 BGR→letterbox→NV12；Python padding 为 **127**。需对齐训练/导出的色彩、插值、取整、padding、归一化，并明确哪些步骤由编译器吸收，避免重复处理。 |
| 三类别 | 标签按训练索引核实为 `0=person、1=helmet、2=vest`。Python `classes_num` 默认 80，入口未覆盖；仅传三行标签文件不会改变解码，需显式设为 3。 |
| 输出 | Python 假设 batch=1、每尺度 3 个 anchor，将输出 reshape 为 `[1,h,w,3,5+nc]`，再执行 sigmoid 和 anchor 解码。若保持此合同，三类别每尺度通道为 **24**；这只是样例要求，并非已确认的 ONNX 输出。 |
| 输出顺序 | runtime 输出列表按位置对应 strides `[8,16,32]` 和默认 anchors。须核实真实 anchors、尺度与节点映射；已解码、已 sigmoid 或含 NMS 的输出不能再次套用当前解码。 |
| 反量化 | Python 依赖输出 quant metadata；C++ 固定调用 `dequantizeTensorS32`。需核对 dtype、scale、zero point、axis、存储对齐及反量化责任。 |
| C++ 特有约束 | `hw_list` 固定为 `84/42/21`，对应默认 672 输入；`num_classes=80` 虽有配置，但调用解码函数时未传递。必须继续核实共享解码实现，不能认为改配置即可生效。 |
| 加载入口 | Python 模型缺失时会下载官方权重，即使指定了自定义路径；两个 `run.sh` 还包含安装、下载和执行。后续应让自定义模型缺失时明确失败，并同步模型、标签路径；C++ 默认模型路径仍为 S100。 |

主要源码证据：`runtime/python/{yolov5.py,main.py,run.sh}`、`runtime/cpp/{inc/yolov5.hpp,src/yolov5.cpp,src/main.cpp,run.sh}`、`utils/py_utils/{preprocess.py,postprocess.py}`。`conversion/README.md` 和 `evaluator/README.md` 均为待补充，不能作为现成转换或验收流程。

**工具链交接需补齐：**

- ONNX 文件路径及哈希、YOLOv5 变体/上游版本、导出参数/opset、动态维度、真实输入输出信息，以及是否包含 sigmoid、decode、NMS。
- 训练类别顺序、anchors/strides、预处理协议、浮点基线；校准集与独立验证集及使用许可。
- S600 系统和 runtime 版本、精度容差、性能口径、资源预算及独立输出目录。

交给匹配 S600 的 **S 系列 OE Pack／`horizon-router`**，范围限定为检查 ONNX、确认合同并生成目标产物。当前发现的技能中没有该 router，其版本和完整资源树未核验；本次不安装、不调用，也不替换成 X5 工具链。未知交接字段保持 `null`。

返回材料应包含原始 HBM、转换配置、完整 I/O 与量化 metadata、工具版本、模型/数据哈希、执行日志和原始验证收据。官方清单虽列出 S600 YOLOv5 HBM，但其 `sha256: null`，且不能证明自训练模型兼容。

后续验证顺序：

1. **静态合同检查**：逐输入输出匹配，检查三类别 reshape、标签、anchors、节点顺序、路径及缺失模型行为。
2. **主机数值对照**：同一输入比较浮点 ONNX、工具链结果与样例解码；覆盖空检测、非方形图片、边界框和三类别，预先确定容差。
3. **S600 板端验证**：加载与 smoke，再做独立数据集逐类 AP/mAP；需要双语言交付时比较 Python/C++。
4. **性能验证**：分别记录纯推理与端到端耗时，固定预热、次数、batch、核配置和环境。

本次仅只读分析，未修改、安装、联网、量化或运行模型。C++ 共享 `utils/c_utils` 未在当前检出中呈现，按稀疏边界保留未知；未检查实际 ONNX、编译产物或板卡，数值、精度、性能及硬件兼容性均为 **not-run**。
