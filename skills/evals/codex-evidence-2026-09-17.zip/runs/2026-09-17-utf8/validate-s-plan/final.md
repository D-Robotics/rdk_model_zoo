我会使用 `rdk-model-zoo-validate` 主技能，先检查编码探针和稀疏检出边界，再只读核查 YOLOv5 的 evaluator/runtime，列出验证条件、门禁和未运行原因。

已确认 YOLOv5 的 evaluator 只有“待补充”说明，现有入口仍按 80 类配置；Python 封装可配置类别数，但 CLI 没有暴露该参数，C++ 的类别数还需核对解码器调用。三类别接入因此不能只替换权重和标签文件；矩阵会单独列出接口适配、数值一致性和精度门禁。

已按 **`rdk-model-zoo-validate`** 完成只读核查与验证矩阵；**未执行样例、未生成通过结果**。

目标绑定 `samples/vision/yolov5`、S600、三类别自训练检测模型。HEAD 为 `380e1a2bf42041af54be6f34935e50197cfadff9`，处于 detached HEAD；`EVAL_CONTEXT.md` 标明来源为 `origin/rdk_s`。工作区有技能及上下文文件未跟踪，不能记录为完全 clean。编码探针正常。

**可复用能力与限制**

- [evaluator/README.md](${EVAL_ROOT}/target/samples/vision/yolov5/evaluator/README.md) 仅为“待补充”，当前检出中没有可直接运行的 YOLOv5 精度 evaluator。
- [Python wrapper](${EVAL_ROOT}/target/samples/vision/yolov5/runtime/python/yolov5.py) 可复用 `hbm_runtime` 推理及前后处理。配置支持 `classes_num`，但默认 80，`main.py` 未暴露类别数参数；只替换模型和三行标签不够。
- C++ 使用 HB-DNN/UCP；配置仍为 80 类、固定特征图 `84/42/21`。`post_process()` 调用解码器时没有显式传递 `num_classes`。其依赖的 `utils/c_utils` 当前未物化，解码器默认行为尚无法确认；不能据此判定仓库缺文件。
- `utils/py_utils` 可复用 NV12 转换、反量化、置信度过滤、分类 NMS 和坐标还原，但后处理模块依赖 `hbm_runtime`，不是无依赖的本机 evaluator。

| 验证项 | required / 层次 | 条件与预先约定的验收标准 | 当前状态 |
|---|---|---|---|
| 本机静态检查 | true / static | 核对类别数、三类标签顺序、CLI→配置→解码传参、路径及下载副作用 | 已只读核查，发现上述适配缺口；不作通过判定 |
| 本机离线前后处理 | true / host | 准备依赖及可信固定输入/输出夹具；覆盖非方形图、空检测、三类重叠、阈值边界；类别必须在 `0..2`，输出有限且坐标合法 | **not-run**：未提供夹具，本次仅制定计划 |
| 编译产物接口一致性 | true / static＋board | 提供 S600 HBM、编译记录及 I/O metadata；核对 NV12 双输入、shape/layout/dtype、输出顺序、量化轴/scale/zero-point、anchors/strides | **not-run**：无编译产物。若沿用现有三 anchor 原始检测头，每位置应为 `3×(5+3)=24` 通道，须以实际导出合同确认 |
| Python/C++ 数值一致性 | 双实现交付时 true / host＋board | 同模型、同输入，逐阶段比较预处理、反量化、解码与 NMS；明确匹配规则、坐标/分数容差，执行前冻结，不能默认 bitwise | **not-run**：缺产物、板卡、参考输出；C++ 公共实现未核查完整 |
| 三类别精度 | true / host＋board | 独立标注评估集、类别 ID 映射、浮点基线及预测导出适配；统计 mAP@0.5、mAP@0.5:0.95、每类 AP/召回；预先确定绝对下限及相对基线允许下降值 | **not-run**：无标注数据、产物与基线；evaluator 待补齐，精度阈值待定 |
| S600 smoke | true / board；两种 runtime 分别记录 | S600、匹配 SDK/runtime、三类 HBM 与真实输入；加载及推理成功、无异常，类别/框有效，本次输出可追溯；覆盖正例和空结果 | **not-run**：无板卡及产物 |

现有 smoke 默认 `score=0.25`、`NMS IoU=0.45`，只是推理参数，**不是精度通过阈值**。自训练输入尺寸和 anchors 尚未知，不能直接沿用默认 672 输入及固定特征图尺寸。

后续命令应在三类适配完成后冻结：Python 的 cwd 为 `runtime/python`，显式传入模型、图片、三类标签和隔离输出路径；C++ 使用源码实际定义的下划线参数，例如 `--model_path`。不直接使用 `run.sh`，因为它会安装依赖、下载模型；Python 入口遇到缺失模型也会下载。当前没有足够条件给出可验收的精度执行命令。

所有未运行行应记录 `execution: null`、真实阻断原因，未知模型/输入哈希保持空值；未来执行再保存 argv、cwd、版本、日志、退出码、哈希及指标。本次未验证编译、真实 I/O、数值、精度、板端兼容性或性能，未写文件，也未运行证据校验器。
