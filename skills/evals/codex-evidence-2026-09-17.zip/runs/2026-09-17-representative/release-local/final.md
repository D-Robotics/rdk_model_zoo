我会使用 `rdk-model-zoo-release` 主技能，先读取稀疏检出边界，再核对本地 Skills Pack 版本、发布规范和验证证据；全程只读，不联网或执行发布操作。

本次主技能为 `rdk-model-zoo-release`，模式为 `skills-release`。**本地检查受阻，不能判定发布准备完成；未发布。**

读取 `EVAL_CONTEXT.md` 的只读命令被执行策略拒绝，禁用 PowerShell 配置加载后仍被拒绝。因此未能读取稀疏检出边界、本地包及验证说明，也不能把未读取文件判为缺失。

依据你提供的技能内容，版本应严格区分：

| 对象 | 版本／Tag 规则 |
|---|---|
| Skills Pack | `skills/VERSION`；裸 `vMAJOR.MINOR.PATCH` |
| 单个 Skill | 各自 `SKILL.md` 的版本，独立于 Pack 版本 |
| 模型版本 | 根 `VERSION`；`x5-v*`、`s-v*`、`x3-v*` 模型 Tag 线保持独立 |

目前**未满足的是检查证据要求**：候选提交、版本与 CHANGELOG 一致性、自包含与引用、行为评测、许可来源及发布隔离均未验证。正式 Release 的非草稿、非预发布和 `latest=false` 要求也未核实，不能据此断言仓库存在缺陷。

未联网、未访问认证目录或个人配置、未调用子代理、未安装依赖或运行模型，也未改文件、创建 Tag、发布或推送。
