# 隔离认证与七个代表场景验证

2026-09-17。完成本轮要求的两步：恢复隔离 Codex 会话认证；在真实版本的临时稀疏检出中运行七个技能的代表任务。**七项观察到的任务结果符合预期，但不等同于完整行为验收。**

## 环境修复与发现

- 原隔离环境缺少认证，返回 401。将现有登录缓存复制到临时私有 CODEX_HOME 后认证可用；每次执行比较源认证文件摘要，均保持不变，临时目录随运行结束清理。
- 全局 CLI 0.145.0 不支持当前 gpt-6-astra；改用桌面应用自带的 0.155.0-alpha.2.6，未替换全局 CLI、模型或配置。认证探测实际返回 READY，见 [探测证据](../2026-09-17-representative/auth-probe.json)。复用缓存方式参考 [OpenAI 认证文档](https://learn.chatgpt.com/docs/auth)。
- app-server skills/list 在新会话中发现七个 repo 技能，均启用、解析错误为空，见 [实际发现响应](../2026-09-17-representative/discovery.json)。这验证本机该版本的发现能力，不代表所有宿主均接受顶层 version。
- 首批七次运行的 shell 读取被策略拒绝，已保留并标为 environment-blocked，不能因退出码为 0 计为通过。重试使用工作区内临时 HOME、明确的 Windows elevated sandbox 配置，并清除子进程继承的桌面会话 CODEX_* 变量；仍为 read-only、approval never。未放宽为无沙箱。

## 实际结果

每个目录包含 prompt.txt、fixture.json（目标提交与输入文件摘要）、events.jsonl（实际命令及输出）、stderr.log、final.md、execution.json（变更对比和逐项判定）。[汇总 JSON](results.json) 保留判断理由；判断由父 Codex 会话完成，不冒称独立人工验收。

| 场景 | 目标 | 观察到的结果 |
|---|---|---|
| [仓库识别](repo-x3/final.md) | X3 | 识别 1.1.2、demos 布局和 Bernoulli2；没有套用 X5 规范；执行了仓库检查器 |
| [现成模型查询](lookup-x3/final.md) | X3 | 找到真实 Python 入口与模型资产；指出默认模型/文档路径偏差；给出基于源码的准备命令 |
| [三类别接入](integrate-s600/final.md) | S600 | 核对 NV12、输出头与类别数合同；标明缺失 metadata/产物/S 工具链，没有替用 X5 |
| [代码评审](review-s/final.md) | S 系列 | 检出临时 fixture 中固定 80 类的 reshape 回归，定位 147 行；changes-required 与 not-ready 分别说明 |
| [开发方案](develop-s-plan/final.md) | S600 | 提出真实入口参数透传、标签校验、默认行为保留和防止错权重回退的最小方案 |
| [验证计划](validate-s-plan/final.md) | S600 | 识别 evaluator 占位，区分 host/接口/精度/板端条件；没有虚构通过 |
| [发布准备](release-local/final.md) | X5 上维护的 Skills Pack | 实跑同步/包检查；分开 Pack、成员和模型版本；指出发布隔离及验收缺口，未发布 |

X3 提交：`0eb344ba8bed76923a6bd696e468fd82489cf46e`；S 系列：`380e1a2bf42041af54be6f34935e50197cfadff9`；X5 发布准备基线：`7265e41dbea29574b9b8e3cef61f189960db5b4c`。候选技能以文件摘要绑定，不能将基线提交解释为已包含未提交的技能包。

七个目标工作区的运行前后文件摘要均无变化。评审缺陷只存在于已清理的临时 fixture，其 [patch](review-s/fixture.patch) 明确留档。发布场景读取的是运行开始时复制的旧验证报告，所以它提到“全部未运行”；本报告是在新一轮结果审阅后更新的状态，不回写或篡改历史输出。

## 限制与后续边界

- 部分 Windows PowerShell 文件读取的中文出现乱码；英文标识、代码、路径和最终中文回答可读。这里仅判定可从轨迹和结果核对的任务断言，**不据此证明完整中文技能指令被正确理解**。完整用例启动前应固定 UTF-8 读取/输出并增加编码探测。
- 子会话缺少 rg 时改用 PowerShell；Git 自动尝试读取个人 ignore 文件被沙箱拒绝，未主动打开认证文件。后台插件目录刷新出现 503 警告，未阻断任务。未连接板卡、下载模型、安装依赖、执行推理或发布。
- 75 条核心用例、对应 baseline/agents-only 和跨平台 overlay 仍未运行；本轮代表场景不替代它们，不证明技能相对无技能有增益。未覆盖 prompt injection 等完整负向门禁。
- release 场景发现的现有 Pages 并发隔离风险保留为正式发布前事项，本轮没有修改既有发布流程。

[执行脚本快照](runner-snapshot.py) 和 [发现脚本快照](discovery-runner-snapshot.py) 记录本机调用方式，含本机路径，需要在其他机器上调整。它们不是通用安装入口。源码、许可和全局技能保持原状；本轮只新增评测记录及更新验证说明。


## 编码诊断更正（2026-09-17 后续验证）

后续直接检查原始 JSONL 后确认：七个场景的实际命令输出均没有 Unicode 替换乱码，中文技能内容在原轨迹中可读。先前看到的乱码来自父会话读取报告时 Python 使用本机默认编码输出、外层按 UTF-8 解码的边界，不是 Agent 原始读取损坏。上文关于“完整中文理解因乱码受限”的归因予以撤回；仍不以代表场景证明完整行为验收。[回归诊断](../2026-09-17-utf8/encoding-regression.json) 已通过默认输出失败、显式 UTF-8 成功的对照复现。
