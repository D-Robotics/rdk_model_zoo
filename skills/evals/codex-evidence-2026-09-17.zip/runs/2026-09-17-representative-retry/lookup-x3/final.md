我会先读取稀疏检出说明，并使用 `rdk-model-zoo` 技能核对当前版本的 YOLOv5 Python 入口、模型来源和输入要求，全程只读。


已确认这是 `rdk_x3` 的稀疏检出，`demos` 是该版本的正常布局。Python 入口默认模型名与下载文档中的 X3 资产名不一致，因此准备步骤会显式指定模型和测试图片路径。


**正常，当前 X3 版本使用 `demos/`。** 本次主技能为 `rdk-model-zoo`；依据 `EVAL_CONTEXT.md`、实际源码和模型清单核对。当前提交为 `0eb344ba8bed76923a6bd696e468fd82489cf46e`，清单标注 X3、版本 `1.1.2`、`x3-v1.1.2`。技能维护源是 X5，不改变本次 X3 目标。

1. **真实入口**：`demos/detect/YOLOv5/YOLOv5_Detect.py`。它使用 BSP 的 `hobot_dnn.pyeasy_dnn`，直接依赖 OpenCV、NumPy、SciPy。准备板端 Python 环境时应确认这些依赖可用；运行此入口无需重新导出、量化模型。

2. **模型获取位置**：实际文件为 `demos/detect/YOLOv5/models/download.md`，README 写的 `./model/download.md` 有路径偏差。选择其中 **Bernoulli2 / RDK X3** 资产，例如：
   `yolov5s_tag_v2.0_detect_640x640_bernoulli2_nv12.bin`  
   文档及 `docs/manifests/models.yaml` 均记录了[该模型下载地址](https://archive.d-robotics.cc/downloads/rdk_model_zoo/rdk_x3/yolov5s_tag_v2.0_detect_640x640_bernoulli2_nv12.bin)。后续获取后放入样例的 `models/` 目录。

3. **输入要求**：提供 OpenCV 能读取的普通彩色图片。代码读取 BGR 图像，按模型尺寸直接缩放至 640×640，再转换成 UINT8 NV12；不是 letterbox，也不要求用户预先准备 NV12 文件。该样例按 COCO 80 类解码，代码实际固定 `self.nc = 80`。

4. **后续板端运行命令**如下，本次未执行。将图片路径替换为真实文件，并从样例目录启动：
   ```bash
   cd "$REPO_ROOT/demos/detect/YOLOv5"
   python3 YOLOv5_Detect.py \
     --model-path models/yolov5s_tag_v2.0_detect_640x640_bernoulli2_nv12.bin \
     --test-img /absolute/path/test.jpg \
     --img-save-path result_x3.jpg
   ```
   必须显式指定模型：源码默认值是 `models/yolov5s_672x672_nv12.bin`，与上述资产不一致。默认图片 `../../../resource/assets/bus.jpg` 在当前稀疏检出中不可见，可自行提供图片；这不能判定为仓库缺陷。运行将写入或覆盖 `result_x3.jpg`，并输出检测日志。

**证据与未验证范围**：已静态核对入口的参数、模型加载、预处理、后处理和保存逻辑，以及清单与下载文档。未联网、下载、安装或运行模型；无板卡，板端兼容性、检测效果和性能均为 **not-run**。清单的模型 `sha256` 为 `null`，文件完整性尚未验证。
