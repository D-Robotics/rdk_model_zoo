我将使用 `rdk-model-zoo-validate`，先读取稀疏检出边界与技能要求，再检查 YOLOv5 可复用的 evaluator/runtime，制定验证矩阵；不运行样例或生成通过结果。


当前 YOLOv5 的 evaluator 只有“待补充”说明；Python/C++ runtime 可复用，但入口仍默认 80 类，不能仅替换权重和标签就认定完成三类别接入。我会继续核对共享评估代码、输出契约和脚本副作用。


已使用主技能 **`rdk-model-zoo-validate`** 完成只读检查与验证计划，未运行样例、安装依赖、生成通过结果。

目标为 `samples/vision/yolov5`、**S600、三类别自训练检测模型**。`EVAL_CONTEXT.md` 与 HEAD 均指向 `380e1a2bf42041af54be6f34935e50197cfadff9`，来源为 `origin/rdk_s`；技能的 `rdk_x5` 维护来源不替代目标版本。Git 状态仅列出未跟踪的 `.agents/`、`EVAL_CONTEXT.md`。

**可复用内容与接入缺口**

- [evaluator/README.md](${EVAL_ROOT}/target/samples/vision/yolov5/evaluator/README.md) 只有“当前内容待补充”，没有可直接运行的精度 evaluator。
- Python 可复用 `YoloV5X` 的预处理、推理、后处理，以及 `utils/py_utils` 的 NV12 转换、反量化、置信度过滤、分类别 NMS、坐标还原。它们不是完整评估器。
- [Python wrapper](${EVAL_ROOT}/target/samples/vision/yolov5/runtime/python/yolov5.py) 支持 `classes_num`，但默认 **80**；`main.py` 未提供类别数参数，也未传入三类别配置。仅换标签文件不足以完成接入。
- C++ 默认 `num_classes=80`、特征图尺寸 `84/42/21`；[后处理调用](${EVAL_ROOT}/target/samples/vision/yolov5/runtime/cpp/src/yolov5.cpp) 未显式传递 `num_classes`，且使用 `dequantizeTensorS32`。其依赖的 `utils/c_utils` 未在当前稀疏工作区物化，不能据此认定仓库缺文件或三类别解码可用。
- `run.sh` 包含安装、下载及构建操作；Python 入口也会在模型缺失时下载公共权重，因此不宜直接作为自训练模型验收命令。

**验证矩阵**

本计划以 Python 为最低交付范围；若同时交付 C++，对应构建和双实现一致性检查也必须通过。

| 检查 / 层次 | required | 条件与判定标准 | 当前状态 |
|---|---|---|---|
| 本机静态检查 / static | true | 三类别配置贯通；标签恰为 3 项且顺序对应训练 ID；anchors、strides、尺寸与导出记录一致；显式模型路径；检查下载及输出副作用 | 已完成源码检查，发现上述接入缺口；不作通过判定 |
| 本机离线检查 / host | true | 准备隔离测试入口及依赖；检查长宽图、奇数尺寸、空检测、阈值边界、不同类别重叠框；输出无 NaN/Inf，类别限于 `0..2`，空结果形状正确 | `not-run`：本次仅只读分析；尚无测试入口与固定参考数据。wrapper 和共享后处理直接依赖 `hbm_runtime`，不能假定普通主机可直接导入 |
| 模型 I/O 契约 / static→board | true | 提供 S600 编译产物、编译记录及 metadata；核对 NV12 Y/UV 输入、布局、dtype、量化参数、输出名称顺序。现有 Python 解码按三 anchor 原始头重排，三类别每 anchor 为 `5+3=8`，合并通道为 24；已解码或带 NMS 输出不能直接套用 | `not-run`：无编译产物；实际 shape、输出顺序与量化契约未知 |
| Python/C++ 数值一致性 / host＋board | 双实现交付时 true | 同模型、输入、阈值、预处理；逐阶段比较 NV12、反量化、解码、NMS 和最终框。核对 padding 舍入、类别数传递、C++ 固定尺寸及 S32 假设 | `not-run`：缺产物、板卡、C++ 依赖源码及参考输出 |
| 三类别精度 / host＋board | true | 独立标注评估集与校准集隔离；固定类别映射、训练浮点基线及 evaluator 版本；报告 mAP50、mAP50:95、逐类 AP/召回率，比较部署结果与基线 | `not-run`：缺标注、基线、编译产物；当前 sample evaluator 尚未实现 |
| S600 smoke / board | true | 实际 S600、匹配的 HBM runtime／DNN-UCP、可信产物；真实图片覆盖三类、背景和不同宽高比；加载与推理成功、输出语义合法、本次结果可追溯，错误输入可诊断 | `not-run`：无板卡和产物；Python/C++ 分别记录，不相互代替 |

阈值须在执行前冻结：smoke 可暂沿用源码的 `score=0.25、NMS=0.45`；它们不是精度达标阈值。数值容差、最低 mAP／逐类召回率及允许精度下降目前均**待基线确定**，不能凭空填写，也不默认要求 bitwise 一致。

当前无法给出可直接执行的三类别验收命令：入口尚未接通类别配置，evaluator 缺实现，实际模型契约未知。后续命令应显式绑定模型、输入、三类标签和独立输出目录，避免触发公共权重下载。

未验证范围包括主机功能、构建、数值、精度、S600 加载和性能。后续按技能证据契约记录真实 argv/cwd、退出码、日志、环境版本及模型/输入哈希；未执行行保持 `not-run`、`execution: null`。本次没有写入文件或访问网络。另，首次 Git 状态查询自动尝试读取用户级 ignore，权限拒绝，未取得内容；未主动读取认证或个人配置。
