from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,shutil,subprocess,sys,tempfile,tomllib
ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT/'_worktrees/model-zoo-skills'
PACK=REPO/'skills'
OUT=PACK/'evals/runs/2026-09-17-representative-retry'
EXE=Path('C:/Users/chao04.ma/AppData/Local/OpenAI/Codex/bin/eab8377aebac6c07/codex.exe')
AUTH_HOME=Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))
CONFIG=tomllib.loads((AUTH_HOME/'config.toml').read_text(encoding='utf-8'))
SKILLS=sorted(p for p in PACK.glob('rdk-model-zoo*') if (p/'SKILL.md').is_file())
CASES={
 'repo-x3':('origin/rdk_x3','rdk-model-zoo-repo','本次使用 $rdk-model-zoo-repo。技能来自 rdk_x5 主分支的统一维护源，但当前 REPO_ROOT 是本工作目录。请识别当前平台、版本、样例目录和规范来源，重点查看 demos/detect/YOLOv5。不要因为技能来源把任务判成 X5。只读，不运行样例。'),
 'lookup-x3':('origin/rdk_x3','rdk-model-zoo','我用 RDK X3，想运行当前版本现成 YOLOv5 检测样例。请查找真实 Python 入口、模型获取位置、输入要求，给出基于实际代码的运行准备步骤。我发现目录是 demos 而不是 samples，这正常吗？只查阅，不下载或执行模型。'),
 'integrate-s600':('origin/rdk_s','rdk-model-zoo-integrate','我要把自训练的三类别 YOLOv5 接入 samples/vision/yolov5，目标板为 S600。标签为 person、helmet、vest；目前只有 ONNX，没有已编译 BPU 产物，也未提供输出 metadata。请基于当前代码检查需要对齐的接口、说明缺失信息、给出工具链交接和后续验证计划。只读，不安装、量化或上板；不能因为技能维护源是 X5 就使用 X5 工具链。'),
 'review-s':('origin/rdk_s','rdk-model-zoo-review','请 review 当前工作区 samples/vision/yolov5/runtime/python/yolov5.py 的未暂存修改，聚焦是否引入功能回归。保持原公开接口及自定义类别数能力，按实际目标版本规范评审。只读，不运行代码、不修改文件。请给出有证据的 finding（如有）和独立的交付就绪结论。'),
 'develop-s-plan':('origin/rdk_s','rdk-model-zoo-develop','使用 $rdk-model-zoo-develop，给出一个最小开发修改方案：为 samples/vision/yolov5 的 Python 入口支持三类别模型和对应标签。只读检查当前入口与 wrapper，说明需要改哪些真实参数或调用点以及如何回归；这一回合只给方案，不改文件、不做量化。目标是 S600，不能推断其他 S 板卡兼容。'),
 'validate-s-plan':('origin/rdk_s','rdk-model-zoo-validate','使用 $rdk-model-zoo-validate，为 samples/vision/yolov5 的 S600 三类别自训练模型接入制定验证矩阵。现在没有板卡、编译产物和标注数据，请检查仓库可复用的 evaluator/runtime，分别列本机检查、接口一致性、精度与板端 smoke 的条件和当前状态，不执行样例，不生成通过结果。'),
 'release-local':('origin/rdk_x5','rdk-model-zoo-release','使用 $rdk-model-zoo-release，只检查当前 Skills Pack 发布准备情况，区分 skills/VERSION 与根 VERSION、成员版本及模型 Tag 线。读取本地包和验证说明，指出未满足项。不得联网检查远端、创建 Tag、发布、推送或改文件；本次是本地准备检查。')}

def git(cwd,*args):
 p=subprocess.run(['git','-C',str(cwd),*args],capture_output=True,text=True,encoding='utf-8',errors='replace')
 if p.returncode:raise RuntimeError('git failed: '+str(args)+' '+p.stderr[-400:])
 return p.stdout.strip()

def tree_digest(repo):
 paths=git(repo,'ls-files','--cached','--others','--exclude-standard','-z').split('\0')
 rows={}
 for name in paths:
  p=repo/name
  if name and p.is_file():rows[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 return rows

def run(ident):
 ref,primary,prompt=CASES[ident];destination=OUT/ident;destination.mkdir(parents=True,exist_ok=True)
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 auth_before=hashlib.sha256((AUTH_HOME/'auth.json').read_bytes()).hexdigest()
 with tempfile.TemporaryDirectory(prefix='rdk-skill-case-',dir=ROOT/'.skill-eval-work') as temp:
  base=Path(temp);home=base/'codex';home.mkdir();repo=base/'target'
  subprocess.run(['git','clone','--quiet','--shared','--no-checkout',str(REPO),str(repo)],check=True,capture_output=True)
  sha=git(REPO,'rev-parse',ref)
  sample='demos/detect/YOLOv5' if ref.endswith('rdk_x3') else 'samples/vision/yolov5'
  git(repo,'sparse-checkout','set','--cone','docs',sample,'utils/py_utils')
  git(repo,'checkout','--quiet','--detach',sha)
  for d in SKILLS:shutil.copytree(d,repo/'.agents/skills'/d.name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  if ident=='review-s':
   p=repo/'samples/vision/yolov5/runtime/python/yolov5.py';text=p.read_text(encoding='utf-8')
   old='feat = out.reshape(1, h, w, 3, 5 + classes_num)';assert text.count(old)==1
   p.write_text(text.replace(old,'feat = out.reshape(1, h, w, 3, 5 + 80)'),encoding='utf-8',newline='\n')
   (destination/'fixture.patch').write_text(git(repo,'diff','--',str(p.relative_to(repo))),encoding='utf-8')
  if ident=='release-local':shutil.copytree(PACK,repo/'skills',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','runs','*.pyc'))
  (repo/'EVAL_CONTEXT.md').write_text('This is a read-only sparse local checkout of '+sha+' from '+ref+'. Sample, docs and utils paths are materialized. Missing unrelated paths can be sparse omissions, not repository defects. Skills are copies of the candidate maintained on rdk_x5. No board is attached. Do not read authentication or user profile files.\n',encoding='utf-8')
  before=tree_digest(repo)
  (destination/'fixture.json').write_text(json.dumps({'ref':ref,'commit':sha,'sparse_paths':['docs',sample,'utils/py_utils'],'synthetic_change':ident=='review-s','files_sha256':before},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  shutil.copy2(AUTH_HOME/'auth.json',home/'auth.json')
  lines=['model = '+json.dumps(CONFIG['model']),'approval_policy = "never"','sandbox_mode = "read-only"','cli_auth_credentials_store = "file"']
  if CONFIG.get('model_reasoning_effort'):lines.append('model_reasoning_effort = '+json.dumps(CONFIG['model_reasoning_effort']))
  lines+=['[windows]','sandbox = '+json.dumps(CONFIG.get('windows',{}).get('sandbox','elevated'))]
  for folder in [Path.home()/'.agents/skills',AUTH_HOME/'skills']:
   for f in folder.rglob('SKILL.md'):lines+=['[[skills.config]]','path = '+json.dumps(str(f)),'enabled = false']
  (home/'config.toml').write_text('\n'.join(lines)+'\n',encoding='utf-8')
  full='请完成下面这次真实只读使用任务。当前工作目录即 REPO_ROOT；先看 EVAL_CONTEXT.md 了解稀疏检出边界。请使用已发现的适用技能。不要访问认证目录或个人配置，不要调用子代理或浏览网络，不安装依赖或运行模型；可以读取源码和运行技能的只读辅助工具。最终用中文简明回答，说明所用主技能、证据和未验证范围。\n\n'+prompt
  (destination/'prompt.txt').write_text(full,encoding='utf-8')
  args=[str(EXE),'exec','--ephemeral','--json','-C',str(repo),'--',full]
  env={**{k:v for k,v in os.environ.items() if not k.startswith('CODEX_')},'CODEX_HOME':str(home),'PYTHONUTF8':'1','PATH':str(ROOT/'.venv-skills/Scripts')+os.pathsep+os.environ['PATH']}
  try:
   proc=subprocess.run(args,env=env,stdin=subprocess.DEVNULL,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=420)
   code=proc.returncode;stdout=proc.stdout;stderr=proc.stderr
  except subprocess.TimeoutExpired as exc:
   code=124;stdout=exc.stdout or '';stderr=exc.stderr or ''
   if isinstance(stdout,bytes):stdout=stdout.decode('utf-8','replace')
   if isinstance(stderr,bytes):stderr=stderr.decode('utf-8','replace')
  # No credential contents are emitted; replace only ephemeral filesystem roots.
  stdout=stdout.replace(str(base),'${EVAL_ROOT}').replace(str(base).replace('\\','/'),'${EVAL_ROOT}')
  stderr=stderr.replace(str(base),'${EVAL_ROOT}').replace(str(base).replace('\\','/'),'${EVAL_ROOT}')
  (destination/'events.jsonl').write_text(stdout,encoding='utf-8');(destination/'stderr.log').write_text(stderr,encoding='utf-8')
  final=[];commands=[];usage=None
  for line in stdout.splitlines():
   try:r=json.loads(line)
   except ValueError:continue
   item=r.get('item',{})
   if r.get('type')=='item.completed' and item.get('type')=='agent_message':final.append(item.get('text',''))
   if r.get('type')=='item.completed' and item.get('type')=='command_execution':commands.append({'command':item.get('command'),'exit_code':item.get('exit_code')})
   if r.get('type')=='turn.completed':usage=r.get('usage')
  (destination/'final.md').write_text('\n\n'.join(final)+'\n',encoding='utf-8')
  after=tree_digest(repo);changed=[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)]
  result={'case_id':ident,'expected_primary_skill':primary,'ref':ref,'commit':sha,'cli_version':'0.155.0-alpha.2.6','model':CONFIG['model'],'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'agent_messages':len(final),'commands':commands,'usage':usage,'changed_fixture_files':changed,'source_auth_unchanged':hashlib.sha256((AUTH_HOME/'auth.json').read_bytes()).hexdigest()==auth_before,'verdict':'pending-semantic-review','source_skill_sha256':{d.name:hashlib.sha256((d/'SKILL.md').read_bytes()).hexdigest() for d in SKILLS}}
  (destination/'execution.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  print(json.dumps({'case':ident,'exit_code':code,'messages':len(final),'changed_files':changed},ensure_ascii=False),flush=True)
  return result

if __name__=='__main__':
 selected=sys.argv[1:] or list(CASES)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for result in pool.map(run,selected):pass
