我会按 `rdk-model-zoo-develop` 技能先读取稀疏检出说明，再检查 YOLOv5 的 Python 入口、wrapper 和适用规范；只给出面向 S600 的最小修改与回归方案。


入口目前没有把类别数传给 wrapper，后者仍默认按 80 类解码；标签路径参数已经存在。另外，自定义模型路径缺失时会触发官方模型下载，方案需要避免将三类配置误配给官方权重。


主技能：`rdk-model-zoo-develop`。已按 `EVAL_CONTEXT.md` 核对：这是 `origin/rdk_s` 提交 `380e1a2…` 的稀疏检出，无板卡；技能维护源 `rdk_x5` 不代表本任务平台。方案仅面向 **S600、Python、YOLOv5 目标检测**。

**最小修改方案**

1. **入口增加类别数参数并透传。**  
   [main.py](/${EVAL_ROOT}/target/samples/vision/yolov5/runtime/python/main.py:71) 已有 `--model-path`、`--label-file`，但第 100 行构造配置时只传模型路径及两个阈值。拟增加：
   ```python
   parser.add_argument('--classes-num', type=int, default=80,
                       help='Number of detection classes.')
   # 构造 YOLOv5Config 时增加：
   classes_num=opt.classes_num
   ```
   保留默认 80 类；三类模型显式指定 `--classes-num 3`。

2. **标签在初始化模型前校验。**  
   复用现有 `file_io.load_class_names(opt.label_file)`，校验类别数为正、读取后的标签数等于 `classes_num`。三行标签按训练类别 ID **0、1、2** 排列，实际名称尚待提供。将 `coco_names` 改为 `class_names`，继续传给第 132 行 `visualize.draw_boxes(...)`；更新 `--label-file` 的 COCO 专属帮助文字。

3. **wrapper 已支持类别数，不必重写解码。**  
   [yolov5.py](/${EVAL_ROOT}/target/samples/vision/yolov5/runtime/python/yolov5.py:173) 已有 `YOLOv5Config.classes_num=80`；第 337 行将其传给 `decode_outputs`，第 147 行按 `5 + classes_num` reshape。  
   最小方案成立的前提：模型仍采用现有 NV12 双平面输入及三尺度、每尺度三个 anchor 的输出合同；三类对应每个 anchor **8 个值**。须核对输出布局、顺序、strides、anchors 和反量化信息。建议在 reshape 前增加合同校验，遇到不匹配明确报错；仅修改类别数不能适配任意 YOLO 导出格式。

4. **防止下载错权重，并同步说明。**  
   `main.py:92–97` 在模型缺失时下载官方权重。拟限定自动下载只用于默认模型配置；三类模式要求已有自定义 S600 模型文件，缺失即报错。更新 Python README 的参数表和三类示例。现有 `run.sh` 固定使用官方模型及 COCO 标签，并含安装、下载操作；最小方案保留其默认用途，三类示例直接调用 `main.py`。

适用规范为目标仓库的 Config/Model 分离、`argparse` kebab-case 与 `type/default/help`、检测返回 `(boxes, scores, cls_ids)`、文档默认值一致。上述新增校验属于本次工程提案。

**回归计划（均未执行）**

- Host：隔离硬件 runtime，先验证新增参数透传、默认 80 类、三标签映射；覆盖非正类别数、标签缺失/数量不符、自定义模型缺失且不触发下载。
- 后处理：合成三类输出，检查类别 ID 范围、空检测形状、错误输出合同；对照原 80 类结果防回归。
- S600：使用明确适配的三类 HBM 和带标注图片，检查三类标签、框和分数，再与参考输出比较；记录模型哈希、runtime 版本及输入身份。

本回合仅完成源码静态检查和方案，未改文件、安装依赖、运行模型或量化；未完成独立 review。三类产物的实际 I/O、数值精度及 S600 板测尚未验证，**不推断 S100、S100P 或其他板卡兼容性**。
