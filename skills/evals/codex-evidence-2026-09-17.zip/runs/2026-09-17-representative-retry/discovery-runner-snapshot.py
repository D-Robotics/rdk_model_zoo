from pathlib import Path
import os,tempfile,shutil,subprocess,json,tomllib,threading,queue
exe=Path('C:/Users/chao04.ma/AppData/Local/OpenAI/Codex/bin/eab8377aebac6c07/codex.exe')
pack=Path('_worktrees/model-zoo-skills/skills').resolve();out=pack/'evals/runs/2026-09-17-representative'
source_home=Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))
with tempfile.TemporaryDirectory(prefix='rdk-skills-discovery-') as temp:
 base=Path(temp);home=base/'codex';home.mkdir();work=base/'workspace';work.mkdir();subprocess.run(['git','init','-q',str(work)],check=True)
 shutil.copy2(source_home/'auth.json',home/'auth.json')
 for d in pack.glob('rdk-model-zoo*'):
  if (d/'SKILL.md').is_file():shutil.copytree(d,work/'.agents/skills'/d.name,ignore=shutil.ignore_patterns('__pycache__'))
 lines=['model = "gpt-6-astra"','approval_policy = "never"','sandbox_mode = "read-only"','cli_auth_credentials_store = "file"']
 for folder in [Path.home()/'.agents/skills',source_home/'skills']:
  for f in folder.rglob('SKILL.md'):
   lines+=['[[skills.config]]','path = '+json.dumps(str(f)),'enabled = false']
 (home/'config.toml').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 env={**os.environ,'CODEX_HOME':str(home),'PYTHONUTF8':'1'}
 p=subprocess.Popen([str(exe),'app-server','--stdio'],cwd=work,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8')
 q=queue.Queue()
 def read():
  for line in p.stdout:
   try:q.put(json.loads(line))
   except ValueError:pass
 threading.Thread(target=read,daemon=True).start()
 def send(obj):p.stdin.write(json.dumps(obj)+'\n');p.stdin.flush()
 def response(ident):
  while True:
   r=q.get(timeout=40)
   if r.get('id')==ident:return r
 try:
  send({'id':1,'method':'initialize','params':{'clientInfo':{'name':'rdk_skill_eval','version':'1.0'},'capabilities':{'experimentalApi':True}}});print('initialized', 'result' in response(1))
  send({'method':'initialized','params':{}})
  send({'id':2,'method':'skills/list','params':{'cwds':[str(work)],'forceReload':True}})
  result=response(2);(out/'discovery.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  entries=result.get('result',{}).get('data',[])
  for e in entries:
   enabled=[s for s in e['skills'] if s.get('enabled')]
   print(json.dumps({'enabled':[{'name':s['name'],'scope':s['scope']} for s in enabled],'errors':e.get('errors')},ensure_ascii=False))
 finally:
  p.terminate();p.wait(timeout=10)
